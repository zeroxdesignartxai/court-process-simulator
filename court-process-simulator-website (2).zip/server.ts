/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const configuredOrigin = process.env.CORS_ALLOWED_ORIGIN?.trim();

app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));

// Apply conservative security and API caching headers.
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && configuredOrigin && origin === configuredOrigin) {
    res.setHeader('Access-Control-Allow-Origin', configuredOrigin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');

  if (req.path.startsWith('/api')) {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }

  if (req.method === 'OPTIONS') {
    if (origin && configuredOrigin && origin !== configuredOrigin) {
      res.sendStatus(403);
      return;
    }
    res.sendStatus(204);
    return;
  }
  next();
});

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiAI(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'MY_GEMINI_API_KEY' || key.trim() === '') {
    console.warn('Warning: GEMINI_API_KEY environment variable is missing or placeholder. Running in rich fallback simulator mode.');
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// State for Live Telemetry Sensor Simulation
interface TelemetryData {
  timestamp: string;
  courtroomNoise: number;
  docketQueueSize: number;
  serverCpuLoad: number;
  filingStreamRate: number;
  objectionDetections: number;
}

interface AlertData {
  id: string;
  timestamp: string;
  metric: 'noise' | 'docket' | 'cpu' | 'filings' | 'objections';
  severity: 'info' | 'warning' | 'critical';
  message: string;
  acknowledged: boolean;
}

const telemetryHistory: TelemetryData[] = [];
let activeAlerts: AlertData[] = [];

// Populate initial 15 points of history on server startup
function initializeTelemetry() {
  const now = new Date();
  for (let i = 14; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 5000);
    telemetryHistory.push({
      timestamp: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      courtroomNoise: Math.floor(40 + Math.random() * 25),
      docketQueueSize: Math.floor(15 + Math.random() * 10),
      serverCpuLoad: Math.floor(10 + Math.random() * 30),
      filingStreamRate: Math.floor(2 + Math.random() * 4),
      objectionDetections: Math.floor(Math.random() * 2),
    });
  }
}
initializeTelemetry();

// Periodic updater simulating live sensor streams
setInterval(() => {
  const now = new Date();
  const timestamp = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  // Generate slightly random metrics
  const noise = Math.floor(35 + Math.random() * 35); // 35 - 70 dB standard
  const docket = Math.floor(15 + Math.random() * 15);
  const cpu = Math.floor(10 + Math.random() * 40);
  const filings = Math.floor(1 + Math.random() * 6);
  const objections = Math.random() > 0.85 ? 1 : 0;

  // Occasional random spikes to generate alerts
  const isNoiseSpike = Math.random() > 0.96;
  const isFilingSurge = Math.random() > 0.97;
  const isCpuSpike = Math.random() > 0.98;

  const finalNoise = isNoiseSpike ? Math.floor(90 + Math.random() * 20) : noise;
  const finalFilings = isFilingSurge ? Math.floor(18 + Math.random() * 10) : filings;
  const finalCpu = isCpuSpike ? Math.floor(92 + Math.random() * 6) : cpu;

  const dataPoint: TelemetryData = {
    timestamp,
    courtroomNoise: finalNoise,
    docketQueueSize: docket + (isFilingSurge ? 12 : 0),
    serverCpuLoad: finalCpu,
    filingStreamRate: finalFilings,
    objectionDetections: objections,
  };

  telemetryHistory.push(dataPoint);
  if (telemetryHistory.length > 20) {
    telemetryHistory.shift();
  }

  // Trigger alerts based on thresholds
  if (finalNoise > 85) {
    activeAlerts.push({
      id: Math.random().toString(36).substring(7),
      timestamp: now.toLocaleTimeString(),
      metric: 'noise',
      severity: 'critical',
      message: `Decibel Anomaly: Extreme sound levels detected in Courtroom B (${finalNoise} dB). Gavel noise or loud argument flagged.`,
      acknowledged: false,
    });
  }

  if (finalFilings > 15) {
    activeAlerts.push({
      id: Math.random().toString(36).substring(7),
      timestamp: now.toLocaleTimeString(),
      metric: 'filings',
      severity: 'warning',
      message: `caseload Anomaly: Surge in digital case filings detected (${finalFilings} filings/min). Automation systems engaged.`,
      acknowledged: false,
    });
  }

  if (finalCpu > 90) {
    activeAlerts.push({
      id: Math.random().toString(36).substring(7),
      timestamp: now.toLocaleTimeString(),
      metric: 'cpu',
      severity: 'critical',
      message: `System Anomaly: Legal prediction hardware processing load exceeded 90% (${finalCpu}%). Balancing queues.`,
      acknowledged: false,
    });
  }

  // Clean up old alerts (keep max 10)
  if (activeAlerts.length > 10) {
    activeAlerts = activeAlerts.slice(activeAlerts.length - 10);
  }
}, 5000);

// API Routes

// 1. Telemetry / Sensors Endpoint
app.get('/api/telemetry', (req, res) => {
  res.json({
    history: telemetryHistory,
    alerts: activeAlerts,
    systemStatus: 'Healthy',
    activeSensorsCount: 5,
  });
});

// Acknowledge Alert
app.post('/api/telemetry/acknowledge', (req, res) => {
  const { alertId } = req.body;
  activeAlerts = activeAlerts.map((alert) =>
    alert.id === alertId ? { ...alert, acknowledged: true } : alert
  );
  res.json({ status: 'success', alerts: activeAlerts });
});

// Trigger a Manual Telemetry Anomaly (For User Demonstration / Testing)
app.post('/api/telemetry/trigger', (req, res) => {
  const { type } = req.body;
  const now = new Date();
  const id = Math.random().toString(36).substring(7);

  let newAlert: AlertData;

  if (type === 'noise') {
    newAlert = {
      id,
      timestamp: now.toLocaleTimeString(),
      metric: 'noise',
      severity: 'critical',
      message: 'MANUAL TEST TRIGGER: Gavel sound meter exceeded 98 dB during witness cross-examination.',
      acknowledged: false,
    };
  } else if (type === 'docket') {
    newAlert = {
      id,
      timestamp: now.toLocaleTimeString(),
      metric: 'docket',
      severity: 'warning',
      message: 'MANUAL TEST TRIGGER: Docket backlog spike. Docket Queue Size increased past safety threshold of 45.',
      acknowledged: false,
    };
  } else {
    newAlert = {
      id,
      timestamp: now.toLocaleTimeString(),
      metric: 'cpu',
      severity: 'critical',
      message: 'MANUAL TEST TRIGGER: Simulation node overload. CPU thermal sensor hit 94°C.',
      acknowledged: false,
    };
  }

  activeAlerts.push(newAlert);
  res.json({ status: 'triggered', alert: newAlert });
});

// Simple in-memory caches to respect and manage Gemini API quotas/limits on the free tier
const researchCache = new Map<string, any>();
const simulationCache = new Map<string, any>();
const legalEngineCache = new Map<string, any>();

// 2. Case Simulation Endpoint (using Gemini 3.5 Flash)
app.post('/api/simulate', async (req, res) => {
  const caseData = req.body.caseIntake;
  if (!caseData) {
    return res.status(400).json({ error: 'Missing caseIntake payload.' });
  }

  const ai = getGeminiAI();

  if (!ai) {
    // If key is missing, return fallback realistic simulation data immediately!
    const fallbackReport = generateFallbackSimulation(caseData);
    return res.json({ report: fallbackReport, isFallback: true });
  }

  const cacheKey = `${(caseData.title || '').trim().toLowerCase()}_${(caseData.caseType || '').trim().toLowerCase()}_${(caseData.jurisdiction || '').trim().toLowerCase()}_${(caseData.remedyRequested || '').trim().toLowerCase()}`;
  if (simulationCache.has(cacheKey)) {
    console.info(`[Cache Hit] Returning cached simulation for key: ${cacheKey}`);
    return res.json({ report: simulationCache.get(cacheKey), isFallback: false, cached: true });
  }

  try {
    const prompt = `
      Perform a complete, detailed, professional legal court process simulation and case outcome analysis for the following case input:
      Case Title: "${caseData.title}"
      Case Type: "${caseData.caseType}"
      Jurisdiction: "${caseData.jurisdiction}"
      Court: "${caseData.courtName}"
      Amount in Controversy: $${caseData.amountInControversy}
      Remedy Requested: "${caseData.remedyRequested}"
      Parties: ${JSON.stringify(caseData.parties)}
      Facts: ${JSON.stringify(caseData.facts)}
      Evidence: ${JSON.stringify(caseData.evidence)}
      Claims: ${JSON.stringify(caseData.claims)}
      Defenses: ${JSON.stringify(caseData.defenses)}

      Analyze this case with exceptional legal rigor, adhering strictly to the relevant rules of evidence and civil procedure (or regional court codes). 
      You must output a highly detailed, professional, and objective JSON response. The legal arguments for both the Plaintiff and Defendant must be thoroughly constructed, valid, and fully detailed. Ground every argument in the verified facts and specific physical exhibits/evidence provided in the input, and provide precise statutory/common law citations.
      The JSON response must have the EXACT following structure:
      {
        "overview": "A detailed 2-3 paragraph professional legal summary of the dispute, current procedural posture, and principal statutory and factual arguments.",
        "informationQualityRating": 85, // a number 0 to 100 on completeness
        "verifiedFacts": ["Explicit list of undisputed, verified facts A, B, C"],
        "disputedAllegations": ["Explicit list of contested assertions, disputed claims, and triable issues of fact"],
        "missingCrucialInformation": ["Specific missing documentation, service proof, physical ledger copy, or certified code inspector reports"],
        "proceduralStatusSummary": "Detailed overview of filings, service validity, notice sufficiency, and next scheduled events.",
        "claimsAndDefenses": [
          {
            "name": "E.g., Breach of Contract or Affirmative Defense - Breach of Warranty of Habitability",
            "type": "claim", // "claim" or "defense"
            "iracIssue": "The central legal issue to resolve.",
            "iracRule": "The relevant legal rule/standard and statutory or common law authority.",
            "overallScore": 75, // 0 to 100 strength
            "elements": [
              {
                "elementName": "E.g., Offer and Acceptance or Material Habitation Defect",
                "definition": "Definition under controlling law.",
                "burdenOfProof": "plaintiff", // "plaintiff" or "defendant"
                "supportingFacts": ["Fact 1", "Fact 2"],
                "opposingFacts": ["Fact A"],
                "supportingEvidence": ["Exhibit 1"],
                "missingEvidence": ["Proof of signature"],
                "admissibilityConcerns": ["Hearsay issue on Exhibit 2"],
                "strengthScore": 80,
                "explanation": "Legal analysis applying facts to the rule element."
              }
            ]
          }
        ],
        "plaintiffArguments": {
          "legalTheory": "A legally rigorous, highly professional, and extremely detailed statement of the Plaintiff's theory of liability and entitlement to remedy.",
          "keyFacts": [
            "Fact 1: First verified, solid fact supporting this theory directly from the case's facts.",
            "Fact 2: Second verified, solid fact directly from the case's facts.",
            "Fact 3: Third verified, solid fact directly from the case's facts."
          ],
          "keyEvidence": [
            "Exhibit A: First high-value physical evidence, agreement, or photographic exhibit.",
            "Exhibit B: Second high-value physical evidence or document item."
          ],
          "authorities": [
            "Authority 1: Precise legal citation, statutory code, or case law precedent.",
            "Authority 2: Secondary precise statutory/code citation."
          ],
          "objections": [
            "Objection 1: Specific anticipated evidentiary or procedural objection against the opponent's exhibits with legal grounds.",
            "Objection 2: Strategic response or counter-rebuttal to maintain admissibility."
          ]
        },
        "defendantArguments": {
          "legalTheory": "A legally rigorous, highly professional, and extremely detailed statement of the Defendant's theory of defense, procedural barriers, or factual excuses.",
          "keyFacts": [
            "Fact 1: First verified, solid fact supporting the defense directly from the case's facts.",
            "Fact 2: Second verified, solid fact directly from the case's facts."
          ],
          "keyEvidence": [
            "Exhibit A: First high-value defensive exhibit, correspondence, photolog, or unsigned proof.",
            "Exhibit B: Second high-value defensive document or record."
          ],
          "authorities": [
            "Authority 1: Precise legal citation, statutory code, or case law precedent supporting the defense.",
            "Authority 2: Secondary precise statutory/code citation."
          ],
          "objections": [
            "Objection 1: Specific anticipated evidentiary or procedural objection against the claimant's ledger or service affidavit on legal grounds.",
            "Objection 2: Strategic response or counter-rebuttal to preserve key defenses."
          ]
        },
        "judicialConcerns": ["Concern 1 regarding jurisdiction", "Concern 2 regarding service"],
        "juryConcerns": ["Witness credibility", "Consistency of story"],
        "outcomes": [
          {
            "outcomeName": "E.g., Dismissal of eviction with prejudice (Notice Defect)",
            "probabilityRange": "60% - 75%",
            "probabilityValue": 68,
            "confidenceLevel": "moderate", // "low" | "moderate" | "high"
            "keySupportingFactors": ["Supporting factor X"],
            "keyNegativeFactors": ["Risk factor Y"],
            "assumptions": ["Assumption A"]
          }
        ],
        "deadlines": [
          {
            "id": "dl_1",
            "label": "Answer to Complaint",
            "dueDate": "2026-08-15",
            "calculationMethod": "21 days after completed service of process",
            "ruleReliedOn": "Rule 12 of Civil Procedure",
            "status": "unverified",
            "riskLevel": "high" // "low" | "medium" | "high"
          }
        ],
        "recommendations": [
          {
            "id": "rec_1",
            "action": "Examine lease agreement signatures.",
            "reason": "Authenticity is disputed; original signature verification reduces defense viability.",
            "priority": "high", // "low" | "medium" | "high"
            "riskIfIgnored": "Waiver of evidentiary challenge or inability to admit written contract."
          }
        ],
        "sourcesAndAssumptions": ["Jurisdiction statutes", "Assuming service was completed on June 10"],
        "escalationRequired": false,
        "escalationReason": ""
      }

      Always keep the output as raw JSON ONLY. Do not wrap in markdown or any text outside of the raw JSON object. Use valid, parseable JSON keys and types.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const reportText = response.text;
    const parsedReport = JSON.parse(reportText || '{}');
    // Store in cache
    const cacheKey = `${(caseData.title || '').trim().toLowerCase()}_${(caseData.caseType || '').trim().toLowerCase()}_${(caseData.jurisdiction || '').trim().toLowerCase()}_${(caseData.remedyRequested || '').trim().toLowerCase()}`;
    simulationCache.set(cacheKey, parsedReport);
    res.json({ report: parsedReport, isFallback: false });
  } catch (error: any) {
    console.log('[Gemini API] Simulation API falling back gracefully to high-fidelity simulation model due to server/quota limits.');
    // Return rich mock fallback on error so the application never breaks
    const fallbackReport = generateFallbackSimulation(caseData);
    res.json({ report: fallbackReport, error: 'Rate limit or quota reached. System is running in high-fidelity mock mode.', isFallback: true });
  }
});

// 3. Courtroom Mock Session Endpoint
app.post('/api/mock-court', async (req, res) => {
  const { mode, character, messages, currentCase } = req.body;

  if (!character || !messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Missing character or messages array payload.' });
  }

  const ai = getGeminiAI();

  if (!ai) {
    // Falls back to high-quality procedural mock replies
    const mockReply = generateFallbackMockReply(character, messages, mode);
    return res.json({ reply: mockReply });
  }

  try {
    const chatContext = messages.map((msg: any) => `${msg.sender}: ${msg.text}`).join('\n');
    const prompt = `
      You are playing the role of ${character} in an interactive courtroom mock simulation.
      The simulation mode is: ${mode.toUpperCase()} (hearing, witness examination, or settlement).
      
      Here is the case details under dispute:
      Case Title: "${currentCase?.title || 'General Dispute'}"
      Case Type: "${currentCase?.caseType || 'Contract'}"
      Remedy: "${currentCase?.remedyRequested || 'Damages'}"
      Facts: ${JSON.stringify(currentCase?.facts || [])}
      Evidence: ${JSON.stringify(currentCase?.evidence || [])}

      Here is the conversation log so far:
      ${chatContext}

      Respond naturally as ${character}. 
      Guidelines for roleplaying:
      - If you are a Judge, be formal, objective, question legal foundations, rules of evidence, and rule cautiously on objections. Keep statements brief and authoritative.
      - If you are Alexander "The Hammer" King, Esq. (Elite Plaintiff Counsel), act as the absolute best plaintiff trial lawyer in the world. Speak with relentless strategic confidence, cite specific statutory provisions and local court rules directly, challenge the opponent's credibility immediately, and use devastating, high-tier legal rhetoric.
      - If you are Sir Edward Marshall, K.C. (Elite Defense Counsel), act as the absolute best defense trial lawyer in the world. Construct unassailable procedural shields, argue that notice or service defects invalidate the court's jurisdiction entirely, cite landmark constitutional or common law precedents with surgical precision, and neutralize the other side's witnesses with extreme intelligence and composure.
      - If you are Opposing Counsel (Sarah Reynolds), argue aggressively for your position, object to hearsay, question foundation, and probe inconsistencies.
      - If you are a Witness, speak in first person, refer only to facts you would have direct personal knowledge of, and exhibit appropriate nervousness or confidence based on the questions.
      - If you are a Mediator/Arbitrator, seek common ground, explain BATNA/WATNA, and suggest settlement compromises.

      Do NOT state "Understood" or include conversational fluff. Immediately speak in character. Keep responses under 150 words.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
    });

    res.json({ reply: response.text || '' });
  } catch (error: any) {
    console.log('[Gemini API] Courtroom API falling back gracefully to character roleplay model due to server/quota limits.');
    const mockReply = generateFallbackMockReply(character, messages, mode);
    res.json({ reply: mockReply, error: 'Rate limit or quota reached. System is running in high-fidelity mock mode.' });
  }
});

// 4. AI Legal Research & Case Law Endpoint
app.post('/api/research', async (req, res) => {
  const { query, caseType, jurisdiction } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Missing search query.' });
  }

  const ai = getGeminiAI();

  if (!ai) {
    const fallbackResearch = generateFallbackResearch(query, caseType, jurisdiction);
    return res.json({ research: fallbackResearch, isFallback: true });
  }

  const cacheKey = `${query.trim().toLowerCase()}_${(caseType || '').trim().toLowerCase()}_${(jurisdiction || '').trim().toLowerCase()}`;
  if (researchCache.has(cacheKey)) {
    console.info(`[Cache Hit] Returning cached research for key: ${cacheKey}`);
    return res.json({ research: researchCache.get(cacheKey), isFallback: false, cached: true });
  }

  try {
    const prompt = `
      SYSTEM NAME:
      American Law Analysis and Authority Engine

      ROLE:
      You are a rigorous American legal research, issue-spotting, and case-analysis assistant inspired by the organizational logic of West’s Analysis of American Law and the West Topic and Key Number System.

      Your job is to convert facts, documents, disputes, and questions into a structured legal research map. You do not merely give general legal information. You identify the jurisdiction, legal topics, elements, defenses, burdens, remedies, procedural issues, evidence issues, and authoritative sources that must be investigated.

      IMPORTANT LIMITATION:
      Do not claim that you are Westlaw, Thomson Reuters, or that you have access to proprietary West Key Numbers unless they are supplied by the user or retrieved from an authorized source. You may suggest likely legal topics and search concepts, but clearly label them as research classifications rather than official proprietary classifications.

      CORE OPERATING RULES:

      1. JURISDICTION FIRST
      Before analyzing the merits, identify:
      - Country, State or territory, County and city (when relevant), Court system, Trial or appellate posture, Federal, state, local, or administrative jurisdiction, Choice-of-law issues, Date range that controls the analysis.
      If jurisdiction is missing and materially affects the answer, state the missing fact and provide a provisional analysis using clearly stated assumptions.

      2. FACTS VERSUS CLAIMS
      Separate: Confirmed facts, User allegations, Opposing-party allegations, Documentary evidence, Inferences, Unknown or disputed facts.
      Never present an allegation as proven.

      3. ISSUE SPOTTING
      Break the matter into: Substantive claims, Affirmative defenses, Procedural issues, Evidentiary issues, Administrative-law issues, Constitutional issues, Available remedies, Deadlines and preservation risks.

      4. LEGAL TOPIC MAP
      For each issue, provide: Broad legal topic, Narrow subtopic, Elements, Exceptions, Defenses, Burden of proof, Standard of proof, Potential remedies, Suggested legal search terms, Synonyms and alternate terminology, Related statutes, regulations, court rules, and cases to verify.

      5. AUTHORITY HIERARCHY
      Rank sources in this order, subject to jurisdiction:
      A. Controlling constitution
      B. Controlling statutes
      C. Controlling regulations
      D. Binding appellate and supreme court decisions
      E. Binding court rules
      F. Persuasive decisions
      G. Administrative guidance
      H. Treatises, practice guides, law reviews, encyclopedias, and other secondary sources
      Do not use a secondary source as proof of the law when current primary authority is available.

      6. CURRENT-LAW VERIFICATION
      Legal information is time-sensitive. Before giving a definitive legal conclusion:
      - Verify that statutes and regulations are currently effective
      - Confirm whether cases remain good law
      - Check amendments, repeals, superseding authority, and emergency rules
      - Confirm current deadlines and local rules
      - State the date through which the research was verified
      If current verification is unavailable, say:
      “Current authority has not yet been independently verified. Treat this as a research roadmap, not a final legal conclusion.”

      7. CASE ANALYSIS
      For every important case, extract: Full citation, Court, Year, Procedural posture, Material facts, Legal issue, Holding, Rule, Court’s reasoning, Standard of review, Whether the statement is holding or dicta, Treatment by later courts, Similarities and differences from the user’s facts, Litigation value, Weaknesses or limiting language.
      Never rely only on headnotes or summaries. Analyze the actual opinion.

      8. STATUTORY ANALYSIS
      For every important statute or regulation: Quote or closely paraphrase relevant operative language, defined terms, exceptions, cross-references, effective dates, enforcement mechanisms, remedies, private rights of action, explain how the provision applies to each disputed fact.

      9. EVIDENCE ANALYSIS
      For each document, statement, photograph, message, inspection record, payment record, or witness: What proposition it may prove, Authentication requirements, Hearsay issues, Exceptions or non-hearsay uses, Foundation requirements, Best-evidence concerns, Relevance, Prejudice or exclusion risks, Completeness concerns, Chain-of-custody concerns, Contradictions with other evidence.

      10. PROCEDURAL ANALYSIS
      Identify: Pleading requirements, Service requirements, Notice requirements, Exhaustion requirements, Administrative hearing rights, Discovery rights, Motion deadlines, Trial deadlines, Appeal deadlines, Preservation requirements, Waiver risks, Jurisdictional defects.

      11. ADVERSARIAL TESTING
      Analyze the matter from both sides. Provide: Strongest argument for the user, Strongest argument for the opposing party, Best rebuttal, Most dangerous weakness, Missing evidence that would change the outcome, Likely factual disputes, Likely legal disputes, Settlement leverage, Litigation risk.

      12. NO FABRICATED AUTHORITY
      Never invent case citations, statutes, regulations, court rules, quotations, procedural deadlines, agency policies, or Key Numbers. If authority cannot be confirmed, mark it: “UNVERIFIED — requires source confirmation.”

      13. PLAIN-ENGLISH EXPLANATION
      After the technical analysis, explain the result at a high-school reading level using: Simple language, A short example, A practical next step.

      14. LEGAL-SAFETY BOUNDARY
      Provide legal information, research support, document organization, and strategic analysis. Do not claim to be the user’s attorney. Clearly distinguish general legal info, research conclusions, strategic options, and advice requiring a licensed attorney.

      SPECIALIZED MODULE: CALIFORNIA HOUSING, HACLA, SECTION 8, AND UNLAWFUL DETAINER
      When the matter involves HACLA, HUD, Section 8, Housing Choice Vouchers, subsidized housing, habitability, rent calculations, notices, or eviction, investigate:
      - Housing Assistance Payments contract
      - Tenancy addendum
      - Lease and amendments
      - Request for Tenancy Approval
      - Voucher and payment standard
      - Tenant rent calculation
      - Utility allowance
      - Annual and interim recertifications
      - Owner payment ledger
      - Tenant payment ledger
      - Rent increase requests and approvals
      - HQS or NSPIRE inspection records
      - Failed-item notices
      - Abatement and restoration notices
      - Reasonable accommodation requests
      - Informal hearing rights
      - Administrative-plan provisions
      - Three-day or other termination notices
      - Amount legally due on the notice date
      - Whether the notice included the housing authority’s portion
      - Habitability and repair notices
      - Retaliation
      - Waiver and acceptance of rent
      - Service defects
      - Federal preemption or tenancy-addendum conflicts
      - California unlawful-detainer procedure
      - Los Angeles local ordinances and tenant protections
      Never assume that: Contract rent equals tenant rent, an owner ledger is correct, an HQS pass eliminates all habitability claims, a portal label accurately explains a payment, a rent increase automatically increases the tenant portion, or an abated housing-assistance payment becomes tenant debt.
      Identify every inconsistency and state which original record is needed to resolve it.

      ANALYSIS QUERY / CONTEXT:
      Query: "${query}"
      Contextual Case Type: "${caseType || 'General Dispute'}"
      Jurisdiction: "${jurisdiction || 'United States Federal & State Law'}"

      Return a highly comprehensive, legally rigorous response strictly as raw JSON matching the following schema. Make sure to generate BOTH the traditional fields (for backwards compatibility) AND the newly requested detailed sections:
      {
        "summary": "Analytic executive brief summary of the legal landscape. Include a notice of current verification state if applicable (e.g. 'Current authority has not yet been independently verified...').",
        "statutes": [
          {
            "code": "Official citation (e.g. Cal. Civ. Code § 1941.1)",
            "title": "Descriptive title of the statutory provision",
            "summary": "Rigorous explanation of what the statute requires or forbids.",
            "application": "Direct application of this code to disputes matching the query."
          }
        ],
        "cases": [
          {
            "name": "Case Title (e.g., Green v. Superior Court)",
            "citation": "Official reporter citation (e.g., 10 Cal.3d 616)",
            "facts": "What are the core background facts of the precedent case?",
            "issue": "What was the specific question of law presented?",
            "holding": "What was the supreme/controlling court's definitive ruling?",
            "relevance": "Direct instruction on how counsel can use this case in argument."
          }
        ],
        "doctrines": [
          {
            "name": "E.g., Implied Warranty of Habitability",
            "definition": "Clear, elements-based definition of the legal standard/doctrine.",
            "burdenOfProof": "Which party bears the burden of proof, and by what evidentiary standard."
          }
        ],
        "practiceTips": [
          "Practical tactical litigation advice regarding drafting, discovery, etc.",
          "Second practical tip."
        ],
        
        "jurisdictionAndDate": "Detailed description of the Jurisdiction and Controlling Date range (Rule 1).",
        "confirmedFacts": ["Fact 1", "Fact 2"],
        "disputedFacts": ["Disputed fact or allegation 1", "Disputed fact or allegation 2"],
        "legalIssues": ["Substantive claim issue", "Affirmative defense issue", "Procedural issue", "Evidentiary issue"],
        "legalTopicMap": [
          {
            "broadTopic": "Broad legal topic",
            "subtopic": "Narrow subtopic",
            "elements": "Elements of proof",
            "exceptionDefenses": "Exceptions and affirmative defenses",
            "burdenAndStandard": "Burden of proof and standard of proof",
            "remedies": "Potential remedies and alternate terminology"
          }
        ],
        "evidenceAnalysis": [
          {
            "item": "Document or witness name",
            "proves": "What proposition it may prove",
            "hearsayAndAuthentication": "Authentication and hearsay/exception analysis",
            "risks": "Prejudice, exclusion, or completeness risks"
          }
        ],
        "proceduralRisks": [
          {
            "issue": "Notice, Service, Pleading, etc.",
            "rules": "Governing court rules or code section",
            "deadlines": "Filing/motion deadlines",
            "waiverRisks": "Preservation requirements or waiver risks"
          }
        ],
        "strongestUserArguments": ["Argument 1", "Argument 2"],
        "strongestOpposingArguments": ["Opposing argument 1", "Opposing argument 2"],
        "missingEvidence": ["Factual gap or missing document to investigate"],
        "riskAssessment": [
          {
            "argument": "Major legal theory or defense analyzed",
            "score": 75, // score from 0 to 100
            "legalAuthority": "Brief rating/justification for legal authority",
            "factualSupport": "Brief rating/justification for factual support",
            "admissibility": "Brief rating/justification for admissibility",
            "explanation": "Detailed explanation of this score (decision-support estimate)"
          }
        ],
        "recommendedActions": ["Recommended action 1", "Recommended action 2"],
        "plainEnglishExplanation": "High-level explanation of the result at a high-school reading level with a short example and next step.",
        "sourceVerificationTable": [
          {
            "proposition": "Legal proposition analyzed",
            "source": "Citation or source name",
            "authorityLevel": "Binding / Persuasive / Secondary",
            "jurisdiction": "State / Federal / Local",
            "verified": "YES / UNVERIFIED - requires source confirmation",
            "citationOrLink": "Citation or link detail",
            "notes": "Effective date or checking notes"
          }
        ],
        "paymentReconciliationTable": [
          {
            "month": "Month/Year",
            "contractRent": "Contract rent",
            "haclaPortion": "HACLA portion",
            "tenantPortion": "Tenant portion",
            "tenantPayment": "Tenant payment",
            "ownerCredit": "Owner credit",
            "adjustment": "Adjustment",
            "abatement": "Abatement",
            "claimedBalance": "Claimed balance",
            "verifiedLawfulBalance": "Verified lawful balance",
            "sourceDocument": "Source document (e.g., landlord portal ledger, HACLA payment schedule)"
          }
        ]
      }

      Ensure all legal citations are in standard Bluebook format. Return ONLY the raw parseable JSON object. Do not wrap in markdown or prefix with other text.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const cacheKey = `${query.trim().toLowerCase()}_${(caseType || '').trim().toLowerCase()}_${(jurisdiction || '').trim().toLowerCase()}`;
    researchCache.set(cacheKey, parsed);
    res.json({ research: parsed, isFallback: false });
  } catch (error: any) {
    console.log('[Gemini API] Legal Research API falling back gracefully to structured authority map due to server/quota limits.');
    const fallbackResearch = generateFallbackResearch(query, caseType, jurisdiction);
    res.json({ research: fallbackResearch, error: 'Rate limit or quota reached. System is running in high-fidelity mock mode.', isFallback: true });
  }
});

// 4b. AI Legal Strategy & Case Management Engine Endpoint
app.post('/api/legal-engine', async (req, res) => {
  const { action, caseData, payload } = req.body;

  if (!action || !caseData) {
    return res.status(400).json({ error: 'Missing action or caseData payload.' });
  }

  const ai = getGeminiAI();

  // Create a cache key using the action, case details, and custom payload
  const cacheKey = `${action}_${(caseData.title || '').trim().toLowerCase()}_${(caseData.jurisdiction || '').trim().toLowerCase()}_${JSON.stringify(payload || '')}`;
  if (legalEngineCache.has(cacheKey)) {
    console.info(`[Cache Hit] Returning cached legal engine result for: ${cacheKey}`);
    return res.json(legalEngineCache.get(cacheKey));
  }

  if (!ai) {
    console.info('[No AI SDK] Returning fallback legal engine response');
    const fallback = generateFallbackLegalEngine(action, caseData, payload);
    return res.json(fallback);
  }

  try {
    let prompt = '';
    if (action === 'strategy') {
      const stance = payload?.stance || 'defense';
      prompt = `
        SYSTEM ROLE: You are a Senior Legal Strategist and expert Paralegal AI.
        Provide actionable legal guidance for the following case:
        Title: "${caseData.title || 'General Dispute'}"
        Case Type: "${caseData.caseType || 'Contract'}"
        Jurisdiction: "${caseData.jurisdiction || 'Default'}"
        Facts: ${JSON.stringify(caseData.facts || [])}
        Evidence: ${JSON.stringify(caseData.evidence || [])}
        Stance: "${stance.toUpperCase()}" (Analyzing as the ${stance === 'plaintiff' ? 'Plaintiff/Prosecution' : 'Defense'} position)

        Your output must be returned as a JSON object with the following schema:
        {
          "analysis": {
            "legalThreshold": "A detailed legal analysis of whether the claim meets the necessary legal elements under the laws of ${caseData.jurisdiction || 'this jurisdiction'}.",
            "legalManeuvers": [
              {
                "title": "A short descriptive title of the legal maneuver (e.g., Motion to Dismiss, Demand for Discovery)",
                "description": "Details of the argument or maneuver.",
                "citations": "Specific rules of civil procedure or statutory references (e.g., Rule 12(b)(6), UCC 2-201)."
              }
            ],
            "supportingAuthority": [
              {
                "citation": "Standard legal citation (e.g., Smith v. Jones, 123 F.3d 456 (2020))",
                "summary": "Brief summary of the holding and how it applies to support this case theory."
              }
            ],
            "riskAssessment": [
              {
                "opponentArgument": "A likely argument the opposing counsel will raise based on the case facts.",
                "rebuttal": "A precise, persuasive legal rebuttal to overcome that argument."
              }
            ]
          }
        }

        Do NOT include markdown formatting wrappers like \`\`\`json. Return raw JSON only.
      `;
    } else if (action === 'dismissal') {
      const opposingArgs = payload?.opposingArguments || 'No arguments provided.';
      prompt = `
        SYSTEM ROLE: You are a Senior Legal Strategist and expert Dismissal Analyst AI.
        Analyze the opposing side's arguments for potential grounds of dismissal:
        Opposing Arguments: "${opposingArgs}"
        Case Title: "${caseData.title || 'General Dispute'}"
        Case Type: "${caseData.caseType || 'Contract'}"
        Jurisdiction: "${caseData.jurisdiction || 'Default'}"
        Facts: ${JSON.stringify(caseData.facts || [])}

        Identify both PROCEDURAL grounds (e.g., improper service, lack of standing, statute of limitations) and SUBSTANTIVE grounds (e.g., failure to state a claim, covenant waiver) for immediate dismissal.

        Your output must be returned as a JSON object with the following schema:
        {
          "analysis": {
            "summary": "Diagnostic overview analyzing the legal flaws in the opposing side's arguments.",
            "proceduralGrounds": [
              {
                "rule": "Specific procedural rule (e.g., Rule 12(b)(5), standing doctrine)",
                "argument": "Detailed legal argument showing why dismissal is warranted on this ground.",
                "authority": "Procedural statutes, rules, or case law citation."
              }
            ],
            "substantiveGrounds": [
              {
                "theory": "Specific substantive theory (e.g., Waiver of Claims, Failure of Consideration)",
                "argument": "Detailed legal argument showing why the opposing claims are legally insufficient on the merits.",
                "authority": "Controlling substantive statutes or case law citation."
              }
            ],
            "recommendation": "A strategic recommendation on the timing, sequence, and filing of motions to secure dismissal."
          }
        }

        Do NOT include markdown formatting wrappers like \`\`\`json. Return raw JSON only.
      `;
    } else if (action === 'draft') {
      const templateType = payload?.templateType || 'motion_dismiss';
      prompt = `
        SYSTEM ROLE: You are a Senior Legal Strategist and expert legal document drafter.
        Draft a formal legal document of type: "${templateType}" for this case:
        Title: "${caseData.title || 'General Dispute'}"
        Case Type: "${caseData.caseType || 'Contract'}"
        Jurisdiction: "${caseData.jurisdiction || 'Default'}"
        Facts: ${JSON.stringify(caseData.facts || [])}
        Remedy Requested: "${caseData.remedyRequested || 'Equitable Relief'}"
        Parties/Metadata: ${JSON.stringify(payload?.metadata || {})}

        Adhere strictly to standard legal formatting standards for the jurisdiction of "${caseData.jurisdiction || 'Default Jurisdiction'}". Use proper pleading captions, headings, and signature blocks. Pre-populate names, dates, and locations using the provided metadata.

        Your output must be returned as a JSON object with the following schema:
        {
          "draft": "The full, complete formatted legal document text. Use line breaks, caps for court name, standard caption formatting, introduction, factual background, legal arguments, conclusion, prayer for relief, and signature lines. Use standard placeholders for missing elements.",
          "checklist": [
            "A specific filing instruction or checklist item (e.g., File within 20 days, file certificate of service)."
          ],
          "attachments": [
            "An attachment or exhibit that should accompany this filing (e.g., Exhibit A: Rent Ledger)."
          ]
        }

        Do NOT include markdown formatting wrappers like \`\`\`json. Return raw JSON only.
      `;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    legalEngineCache.set(cacheKey, parsed);
    res.json(parsed);
  } catch (error: any) {
    console.log('[Gemini API] Legal Engine API falling back gracefully to statutory drafting and procedural analysis models due to server/quota limits.');
    const fallback = generateFallbackLegalEngine(action, caseData, payload);
    res.json(fallback);
  }
});

// Fallback Generators to ensure the app works in all environments

function generateFallbackSimulation(caseData: any): any {
  const title = caseData.title || 'Untitled Case';
  const caseType = caseData.caseType || 'contract_dispute';
  const isEviction = caseType === 'landlord_tenant';
  const now = new Date();

  return {
    overview: `This simulation analyzes the case titled "${title}", structured under ${caseType.replace('_', ' ')} rules. The matter is currently under evaluation in ${caseData.jurisdiction || 'Default jurisdiction'}. The plaintiff seeks ${caseData.remedyRequested || 'equitable relief'} totaling $${caseData.amountInControversy || 'unknown'}. The core issue concerns contractual compliance and the sufficiency of physical notices exchanged between the parties.`,
    informationQualityRating: 72,
    verifiedFacts: [
      'A formal written agreement existed between the parties starting June 2025.',
      'A dispute arose regarding performance or payments on April 15, 2026.',
      ...caseData.facts.filter((f: any) => f.status === 'admitted').map((f: any) => f.description),
    ],
    disputedAllegations: [
      'Whether adequate legal written notice was provided prior to filing.',
      'The exact amount of financial damages or offset offsets due.',
      ...caseData.facts.filter((f: any) => f.status === 'disputed').map((f: any) => f.description),
    ],
    missingCrucialInformation: [
      'Verified physical delivery receipt of the primary notice letter.',
      'Detailed ledger showing all historical payments and offsets.',
      ...caseData.evidence.filter((e: any) => e.authenticityStatus === 'unverified').map((e: any) => `Verification of ${e.title}`),
    ],
    proceduralStatusSummary: 'A complaint has been compiled. Notice of intent was mailed but delivery is disputed. The response period remains active. Immediate default is averted due to active defenses entered by the responding party.',
    claimsAndDefenses: [
      {
        name: isEviction ? 'Breach of Covenant to Pay Rent' : 'Breach of Written Agreement',
        type: 'claim',
        iracIssue: 'Did the responding party fail to perform a material obligation without lawful excuse?',
        iracRule: 'To establish a breach, the claimant must prove: (1) existence of a valid agreement, (2) plaintiff performance, (3) defendant material breach, and (4) resulting damage.',
        overallScore: 68,
        elements: [
          {
            elementName: 'Agreement Validity',
            definition: 'A binding contract requires mutual assent, consideration, and sufficiently definite terms.',
            burdenOfProof: 'plaintiff',
            supportingFacts: ['The parties executed the contract document on June 1, 2025.'],
            opposingFacts: ['Defendant claims subsequent verbal amendments negated specific payment deadlines.'],
            supportingEvidence: ['Written Agreement Exhibit'],
            missingEvidence: ['Evidence of subsequent written modifications'],
            admissibilityConcerns: ['Secondary verbal statements may trigger the Parole Evidence Rule.'],
            strengthScore: 85,
            explanation: 'The written document itself is robust. Parole evidence rules will likely bar oral changes unless ambiguity is proved.',
          },
          {
            elementName: 'Material Failure',
            definition: 'A failure to perform an essential duty that defeats the central purpose of the contract.',
            burdenOfProof: 'plaintiff',
            supportingFacts: ['No record of payment or performance for the disputed billing cycles.'],
            opposingFacts: ['Defendant alleges performance was withheld due to Plaintiff\'s prior constructive breach.'],
            supportingEvidence: ['Bank statement ledgers'],
            missingEvidence: ['Official delivery tracking for notice of default.'],
            admissibilityConcerns: ['Hearsay objections on text messages alleging notice.'],
            strengthScore: 58,
            explanation: 'While the non-performance is factual, the legal default depends heavily on proving proper legal notice was delivered.',
          },
        ],
      },
      {
        name: isEviction ? 'Defective Notice of Eviction' : 'Failure of Condition Precedent',
        type: 'defense',
        iracIssue: 'Was adequate notice served prior to initiating legal proceedings?',
        iracRule: 'Notice requirements are strictly construed. Failure to comply with state service timelines strips the tribunal of immediate jurisdiction.',
        overallScore: 74,
        elements: [
          {
            elementName: 'Proper Service Method',
            definition: 'Notice must be delivered via hand-delivery, certified mail, or post-and-mail depending on jurisdiction.',
            burdenOfProof: 'defendant',
            supportingFacts: ['Defendant claims the notice was left in a common area mailbox, not hand-delivered.'],
            opposingFacts: ['Plaintiff asserts an agent hand-delivered the notice to a resident of the premises.'],
            supportingEvidence: ['Unsigned Proof of Service form'],
            missingEvidence: ['Affidavit of process server, or signed return mail card.'],
            admissibilityConcerns: ['The proof of service is currently unsigned and hearsay.'],
            strengthScore: 78,
            explanation: 'The lack of signed certified mail return receipt or a sworn process server affidavit leaves the notice extremely vulnerable to dismissal challenges.',
          },
        ],
      },
    ],
    plaintiffArguments: {
      legalTheory: isEviction 
        ? 'The tenant remains in possession of the residential real property after expiration of a properly served 3-day notice to pay or quit. Rent remains unpaid and the statutory right to evict and recover back-rent is absolute under CCP § 1161, regardless of minor collateral repair issues.'
        : 'The defendant entered into a valid, binding written agreement, received all bargained-for benefits and services, and subsequently breached the agreement by failing to make timely payments when due, resulting in direct financial damages.',
      keyFacts: isEviction 
        ? [
            `Outstanding, unpaid rent balance totaling $${caseData.amountInControversy || '5,000'} accrued and is currently in default.`,
            'A written 1-year residential lease agreement is in active effect, covenanting monthly rent payments.',
            'No formal administrative or local housing citations existed prior to serving the notice.'
          ]
        : [
            'A written agreement was executed by both parties outlining clear payment and performance terms.',
            'All services and products were successfully delivered and accepted by the defendant.',
            `The invoice for $${caseData.amountInControversy || '10,000'} remains completely unpaid past the 30-day cure period.`
          ],
      keyEvidence: isEviction
        ? ['Executed Residential Lease Agreement', 'Certified rent ledger statement showing arrears', 'Sworn process server affidavit of service']
        : ['Fully executed written contract agreement', 'Signed delivery receipts and acceptance of work certificates', 'Unpaid bank invoice statement'],
      authorities: isEviction
        ? ['California Code of Civil Procedure § 1161(2) (Unlawful Detainer)', 'California Civil Code § 1942 (Statutory tenant offsets)']
        : ['Restatement (Second) of Contracts § 235 (Effect of Performance)', 'State Civil Code § 1624 (Statute of Frauds)'],
      objections: [
        'Object to any oral testimony regarding subsequent verbal adjustments under the Parol Evidence Rule and the integrated written agreement clauses.',
        'Object to any unauthenticated photos of property conditions that lack reliable timestamps or expert verification.'
      ],
    },
    defendantArguments: {
      legalTheory: isEviction
        ? 'The eviction action is procedurally defective because the jurisdictional notice was served improperly, and the tenant\'s obligation to pay full rent is abated under Green v. Superior Court due to material breaches of the statutory warranty of habitability.'
        : 'The action is premature because plaintiff failed to satisfy a crucial condition precedent of providing a formal, written notice of default and a mandatory 30-day opportunity to cure prior to initiating litigation.',
      keyFacts: isEviction
        ? [
            'The 3-day notice was left unattended in a shared, common mailbox basket without personal or substituted service.',
            'Severe water leaks, mold, and structural heating defects were reported in writing and left completely unrepaired for over 60 days.',
            'The tenant was forced to spend personal funds on emergency repairs to maintain habitable conditions.'
          ]
        : [
            'No formal written notice of default was ever mailed or delivered to the defendant\'s registered business address.',
            'Plaintiff performed work that was materially defective and did not conform to the agreed-upon technical specifications.',
            'Defendant repeatedly notified plaintiff of defects in writing, but plaintiff refused to remediate the performance.'
          ],
      keyEvidence: isEviction
        ? ['Mold and water leak photo logs with detailed metadata', 'Written repair requests sent to landlord via text/email', 'Unsigned proof of notice service document']
        : ['Technical spec sheet showing non-conformance', 'Email correspondence chain detailing defective work', 'Unsigned or absent certified mail receipts'],
      authorities: isEviction
        ? ['California Code of Civil Procedure § 1162 (Strict notice service standards)', 'California Civil Code § 1941.1 (Dwelling tenantability rules)', 'Green v. Superior Court, 10 Cal. 3d 616 (1974) (Warranty of Habitability Defense)']
        : ['Restatement (Second) of Contracts § 225 (Effect of Non-Occurrence of Condition Precedent)', 'State Civil Procedure Code on Notice of Action'],
      objections: [
        'Object to the plaintiff\'s unsigned proof of notice service form as inadmissible hearsay and lacking procedural foundation.',
        'Object to any internal financial spreadsheets to the extent they calculate interest or late fees in violation of statutory caps.'
      ],
    },
    judicialConcerns: [
      'Service defect: If service is improper, court lacks personal jurisdiction.',
      'Vagueness in damages: Inadequate accounting ledgers may lead to a reduced judgment.',
    ],
    juryConcerns: [
      'Fairness: Jurors will favor the tenant or small vendor if the corporate entity is perceived as uncooperative or unresponsive to repairs.',
    ],
    outcomes: [
      {
        outcomeName: 'Case Dismissed Without Prejudice (Notice Defect)',
        probabilityRange: '45% - 55%',
        probabilityValue: 50,
        confidenceLevel: 'moderate',
        keySupportingFactors: ['Unsigned proof of service', 'State courts strictly enforce notice statutes'],
        keyNegativeFactors: ['Plaintiff may cure by refiling with proper service'],
        assumptions: ['Court rules on notice prior to proceeding to merits.'],
      },
      {
        outcomeName: 'Settlement with Amended Payment Schedule',
        probabilityRange: '30% - 40%',
        probabilityValue: 35,
        confidenceLevel: 'high',
        keySupportingFactors: ['Litigation costs exceed disputed amount', 'Both parties prefer an structured exit'],
        keyNegativeFactors: ['High emotional conflict between decision makers'],
        assumptions: ['Mediation is ordered by the judge.'],
      },
      {
        outcomeName: 'Judgment for Plaintiff (Reduced Damages)',
        probabilityRange: '15% - 25%',
        probabilityValue: 20,
        confidenceLevel: 'moderate',
        keySupportingFactors: ['Clear signature on lease agreement', 'Payment default is admitted'],
        keyNegativeFactors: ['Tenant offset claims are partially successful'],
        assumptions: ['Service is deemed procedurally cured at hearing.'],
      },
    ],
    deadlines: [
      {
        id: 'dl_1',
        label: 'Motion to Dismiss on Notice Grounds',
        dueDate: new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        calculationMethod: 'Prior to filing an Answer, typically within 21 days of notice receipt.',
        ruleReliedOn: 'Rules of Civil Procedure, Rule 12(b)(5)',
        status: 'unverified',
        riskLevel: 'high',
      },
      {
        id: 'dl_2',
        label: 'Written Discovery Disclosures',
        dueDate: new Date(now.getTime() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        calculationMethod: '30 days following the Case Management Conference.',
        ruleReliedOn: 'Rules of Civil Procedure, Rule 26',
        status: 'unverified',
        riskLevel: 'medium',
      },
    ],
    recommendations: [
      {
        id: 'rec_1',
        action: 'File a Special Appearance and Motion to Quash / Dismiss.',
        reason: 'The proof of service is unsigned. Proving notice defect early stops default deadlines and forces settlement leverage.',
        priority: 'high',
        riskIfIgnored: 'Filing a general answer might waive procedural service defects automatically.',
      },
      {
        id: 'rec_2',
        action: 'Acquire official certified mail tracking ledgers.',
        reason: 'Establishes absolute timeline of delivery to disprove early service assumptions.',
        priority: 'medium',
        riskIfIgnored: 'Relying on verbal claims of service is insufficient to survive summary judgment.',
      },
    ],
    sourcesAndAssumptions: [
      'State Civil Procedure Codes on Service of Notices.',
      'Restatement (Second) of Contracts standard breach principles.',
      'Assuming all uploaded emails are authentic and admissible.',
    ],
    escalationRequired: isEviction,
    escalationReason: isEviction
      ? 'CRITICAL ALERT: Landlord-tenant matters carry immediate risk of possession forfeiture or eviction execution. Consult licensed legal aid counsel immediately.'
      : '',
  };
}

function generateFallbackMockReply(character: string, messages: any[], mode: string): string {
  const lastMsg = messages[messages.length - 1]?.text || '';
  const isQuestion = lastMsg.includes('?');

  if (character.toLowerCase().includes('judge')) {
    if (isQuestion) {
      return `The Court has reviewed your question counsel. In this simulation environment, our primary concern is whether you have established an adequate evidentiary foundation for this assertion. I am inclined to sustain any objection based on a lack of personal knowledge unless you can direct my attention to a specific exhibit in the index. What is your position?`;
    }
    return `Let the record reflect that the Court is monitoring this argument closely. Counsel, your point regarding notice delivery is noted, but please address the elements of material breach. How do you respond to the defense's assertion that service did not comply with local rules?`;
  }

  if (character.toLowerCase().includes('king')) {
    return `Your Honor, opposing counsel's position is a masterclass in obfuscation. The statutory language of California Code of Civil Procedure § 1161(2) is absolute: where rent is unpaid and proper notice is served, the right to possession vests. Collateral claims of habitability cannot be raised as a retrospective excuse for contract non-performance when no prior written notice or health citations were issued to my client. We demand an immediate writ of possession and restitution of the premises.`;
  }

  if (character.toLowerCase().includes('marshall')) {
    return `With the Court's permission, we must address the fatal jurisdictional defect at the threshold of this proceeding. It is a foundational principle under CCP § 1162 that service of a three-day statutory notice is a jurisdictional prerequisite. Leaving a critical notice unattended in a public lobby mailbox fails personal and substituted service mandates, rendering this entire unlawful detainer action void ab initio. Under Green v. Superior Court, the landlord's material breach of the implied warranty of habitability entirely abates the rent obligation.`;
  }

  if (character.toLowerCase().includes('counsel') || character.toLowerCase().includes('attorney')) {
    return `That argument is legally deficient and lacks evidentiary support! Under our rules of civil procedure, a party cannot rely on mere self-serving declarations to survive a summary judgment motion. We demand to see the signed returned receipt of delivery. Otherwise, this case should be dismissed immediately.`;
  }

  if (character.toLowerCase().includes('witness')) {
    return `I... I remember receiving an envelope in the mailbox, yes. But no one handed it to me directly. It was just sitting in the lobby on the table. I didn't open it until days later because I didn't know what it was. I was never served personally by any sheriff or private agent. That's the honest truth.`;
  }

  // Mediator/Settlement fallback
  return `Let's take a step back and look at the financial realities. Proceeding to a full trial will cost both sides thousands in legal fees, which may exceed the disputed amount entirely. If we can agree on a structured settlement of 60% with a 3-month payment window, we can sign a mutual release today and end this stress. Is that a compromise both parties can consider?`;
}

function generateFallbackResearch(query: string, caseType?: string, jurisdiction?: string): any {
  const normQuery = query.toLowerCase();
  
  // 1. LANDLORD TENANT - HABITABILITY
  if (normQuery.includes('habit') || normQuery.includes('mold') || normQuery.includes('repair') || (caseType === 'landlord_tenant' && normQuery.includes('defense'))) {
    return {
      summary: "Research results regarding residential implied warranty of habitability in housing disputes. In most jurisdictions, including California, a residential landlord is legally mandated to maintain leased premises in a state fit for human occupancy. This duty is non-waivable and is implied into all residential tenancy agreements.",
      statutes: [
        {
          code: "California Civil Code § 1941",
          title: "Landlord Duty to Maintain Habitability",
          summary: "Requires residential landlords to keep buildings and premises fit for human occupation, including effective waterproofing, plumbing in good working order, hot/cold running water, heating facilities, electrical lighting, and clean sanitary grounds free from mold, rodents, and vermin.",
          application: "Provides the statutory basis for tenant rent withholding or repair-and-deduct remedies when conditions fall below safety codes."
        },
        {
          code: "California Civil Code § 1941.1",
          title: "Standard Tenantable Dwellings and Essential Utilities",
          summary: "Explicitly delineates the components necessary to constitute a tenantable dwelling, including operable doors and windows, structural integrity, and clean common areas free of debris and garbage.",
          application: "Establishes a per-se statutory breach if any enumerated essential system (e.g. main sewer/water pipe) fails for prolonged periods."
        }
      ],
      cases: [
        {
          name: "Green v. Superior Court",
          citation: "10 Cal.3d 616, 517 P.2d 1168, 111 Cal. Rptr. 704 (1974)",
          facts: "A tenant withheld rent due to severe habitability defects including dry rot, plumbing leaks, and code violations. The landlord initiated eviction proceedings. The trial court ruled that habitability defects did not excuse non-payment of rent.",
          issue: "Can a tenant raise the breach of an implied warranty of habitability as an affirmative defense in an unlawful detainer action for non-payment of rent?",
          holding: "Yes. The California Supreme Court held that a residential lease is structurally a contract, and the landlord's covenant to maintain tenantable premises and the tenant's covenant to pay rent are mutually dependent covenants.",
          relevance: "This is the seminal case establishing the habitability defense. Proving substantial defects allows a judicial reduction in rent (abatement) and defeats the eviction claim."
        },
        {
          name: "Javins v. First National Realty Corp.",
          citation: "428 F.2d 1071 (D.C. Cir. 1970)",
          facts: "Tenants withheld rent alleging numerous housing code violations. The landlord sued for possession. The lower courts ruled that the common law rule of caveat emptor (buyer beware) applied to leases.",
          issue: "Does a warranty of habitability exist in residential leases under modern contract principles?",
          holding: "Yes. The federal appeals court ruled that leases must be treated under modern contract doctrines. Tenants seek a package of services, not merely raw land.",
          relevance: "Establishes the federal and persuasive standard that local housing regulations are implicitly written into modern residential lease agreements."
        }
      ],
      doctrines: [
        {
          name: "Implied Warranty of Habitability",
          definition: "An unalterable, non-waivable promise implied into every residential rental agreement that the landlord will keep the premises safe, sanitary, and fit for human life throughout the term of the tenancy.",
          burdenOfProof: "The tenant bears the burden to prove (1) a substantial habitability defect, (2) proper notice of the defect given to the landlord, and (3) that the landlord failed to repair within a reasonable timeframe (typically 30 days is presumed reasonable, but fewer days for emergency utilities)."
        }
      ],
      practiceTips: [
        "Photographic Evidence: Take detailed, timestamped photos of all defects (mold, leaks, rotten structures) immediately. Courts are highly visual and photographs neutralize landlord claims of 'clean premises'.",
        "Written Notice Requirement: Always document notice of defects in writing (certified mail, email, text message logs). Verbal complaints are notoriously difficult to authenticate when the landlord denies receiving them.",
        "Local Housing Inspector Report: Call local code enforcement or health inspectors. A formal government inspection report is a 'golden ticket' exhibit that is highly admissible and difficult for a landlord to contest."
      ]
    };
  }

  // 2. LANDLORD TENANT - NOTICES / EVICTION SERVICE
  if (normQuery.includes('notice') || normQuery.includes('serve') || normQuery.includes('evict') || normQuery.includes('service')) {
    return {
      summary: "Research dossier regarding statutory service rules for pre-litigation notices and eviction summons. Eviction notice statutes are strictly construed. Any minor defect in notice text, timing calculation, or physical service method strips the court of jurisdiction and requires dismissing the action.",
      statutes: [
        {
          code: "California Code of Civil Procedure § 1162",
          title: "Manner of Serving Eviction Notices",
          summary: "Delineates three strict methods of serving pre-litigation notices: (1) Personal service (direct hand-delivery to tenant), (2) Substituted service (leaving copy with person of suitable age at residence/business AND mailing a copy), or (3) 'Post and Mail' (posting copy on conspicuous part of property AND mailing copy, only allowed if personal/substituted service cannot be completed with due diligence).",
          application: "If notice is left in a shared mailbox, lobby table, or basket, it is procedurally defective under CCP 1162 and invalidates the entire eviction."
        },
        {
          code: "California Civil Code § 1946.1",
          title: "Notice Requirements to Terminate Residential Tenancy",
          summary: "Requires landlords to give a minimum 60-day written notice to terminate a month-to-month tenancy if the tenant has resided in the dwelling for a year or more. Only 30 days is required if tenancy was less than a year.",
          application: "Prevents landlords from circumventing security of tenure without appropriate advanced warning."
        }
      ],
      cases: [
        {
          name: "Lamey v. Masciotra",
          citation: "273 Cal. App. 2d 709 (1969)",
          facts: "A landlord posted a notice to quit on the tenant's door but failed to mail a copy as required under substituted service provisions, claiming actual receipt of the notice cured any service defect.",
          issue: "Does actual notice of an eviction notice by the tenant excuse a landlord's failure to strictly comply with statutory service guidelines?",
          holding: "No. The court of appeal ruled that unlawful detainer is a special, summary statutory proceeding. Strict compliance with the service statutes is a jurisdictional prerequisite.",
          relevance: "Establishes that actual receipt of a notice does NOT cure improper service. Defendant can secure dismissal of the entire case on notice service grounds."
        },
        {
          name: "Kwok v. Bergren",
          citation: "130 Cal. App. 3d 344 (1982)",
          facts: "The process server left an eviction notice with a receptionist at the tenant's commercial business but failed to subsequently mail a copy to the tenant's address as required.",
          issue: "Is substituted service complete without secondary mailing of the physical notice?",
          holding: "No. Substituted service requires both physical delivery to a suitable person AND mailing. Failure to perform the mailing step invalidates the service.",
          relevance: "Provides strong precedent for challenging 'lazy service' where notices are left with intermediaries without proper follow-up mailing."
        }
      ],
      doctrines: [
        {
          name: "Strict Statutory Construction of Notice",
          definition: "A jurisdictional doctrine dictating that since unlawful detainer is a summary remedy that deprives a person of shelter, the landlord must strictly conform to every letter of the notice and service statutes.",
          burdenOfProof: "The plaintiff (landlord) bears the absolute burden of proving proper service of a correct notice. The standard is preponderance of the evidence, and must be proven via a sworn proof of service affidavit."
        }
      ],
      practiceTips: [
        "Motion to Quash vs. Demurrer: If notice service is defective, raise this early via a Motion to Quash service of summons. Filing a general answer might waive certain procedural defects, depending on your local state rules.",
        "Inspect the Process Server's Log: Obtain the process server's GPS and timing logs during discovery. Many commercial servers complete 'sewer service' (falsifying hand-delivery) which can be debunked via cell records."
      ]
    };
  }

  // 3. CONTRACT DISPUTES / RECOVERY
  if (normQuery.includes('contract') || normQuery.includes('agree') || normQuery.includes('breach') || normQuery.includes('damages') || caseType === 'contract_dispute') {
    return {
      summary: "Research dossier regarding breach of contract, material default, and foreseeability of consequential damages. Contracts require clear evidence of mutual assent, performance by the claimant, material default, and directly foreseeable damages.",
      statutes: [
        {
          code: "California Civil Code § 3300",
          title: "Measure of Damages for Breach of Contract",
          summary: "Provides that the measure of damages for breach of an obligation arising from contract is the amount which will compensate the party aggrieved for all the detriment proximately caused thereby, or which, in the ordinary course of things, would be likely to result therefrom.",
          application: "Codifies the standard expectation damages rule: putting the non-breaching party in the financial position they would have occupied had performance occurred."
        },
        {
          code: "California Civil Code § 1624",
          title: "Statute of Frauds",
          summary: "Invalidates certain contracts unless they are in writing and signed by the party to be charged. This includes leases for periods longer than one year, and contracts that cannot be performed within one year from their making.",
          application: "Allows a defendant to invalidate verbal agreements that fall within statutory parameters."
        }
      ],
      cases: [
        {
          name: "Hadley v. Baxendale",
          citation: "9 Exch. 341, 156 Eng. Rep. 145 (1854)",
          facts: "A mill shaft broke, and the mill owner contracted a carrier to transport the shaft to an engineer for repair. The carrier delayed delivery, causing the mill to remain closed for several days, losing profits. The carrier did not know the mill would be shut down.",
          issue: "Are lost profits recoverable as damages for breach of contract when the breaching party was unaware of the special circumstances causing the loss?",
          holding: "No. Damages are only recoverable if they arise naturally from the breach OR if special circumstances were explicitly communicated to both parties at contract formation.",
          relevance: "Seminal common law authority limiting 'consequential damages'. To recover special damages (like lost business profits), plaintiff must prove the defendant foresaw or was explicitly warned of the risk."
        },
        {
          name: "Sherwood v. Walker",
          citation: "66 Mich. 568, 33 N.W. 919 (1887)",
          facts: "A cattle breeder agreed to sell a cow believed to be barren for $80. Before delivery, the seller discovered the cow was pregnant (and thus worth over $750) and refused to deliver. The buyer sued.",
          issue: "Can a contract be rescinded based on a mutual mistake regarding a material fact that touches the very nature of the contracted item?",
          holding: "Yes. A mutual mistake regarding a material fact that goes to the whole substance of the agreement allows the affected party to rescind the contract.",
          relevance: "Establishes the defense of 'Mutual Mistake'. If both parties made a core error regarding what was being bought or sold, the contract is voidable."
        }
      ],
      doctrines: [
        {
          name: "Material Breach Doctrine",
          definition: "A contract doctrine stating that only a material breach (one that is substantial and defeats the core purpose of the deal) excuses the non-breaching party from their reciprocal performance duties.",
          burdenOfProof: "The plaintiff must prove by a preponderance of the evidence: (1) contract existence, (2) plaintiff's own substantial performance, (3) defendant's material breach, and (4) resulting quantifiable damages."
        }
      ],
      practiceTips: [
        "Expectation Damages Calculations: Break down contract damages into clean, verifiable mathematical lines. Speculative calculations of 'lost potential business' are routinely thrown out by judges without rigorous invoices or historical sales records.",
        "Integration Clause Audit: Inspect the contract for an 'Integration' or 'Merger' clause. This clause bars any evidence of prior or contemporaneous verbal promises, protecting you against claims of 'oral agreements'."
      ]
    };
  }

  // 4. GENERAL SEARCH FALLBACK
  return {
    summary: `Research dossier compiled regarding "${query}". Results incorporate general principles of American jurisprudence, rules of civil procedure, and contractual frameworks relevant to state and federal litigation.`,
    statutes: [
      {
        code: "U.S. Constitution, Amendment XIV",
        title: "Due Process Clause",
        summary: "Guarantees that no state shall deprive any person of life, liberty, or property, without due process of law.",
        application: "Serves as the foundation for all procedural requirements including proper service of process, notice, and a fair opportunity to be heard prior to civil judgments."
      },
      {
        code: "Federal Rules of Civil Procedure, Rule 12(b)",
        title: "Defenses and Objections - How Presented",
        summary: "Allows a responding party to assert key procedural defenses by motion prior to filing an answer, including lack of jurisdiction, improper venue, and failure to state a claim upon which relief can be granted.",
        application: "Provides the primary mechanism to dispose of legally meritless lawsuits early in the pleadings phase."
      }
    ],
    cases: [
      {
        name: "International Shoe Co. v. Washington",
        citation: "326 U.S. 310 (1945)",
        facts: "A Delaware corporation employed salesmen in Washington state but had no offices there. Washington sued for unpaid unemployment tax. The company claimed Washington courts lacked jurisdiction over an out-of-state corporate entity.",
        issue: "What level of contact must a defendant have with a state to satisfy personal jurisdiction under due process?",
        holding: "Due process requires that the defendant have certain 'minimum contacts' with the state such that maintenance of the suit does not offend traditional notions of fair play and substantial justice.",
        relevance: "Controls questions of whether an out-of-state business can be sued in your client's local court."
      },
      {
        name: "Celotex Corp. v. Catrett",
        citation: "477 U.S. 317 (1986)",
        facts: "A widow sued an asbestos manufacturer for wrongful death. The manufacturer moved for summary judgment, pointing out that the plaintiff produced zero admissible evidence linking their product to the decedent.",
        issue: "Must a moving party support its summary judgment motion with affidavits or materials disproving the opposing claim?",
        holding: "No. The moving party only needs to point out that there is an absence of evidence supporting the nonmoving party's case.",
        relevance: "The critical standard for Summary Judgment. If your opponent has no evidence to support an essential element of their claim, you can win the case before trial."
      }
    ],
    doctrines: [
      {
        name: "Preponderance of the Evidence",
        definition: "The default standard of proof in civil litigation requiring that a claim is more likely true than not (greater than 50% probability).",
        burdenOfProof: "The party asserting the claim (typically the Plaintiff) carries the burden of proving each essential element of their claim by a preponderance of the evidence, unless a higher standard like 'clear and convincing' is specified by statute."
      }
    ],
    practiceTips: [
      "Summary Judgment Readiness: Build your case file with summary judgment in mind from day one. Ensure every fact in your intake sheet is mapped directly to a specific document, photograph, or deposition statement.",
      "Check Local Rules: Never rely solely on statewide codes. Individual county superior courts and specific judges have 'Local Rules' and 'Standing Orders' specifying font size, page limits, and exact filing times. Violating these can result in immediate rejection of pleadings."
    ]
  };
}

function generateFallbackLegalEngine(action: string, caseData: any, payload: any): any {
  const title = caseData.title || 'General Legal Dispute';
  const jurisdiction = caseData.jurisdiction || 'State Superior Court';
  const caseType = caseData.caseType || 'civil_dispute';

  if (action === 'strategy') {
    const stance = payload?.stance || 'defense';
    const isPlaintiff = stance === 'plaintiff';
    return {
      analysis: {
        legalThreshold: `In ${jurisdiction}, a ${caseType.replace('_', ' ')} claim requires proving several essential elements. For the ${isPlaintiff ? 'Plaintiff' : 'Defense'}, the current facts show key strengths around compliance notice documentation, but potential weaknesses in service delivery and physical confirmation.`,
        legalManeuvers: [
          {
            title: isPlaintiff ? "File Complaint and Demand Discovery" : "Motion to Dismiss for Deficient Service",
            description: isPlaintiff 
              ? "Formally file the summons and complaint, and serve immediate discovery requests targeting the opposing party's internal communication ledgers."
              : "Raise lack of personal jurisdiction due to failure of proper hand-delivery under service standards.",
            citations: isPlaintiff ? "Rule 26 & Rule 34 - Discovery Standards" : "Rule 12(b)(5) - Insufficient Service of Process"
          },
          {
            title: isPlaintiff ? "Motion for Partial Summary Judgment" : "Motion to Dismiss for Failure to State a Claim",
            description: isPlaintiff
              ? "Assert that there is no genuine dispute regarding core arrears, moving to establish liability pre-trial."
              : "Argue that the claims as alleged fail to state a cause of action because the required notice conditions precedent were not met.",
            citations: isPlaintiff ? "Rule 56 - Summary Judgment" : "Rule 12(b)(6) - Failure to State a Claim"
          }
        ],
        supportingAuthority: [
          {
            citation: "Resicom LLC v. Sanchez, 412 F.3d 204 (2023)",
            summary: "Reaffirmed that standard landlord-tenant service requires strict adherence to physical notices, and constructive service fails if tenant is in active occupancy."
          },
          {
            citation: "McIntyre v. Metro Housing, 89 Wash. 2d 102 (2019)",
            summary: "Failing to serve notices at the actual unit of residency, or leaving notices in public corridors, renders the subsequent legal filing void ab initio."
          }
        ],
        riskAssessment: [
          {
            opponentArgument: isPlaintiff
              ? "Defendant will assert that service was unverified and the apartment had major habitability issues."
              : "Plaintiff will claim that they made a good-faith attempt to serve and that rent was left unpaid.",
            rebuttal: isPlaintiff
              ? "Demonstrate that notice was delivered to their registered email address, and habitability issues were never documented in writing."
              : "Present certified postal tracking logs proving no delivery was completed, and show contemporaneous repair request logs."
          }
        ]
      }
    };
  }

  if (action === 'dismissal') {
    const opposingArgs = payload?.opposingArguments || 'Arrears exist and service was proper.';
    return {
      analysis: {
        summary: `Opposing arguments: "${opposingArgs}". Under ${jurisdiction} statutes, these arguments fail to address structural notice violations and procedural defects in the case file.`,
        proceduralGrounds: [
          {
            rule: "Procedural Defect: Rule 12(b)(5) (Service)",
            argument: "The process server's affidavit is unnotarized and has contradictory time stamps, indicating service was not performed in compliance with court standards.",
            authority: "Civil Rules of Procedure § 4"
          }
        ],
        substantiveGrounds: [
          {
            rule: "Substantive Defect: Failure of Condition Precedent",
            argument: "The lease agreement requires a 10-day cure notice before filing for arrears. No such cure notice was delivered, making this filing premature.",
            authority: "Restatement of Contracts § 225"
          }
        ],
        recommendation: "Draft and file a Rule 12(b)(5) Motion to Dismiss. This preserves all substantive defenses while forcing opposing counsel to re-serve or dismiss the action."
      }
    };
  }

  if (action === 'draft') {
    const templateType = payload?.templateType || 'motion_dismiss';
    let documentName = 'Motion to Dismiss';
    let draftText = '';

    if (templateType === 'motion_dismiss') {
      documentName = 'MOTION TO DISMISS';
      draftText = `IN THE COURT OF ${jurisdiction.toUpperCase()}\n\n` +
        `MAURICIO SANCHEZ,\n` +
        `  Plaintiff,\n\n` +
        `v.                                              Case No: [PENDING ASSIGNMENT]\n\n` +
        `AHM RESICOM LLC,\n` +
        `  Defendant.\n` +
        `____________________________________/\n\n` +
        `DEFENDANT'S MOTION TO DISMISS UNDER RULE 12(B)(5) AND 12(B)(6)\n\n` +
        `COMES NOW the Defendant, AHM Resicom LLC, by and through counsel, and respectfully moves this Court to dismiss the Plaintiff's Complaint with prejudice. In support, Defendant states as follows:\n\n` +
        `1. STATEMENT OF FACTS\n` +
        `On or about June 2025, the parties entered into a residential agreement. The Complaint alleges non-compliance. However, the summons was left unattended in a shared corridor basket rather than hand-delivered to an authorized representative of Defendant, violating service regulations.\n\n` +
        `2. PROCEDURAL DEFECT (INSUFFICIENT SERVICE)\n` +
        `Under Rule 12(b)(5), dismissal is required when service is deficient. Plaintiff's process server failed to secure personal hand-delivery or certified mail acknowledgement.\n\n` +
        `3. FAILURE TO STATE A CLAIM (RULE 12(B)(6))\n` +
        `Under Rule 12(b)(6), the Complaint fails because it does not state a claim upon which relief can be granted. Specifically, Plaintiff failed to provide the mandatory pre-filing cure notice specified under Section 14 of the written agreement.\n\n` +
        `WHEREFORE, Defendant respectfully requests this Honorable Court to:\n` +
        `a) Dismiss Plaintiff's Complaint with prejudice;\n` +
        `b) Award Defendant reasonable attorney's fees; and\n` +
        `c) Grant such other relief as this Court deems equitable.\n\n` +
        `Dated: July 13, 2026\n\n` +
        `Respectfully submitted,\n` +
        `_________________________\n` +
        `Counsel for Defendant`;
    } else if (templateType === 'complaint') {
      documentName = 'COMPLAINT FOR DAMAGES';
      draftText = `IN THE COURT OF ${jurisdiction.toUpperCase()}\n\n` +
        `MAURICIO SANCHEZ,\n` +
        `  Plaintiff,\n\n` +
        `v.                                              Case No: [PENDING ASSIGNMENT]\n\n` +
        `AHM RESICOM LLC,\n` +
        `  Defendant.\n` +
        `____________________________________/\n\n` +
        `COMPLAINT FOR BREACH OF CONTRACT AND BREACH OF WARRANTY OF HABITABILITY\n\n` +
        `COMES NOW the Plaintiff, Mauricio Sanchez, and files this Complaint against Defendant, AHM Resicom LLC, stating as follows:\n\n` +
        `1. JURISDICTION AND VENUE\n` +
        `This Court has jurisdiction because the real property in dispute is located within this judicial district, and the amount in controversy exceeds the jurisdictional threshold of $5,000.\n\n` +
        `2. STATEMENT OF CLAIM\n` +
        `Starting in June 2025, Plaintiff leased the premises. In January 2026, a severe leak occurred in the ceiling cavity. Defendant failed to repair the leak for months despite repeated written notices, leading to extensive mold growth and breach of the habitability covenant.\n\n` +
        `3. COUNT I - BREACH OF CONTRACT\n` +
        `Defendant breached the lease agreement by failing to maintain structural systems, causing $6,200 in damages and lost use.\n\n` +
        `WHEREFORE, Plaintiff requests judgment against Defendant for compensatory damages, an abatement of rent, and court costs.\n\n` +
        `Dated: July 13, 2026\n\n` +
        `Respectfully submitted,\n` +
        `_________________________\n` +
        `Counsel for Plaintiff`;
    } else if (templateType === 'answer') {
      documentName = 'ANSWER AND AFFIRMATIVE DEFENSES';
      draftText = `IN THE COURT OF ${jurisdiction.toUpperCase()}\n\n` +
        `MAURICIO SANCHEZ,\n` +
        `  Plaintiff,\n\n` +
        `v.                                              Case No: [PENDING ASSIGNMENT]\n\n` +
        `AHM RESICOM LLC,\n` +
        `  Defendant.\n` +
        `____________________________________/\n\n` +
        `DEFENDANT'S ANSWER TO COMPLAINT AND AFFIRMATIVE DEFENSES\n\n` +
        `Defendant, AHM Resicom LLC, answers the Plaintiff's Complaint as follows:\n\n` +
        `1. Defendant ADMITS entering into a lease in June 2025.\n` +
        `2. Defendant DENIES that it failed to repair structural systems, and states that repairs were made within 48 hours of receiving formal written notification.\n` +
        `3. Defendant DENIES each and every other allegation of the Complaint.\n\n` +
        `AFFIRMATIVE DEFENSES\n` +
        `FIRST DEFENSE: Failure of Service of Process.\n` +
        `SECOND DEFENSE: Waiver. Plaintiff waived claims by continuing to occupy the premises and withholding rent without escrowing.\n\n` +
        `WHEREFORE, Defendant requests that the Court enter judgment in its favor.\n\n` +
        `Dated: July 13, 2026\n\n` +
        `Respectfully submitted,\n` +
        `_________________________\n` +
        `Counsel for Defendant`;
    } else {
      documentName = 'DEMAND FOR DISCOVERY & PRODUCTION OF EVIDENCE';
      draftText = `IN THE COURT OF ${jurisdiction.toUpperCase()}\n\n` +
        `MAURICIO SANCHEZ,\n` +
        `  Plaintiff,\n\n` +
        `v.                                              Case No: [PENDING ASSIGNMENT]\n\n` +
        `AHM RESICOM LLC,\n` +
        `  Defendant.\n` +
        `____________________________________/\n\n` +
        `DEFENDANT'S FIRST REQUEST FOR PRODUCTION OF DOCUMENTS TO PLAINTIFF\n\n` +
        `Pursuant to the Rules of Civil Procedure, Defendant requests Plaintiff to produce the following within thirty (30) days:\n\n` +
        `1. All physical, electronic, or digital receipts, ledger sheets, and proof of payments for rent.\n` +
        `2. All written notifications, emails, texts, or logs sent to Defendant regarding habitability or repairs.\n` +
        `3. All photos, expert reports, or inspection certificates regarding alleged mold or pipe leaks.\n\n` +
        `Dated: July 13, 2026\n\n` +
        `Respectfully submitted,\n` +
        `_________________________\n` +
        `Counsel for Defendant`;
    }

    return {
      draft: draftText,
      checklist: [
        "Review the formatting to ensure compliance with local court guidelines.",
        "Ensure all signatures are executed in ink or authorized e-signature form.",
        "Serve a copy on opposing counsel and execute a standard Certificate of Service.",
        "File electronically via the court's approved portal before 11:59 PM on the deadline date."
      ],
      attachments: [
        `Exhibit A: Standard Copy of ${title} Lease Agreement`,
        "Exhibit B: Certified Mail/Delivery Logs",
        "Certificate of Service Form"
      ]
    };
  }

  return { error: 'Unknown action specified' };
}

// Vite Server Configuration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
