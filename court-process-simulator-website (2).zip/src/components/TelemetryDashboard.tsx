/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
} from 'recharts';
import {
  Activity,
  AlertTriangle,
  Bell,
  Check,
  Flame,
  Radio,
  Volume2,
  Cpu,
  Inbox,
  AlertOctagon,
  Sparkles,
  Terminal,
  Gauge,
} from 'lucide-react';
import { SensorMetric, TelemetryAlert } from '../types';

export default function TelemetryDashboard() {
  const [history, setHistory] = useState<SensorMetric[]>([]);
  const [alerts, setAlerts] = useState<TelemetryAlert[]>([]);
  const [systemStatus, setSystemStatus] = useState('Healthy');
  const [activeSensors, setActiveSensors] = useState(5);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Poll telemetry metrics and alerts from server
  const fetchTelemetry = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const res = await fetch('/api/telemetry');
      if (!res.ok) throw new Error('Failed to fetch telemetry streams');
      const data = await res.json();
      setHistory(data.history || []);
      setAlerts(data.alerts || []);
      setSystemStatus(data.systemStatus || 'Healthy');
      setActiveSensors(data.activeSensorsCount || 5);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Telemetry link disconnected');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTelemetry();
    const interval = setInterval(() => {
      fetchTelemetry(true);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Acknowledge an alert
  const acknowledgeAlert = async (alertId: string) => {
    try {
      const res = await fetch('/api/telemetry/acknowledge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId }),
      });
      if (!res.ok) throw new Error('Acknowledge failed');
      const data = await res.json();
      setAlerts(data.alerts);
    } catch (err) {
      console.error(err);
    }
  };

  // Trigger a manual anomaly for testing
  const triggerAnomaly = async (type: 'noise' | 'docket' | 'cpu') => {
    try {
      const res = await fetch('/api/telemetry/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      });
      if (!res.ok) throw new Error('Failed to trigger anomaly');
      fetchTelemetry(true);
    } catch (err) {
      console.error(err);
    }
  };

  const activeCriticalAlerts = alerts.filter((a) => !a.acknowledged);
  const currentMetric = history[history.length - 1] || {
    courtroomNoise: 45,
    docketQueueSize: 18,
    serverCpuLoad: 24,
    filingStreamRate: 3,
    objectionDetections: 0,
  };

  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);

  // Automatically update active terminal logger stream upon receiving telemetry updates
  useEffect(() => {
    if (history.length > 0) {
      const latest = history[history.length - 1];
      const timeStr = new Date().toLocaleTimeString();
      const logsToAdd: string[] = [];

      logsToAdd.push(
        `[${timeStr}] [HEARTBEAT] Core scan ok. Noise: ${latest.courtroomNoise} dB | Docket Queue: ${latest.docketQueueSize} cases | CPU Load: ${latest.serverCpuLoad}%`
      );

      if (latest.objectionDetections > 0) {
        logsToAdd.push(
          `[${timeStr}] [ALGO_DETECTION] High-probability objection acoustic pattern localized in Courtroom B.`
        );
      }

      // Sync active unacknowledged alerts to console
      const activeUnack = alerts.filter((a) => !a.acknowledged);
      if (activeUnack.length > 0) {
        activeUnack.forEach((alert) => {
          logsToAdd.push(
            `[${alert.timestamp || timeStr}] [ANOMALY] [${alert.severity.toUpperCase()}] ${alert.message}`
          );
        });
      }

      setTerminalLogs((prev) => {
        const combined = [...prev, ...logsToAdd];
        // Keep the last 25 entries to preserve memory and keep display snappy
        if (combined.length > 25) {
          return combined.slice(combined.length - 25);
        }
        return combined;
      });
    }
  }, [history, alerts]);

  return (
    <div className="space-y-6" id="telemetry_root">
      {/* Overview Header / System Status */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-xl shadow-2xl relative overflow-hidden bg-grid-cyber">
        <div className="absolute right-0 top-0 w-80 h-80 bg-indigo-500/5 blur-3xl rounded-full" />
        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-indigo-400 animate-pulse-slow" />
            <h2 className="text-xl font-bold text-slate-100 font-display tracking-tight uppercase flex items-center gap-2">
              Virtual Courtroom Operations Desk
              <span className="text-[10px] font-mono bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 px-2 py-0.5 rounded-full uppercase">
                Active Session
              </span>
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-sans max-w-xl">
            A streamlined simulation dashboard visualizing real-time activities inside virtual courtroom chambers. Monitor acoustic levels, digital case filings, live incident events, and docket backlog status.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 relative z-10">
          <div className="bg-slate-950/80 border border-slate-800 px-4 py-2.5 rounded-lg flex items-center gap-2.5 shadow-inner">
            <div className={`w-2.5 h-2.5 rounded-full ${activeCriticalAlerts.length > 0 ? 'bg-rose-500 animate-ping-slow' : 'bg-emerald-500 animate-pulse-slow'}`} />
            <span className="text-xs text-slate-300 font-mono">
              SYSTEM: <span className={`font-bold ${activeCriticalAlerts.length > 0 ? 'text-rose-400 text-glow-rose' : 'text-emerald-400 text-glow-emerald'}`}>{activeCriticalAlerts.length > 0 ? 'ANOMALIES PRESENT' : systemStatus.toUpperCase()}</span>
            </span>
          </div>
          <div className="bg-slate-950/80 border border-slate-800 px-4 py-2.5 rounded-lg text-xs text-slate-300 font-mono shadow-inner">
            CHANNELS CONNECTED: <span className="font-bold text-indigo-400">0{activeSensors}</span>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 text-rose-300 p-4 rounded-xl flex items-center gap-3 text-sm animate-pulse-slow">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          <span>{error}. Check your operations backend server connection.</span>
        </div>
      )}

      {/* Grid of Digital Courtroom Sensors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Courtroom Sound */}
        <div className={`bg-slate-900 border p-5 rounded-xl hover:border-slate-750 transition-all relative group shadow-lg ${currentMetric.courtroomNoise > 80 ? 'border-rose-500/45 border-glow-rose' : 'border-slate-800'}`}>
          <div className="flex justify-between items-start">
            <div className={`p-2.5 rounded-lg transition-colors ${currentMetric.courtroomNoise > 80 ? 'bg-rose-500/10 text-rose-400' : 'bg-indigo-500/10 text-indigo-400 group-hover:bg-indigo-500/20'}`}>
              <Volume2 className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold">Sound Level B</span>
          </div>
          <div className="mt-5 space-y-2">
            <div className="flex items-baseline justify-between">
              <span className={`text-3xl font-extrabold tracking-tight font-mono ${currentMetric.courtroomNoise > 80 ? 'text-rose-400 text-glow-rose' : 'text-slate-100'}`}>
                {currentMetric.courtroomNoise}
              </span>
              <span className="text-xs text-slate-400 font-mono">dB</span>
            </div>
            {/* Custom Meter bar */}
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${currentMetric.courtroomNoise > 80 ? 'bg-rose-500' : 'bg-indigo-500'}`}
                style={{ width: `${Math.min(100, (currentMetric.courtroomNoise / 120) * 100)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">Peak Decibels</span>
              <span className={currentMetric.courtroomNoise > 80 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                {currentMetric.courtroomNoise > 80 ? 'SPIKE DETECTED' : 'QUIET'}
              </span>
            </div>
          </div>
        </div>

        {/* Metric 2: Docket Queue */}
        <div className={`bg-slate-900 border p-5 rounded-xl hover:border-slate-750 transition-all relative group shadow-lg ${currentMetric.docketQueueSize > 35 ? 'border-amber-500/45' : 'border-slate-800'}`}>
          <div className="flex justify-between items-start">
            <div className={`p-2.5 rounded-lg transition-colors ${currentMetric.docketQueueSize > 35 ? 'bg-amber-500/10 text-amber-400' : 'bg-indigo-500/10 text-indigo-400 group-hover:bg-indigo-500/20'}`}>
              <Inbox className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold">Docket Load</span>
          </div>
          <div className="mt-5 space-y-2">
            <div className="flex items-baseline justify-between">
              <span className={`text-3xl font-extrabold tracking-tight font-mono ${currentMetric.docketQueueSize > 35 ? 'text-amber-400 text-glow-amber' : 'text-slate-100'}`}>
                {currentMetric.docketQueueSize}
              </span>
              <span className="text-xs text-slate-400 font-mono">Cases</span>
            </div>
            {/* Custom Meter bar */}
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${currentMetric.docketQueueSize > 35 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                style={{ width: `${Math.min(100, (currentMetric.docketQueueSize / 50) * 100)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">Backlog Queue</span>
              <span className={currentMetric.docketQueueSize > 35 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                {currentMetric.docketQueueSize > 35 ? 'HEAVY DEMAND' : 'OPTIMAL'}
              </span>
            </div>
          </div>
        </div>

        {/* Metric 3: Simulation Engine Load */}
        <div className={`bg-slate-900 border p-5 rounded-xl hover:border-slate-750 transition-all relative group shadow-lg ${currentMetric.serverCpuLoad > 85 ? 'border-rose-500/45 border-glow-rose' : 'border-slate-800'}`}>
          <div className="flex justify-between items-start">
            <div className={`p-2.5 rounded-lg transition-colors ${currentMetric.serverCpuLoad > 85 ? 'bg-rose-500/10 text-rose-400' : 'bg-indigo-500/10 text-indigo-400 group-hover:bg-indigo-500/20'}`}>
              <Cpu className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold">Predictor Compute</span>
          </div>
          <div className="mt-5 space-y-2">
            <div className="flex items-baseline justify-between">
              <span className={`text-3xl font-extrabold tracking-tight font-mono ${currentMetric.serverCpuLoad > 85 ? 'text-rose-400 text-glow-rose' : 'text-slate-100'}`}>
                {currentMetric.serverCpuLoad}
              </span>
              <span className="text-xs text-slate-400 font-mono">% CPU</span>
            </div>
            {/* Custom Meter bar */}
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${currentMetric.serverCpuLoad > 85 ? 'bg-rose-500' : 'bg-indigo-500'}`}
                style={{ width: `${currentMetric.serverCpuLoad}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">Core Node Load</span>
              <span className={currentMetric.serverCpuLoad > 85 ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                {currentMetric.serverCpuLoad > 85 ? 'OVERHEATING' : 'NOMINAL'}
              </span>
            </div>
          </div>
        </div>

        {/* Metric 4: Filing Rate */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-slate-750 transition-all relative group shadow-lg">
          <div className="flex justify-between items-start">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
              <Activity className="w-5 h-5" />
            </div>
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold">Filing Velocity</span>
          </div>
          <div className="mt-5 space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-extrabold tracking-tight font-mono text-slate-100">
                {currentMetric.filingStreamRate}
              </span>
              <span className="text-xs text-slate-400 font-mono">filings/m</span>
            </div>
            {/* Custom Meter bar */}
            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500 bg-emerald-500"
                style={{ width: `${Math.min(100, (currentMetric.filingStreamRate / 20) * 100)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">Live Ingest Rate</span>
              <span className={currentMetric.filingStreamRate > 12 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                {currentMetric.filingStreamRate > 12 ? 'SURGING' : 'STEADY'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Graphs Panel & Terminal Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Graphs and Live Console */}
        <div className="lg:col-span-2 space-y-6">
          {/* Waveform Visualizer */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div className="space-y-0.5">
                <h3 className="text-sm font-bold text-slate-100 font-display uppercase tracking-wide flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-indigo-400" /> Multi-Sensor Waveform Visualizer
                </h3>
                <p className="text-[11px] text-slate-400">Rolling telemetry streams mapped in high-frequency increments.</p>
              </div>
            </div>

            <div className="h-[280px] w-full bg-slate-950/70 p-2 rounded-lg border border-slate-800 flex items-center justify-center">
              {loading && history.length === 0 ? (
                <div className="flex flex-col items-center gap-2 text-slate-500">
                  <Activity className="w-8 h-8 animate-spin" />
                  <span className="text-xs font-mono">Synchronizing telemetry parameters...</span>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={history} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorNoise" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorFilings" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.5} />
                    <XAxis dataKey="timestamp" stroke="#475569" fontSize={9} tickLine={false} fontFamily="monospace" />
                    <YAxis stroke="#475569" fontSize={9} tickLine={false} fontFamily="monospace" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#090d16', borderColor: '#1e293b', borderRadius: '8px', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.5)' }}
                      labelStyle={{ color: '#6366f1', fontFamily: 'monospace', fontWeight: 'bold', fontSize: 10 }}
                      itemStyle={{ fontSize: 11, padding: '2px 0' }}
                    />
                    <Legend wrapperStyle={{ fontSize: 11, fontFamily: 'monospace', paddingTop: 10 }} />
                    <Area
                      name="Acoustic Noise (dB)"
                      type="monotone"
                      dataKey="courtroomNoise"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorNoise)"
                    />
                    <Area
                      name="Compute CPU (%)"
                      type="monotone"
                      dataKey="serverCpuLoad"
                      stroke="#0ea5e9"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorCpu)"
                    />
                    <Area
                      name="Filing Speed"
                      type="monotone"
                      dataKey="filingStreamRate"
                      stroke="#10b981"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorFilings)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Scrolling Terminal Console */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl space-y-3">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-slate-100 font-mono uppercase tracking-widest">
                  Secure Operations Log Terminal
                </h3>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[9px] font-mono text-emerald-400">CONSOLE READY</span>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 h-[180px] overflow-y-auto font-mono text-[10px] space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
              {terminalLogs.length === 0 ? (
                <div className="text-slate-500 italic text-center py-12">
                  Waiting for telemetry scans...
                </div>
              ) : (
                terminalLogs.map((log, idx) => {
                  let colorClass = 'text-slate-300';
                  if (log.includes('[ANOMALY]')) {
                    colorClass = 'text-rose-400 font-semibold';
                  } else if (log.includes('[ALGO_DETECTION]')) {
                    colorClass = 'text-amber-300';
                  } else if (log.includes('[HEARTBEAT]')) {
                    colorClass = 'text-emerald-400/90';
                  }
                  return (
                    <div key={idx} className={`${colorClass} leading-relaxed break-all`}>
                      {log}
                    </div>
                  );
                })
              )}
              <div className="inline-block w-1.5 h-3.5 bg-emerald-400 animate-pulse ml-1 align-middle" />
            </div>
          </div>
        </div>

        {/* Right Column: Incident Stream & Lab Controls */}
        <div className="space-y-6">
          {/* Real-time Incident Alerts Console */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl space-y-4 flex flex-col h-full bg-grid-cyber">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-400" />
                <h3 className="text-xs font-bold text-slate-100 font-display uppercase tracking-wider">
                  Live Incident Stream
                </h3>
              </div>
              {alerts.some((a) => !a.acknowledged) && (
                <span className="bg-rose-500/10 text-rose-400 border border-rose-500/25 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider animate-pulse">
                  Unresolved
                </span>
              )}
            </div>

            <div className="flex-1 overflow-y-auto max-h-[350px] pr-1 space-y-3">
              {alerts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-slate-500 space-y-2.5">
                  <Check className="w-9 h-9 text-emerald-400 p-2 bg-emerald-500/10 rounded-full border border-emerald-500/20" />
                  <p className="text-xs font-mono uppercase tracking-wider text-slate-400">ALL SENSORS NOMINAL</p>
                  <p className="text-[10px] text-slate-500 text-center max-w-[180px]">No anomalies or threshold deviations detected.</p>
                </div>
              ) : (
                alerts
                  .slice()
                  .reverse()
                  .map((alert) => (
                    <div
                      key={alert.id}
                      className={`p-3 rounded-lg border text-xs space-y-2.5 transition-all ${
                        alert.acknowledged
                          ? 'bg-slate-950/40 border-slate-850 text-slate-500'
                          : alert.severity === 'critical'
                          ? 'bg-rose-500/10 border-rose-500/30 text-rose-100 animate-pulse-slow border-glow-rose'
                          : 'bg-amber-500/10 border-amber-500/30 text-amber-100'
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-1.5 font-semibold">
                          {alert.severity === 'critical' ? (
                            <AlertOctagon className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          ) : (
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          )}
                          <span className="font-mono text-[9px] uppercase tracking-wider font-bold">
                            {alert.metric} sensor alert
                          </span>
                        </div>
                        <span className="text-[9px] text-slate-500 font-mono">{alert.timestamp}</span>
                      </div>

                      <p className="leading-relaxed font-sans text-[11px]">{alert.message}</p>

                      {!alert.acknowledged && (
                        <button
                          onClick={() => acknowledgeAlert(alert.id)}
                          className="w-full bg-slate-950 hover:bg-slate-850 border border-slate-750 hover:border-slate-650 text-[10px] text-slate-300 font-mono py-1.5 rounded transition-all flex items-center justify-center gap-1.5"
                        >
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          Resolve Incident
                        </button>
                      )}
                    </div>
                  ))
              )}
            </div>

            {/* Manual Anomaly Generators */}
            <div className="border-t border-slate-800 pt-4 space-y-3">
              <h4 className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-400" /> SIMULATION CONTROL PANEL
              </h4>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => triggerAnomaly('noise')}
                  className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-755 text-[9px] py-2 px-1 rounded text-slate-300 font-mono transition-all font-semibold uppercase tracking-wider hover:text-slate-100 active:scale-95 text-center"
                >
                  Noise Spike
                </button>
                <button
                  onClick={() => triggerAnomaly('docket')}
                  className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-755 text-[9px] py-2 px-1 rounded text-slate-300 font-mono transition-all font-semibold uppercase tracking-wider hover:text-slate-100 active:scale-95 text-center"
                >
                  Docket Surge
                </button>
                <button
                  onClick={() => triggerAnomaly('cpu')}
                  className="bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-755 text-[9px] py-2 px-1 rounded text-slate-300 font-mono transition-all font-semibold uppercase tracking-wider hover:text-slate-100 active:scale-95 text-center"
                >
                  CPU overload
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
