/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Award, 
  Gavel, 
  Scale, 
  Sparkles, 
  CheckCircle2, 
  TrendingUp, 
  Users, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (hash: string) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ 
  isOpen, 
  onClose, 
  onNavigate 
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete(false);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = (autoElite: boolean) => {
    localStorage.setItem('onboarding-completed', 'true');
    if (autoElite) {
      localStorage.setItem('auto-elite-onboarding', 'true');
      onNavigate('#simulator');
    }
    onClose();
  };

  const steps = [
    {
      title: 'Welcome to Legal Simulator',
      subtitle: 'Your Case Preparation & Practice Workspace',
      icon: Scale,
      iconBg: 'bg-indigo-600/20 text-indigo-400 border-indigo-500/30',
      content: (
        <div className="space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed">
            Legal Simulator combines case organization, simulated readiness signals, and a virtual mock courtroom so you can find gaps and practice your strategy before a real hearing.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-slate-950/60 border border-slate-850 rounded-xl space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-black text-indigo-400">
                <TrendingUp className="w-4 h-4" />
                Strategy Signals
              </div>
              <p className="text-[10px] text-slate-400 leading-normal">
                Review simulated readiness, evidence coverage, and argument-risk indicators. These are preparation aids, not court predictions.
              </p>
            </div>
            <div className="p-3 bg-slate-950/60 border border-slate-850 rounded-xl space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-black text-emerald-400">
                <Gavel className="w-4 h-4" />
                Virtual Courtroom
              </div>
              <p className="text-[10px] text-slate-400 leading-normal">
                Present pleadings, raise objections, and cross-examine witnesses inside our Chamber B simulator.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Choose Practice Personas',
      subtitle: 'Test Your Position From Both Sides',
      icon: Award,
      iconBg: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      content: (
        <div className="space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed">
            In the Courtroom Arena, choose fictional practice personas with different argument styles. They are training roles—not real lawyers, credentials, or endorsements.
          </p>
          <div className="space-y-2.5">
            <div className="p-3 bg-slate-950/80 border border-amber-500/20 rounded-xl flex gap-3 items-start">
              <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 font-bold text-xs">
                AK
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-amber-400">Alexander "The Hammer" King, Esq.</span>
                  <span className="text-[8px] bg-amber-500 text-slate-950 font-black px-1 rounded uppercase tracking-wider font-mono">PLT ELITE</span>
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-0.5">
                  A fictional plaintiff-side persona focused on statutory remedies, damages, and demanding cross-examination.
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-950/80 border border-amber-500/20 rounded-xl flex gap-3 items-start">
              <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 font-bold text-xs">
                EM
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-amber-400">Sir Edward Marshall, K.C.</span>
                  <span className="text-[8px] bg-amber-500 text-slate-950 font-black px-1 rounded uppercase tracking-wider font-mono">DEF ELITE</span>
                </div>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-0.5">
                  A fictional defense-side persona focused on procedural defects, proof problems, and alternative explanations.
                </p>
              </div>
            </div>
          </div>
          <button
            onClick={() => handleComplete(true)}
            className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-xs font-black text-slate-100 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer border border-amber-400/20"
          >
            <Sparkles className="w-4 h-4 text-slate-100" />
            Select Advanced Practice Mode
          </button>
        </div>
      )
    },
    {
      title: 'Run Interactive Simulations',
      subtitle: 'Initiate Arguments, Witness Cross-Exam, or Settlement',
      icon: Gavel,
      iconBg: 'bg-indigo-600/20 text-indigo-400 border-indigo-500/30',
      content: (
        <div className="space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed">
            In the Simulator page, select from three practice modes to test different parts of your case:
          </p>
          <div className="grid grid-cols-1 gap-2">
            <div className="flex items-center gap-3 p-2.5 bg-slate-950/40 border border-slate-900 rounded-xl">
              <div className="w-6 h-6 rounded-lg bg-indigo-500/10 border border-indigo-500/10 flex items-center justify-center text-indigo-400 text-[10px] font-mono">1</div>
              <div>
                <span className="text-xs font-bold text-slate-200">Motion Hearings</span>
                <p className="text-[10px] text-slate-400 leading-tight">Argue threshold motions regarding defective physical service notices.</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-2.5 bg-slate-950/40 border border-slate-900 rounded-xl">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/10 flex items-center justify-center text-emerald-400 text-[10px] font-mono">2</div>
              <div>
                <span className="text-xs font-bold text-slate-200">Witness Examinations</span>
                <p className="text-[10px] text-slate-400 leading-tight">Cross-examine opposing caretakers or standard lease tenants with dynamic feedback.</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-2.5 bg-slate-950/40 border border-slate-900 rounded-xl">
              <div className="w-6 h-6 rounded-lg bg-pink-500/10 border border-pink-500/10 flex items-center justify-center text-pink-400 text-[10px] font-mono">3</div>
              <div>
                <span className="text-xs font-bold text-slate-200">Settlement Conferences</span>
                <p className="text-[10px] text-slate-400 leading-tight">Test compromises and financial abated-rent math in alternative dispute resolution.</p>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      title: 'Analyze Predictive Outcomes',
      subtitle: 'Audit Case Strength and Minimize Litigation Risks',
      icon: TrendingUp,
      iconBg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      content: (
        <div className="space-y-4">
          <p className="text-xs text-slate-300 leading-relaxed">
            As your simulation progresses, return to the Dashboard and Outcomes pages to review the preparation signals:
          </p>
          <ul className="space-y-2 text-xs">
            <li className="flex gap-2 items-start text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Verdict Probability Gauge</strong>: A real-time Recharts-based visual indicator blending scenario simulations and merit analytics.</span>
            </li>
            <li className="flex gap-2 items-start text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <span><strong>Case Strength Multipliers</strong>: Pinpoints exactly where your physical evidence (mold photos, rent records) establishes leverage.</span>
            </li>
            <li className="flex gap-2 items-start text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span><strong>Procedural Risk Overlays</strong>: Flags hidden risks like notice cure periods or verbal agreements rules before they hurt your case.</span>
            </li>
          </ul>
        </div>
      )
    }
  ];

  const current = steps[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in" id="onboarding_modal_overlay">
      <div 
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh] animate-slide-up"
        id="onboarding_modal_card"
      >
        {/* Decorative ambient color blur */}
        <div className="absolute right-0 top-0 w-48 h-48 bg-indigo-600/10 rounded-full filter blur-3xl pointer-events-none" />
        <div className="absolute left-0 bottom-0 w-48 h-48 bg-emerald-500/10 rounded-full filter blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="p-6 border-b border-slate-850 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${current.iconBg}`}>
              <current.icon className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[8px] font-mono font-bold text-slate-500 uppercase tracking-widest block">
                Guide Step {currentStep + 1} of {steps.length}
              </span>
              <h2 className="text-sm font-black text-slate-100 uppercase tracking-tight">
                {current.title}
              </h2>
            </div>
          </div>
          <button 
            onClick={() => handleComplete(false)}
            className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-850 border border-slate-850 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            id="onboarding_close_btn"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body content with scrolling if needed */}
        <div className="p-6 overflow-y-auto relative z-10 flex-1 space-y-4">
          <p className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">
            {current.subtitle}
          </p>
          {current.content}
        </div>

        {/* Footer controls */}
        <div className="p-6 border-t border-slate-850 flex items-center justify-between bg-slate-900/50 relative z-10">
          {/* Progress dots */}
          <div className="flex gap-1.5">
            {steps.map((_, i) => (
              <span 
                key={i} 
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  i === currentStep ? 'w-5 bg-indigo-500' : 'w-1.5 bg-slate-800'
                }`}
              />
            ))}
          </div>

          <div className="flex gap-2">
            {currentStep > 0 && (
              <button
                onClick={handlePrev}
                className="px-4 py-2 bg-slate-950 hover:bg-slate-850 border border-slate-850 text-xs font-bold text-slate-300 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
                id="onboarding_prev_btn"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                Back
              </button>
            )}
            
            <button
              onClick={handleNext}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-xs font-bold rounded-xl shadow-lg shadow-indigo-950/20 transition-all flex items-center gap-1.5 cursor-pointer font-black"
              id="onboarding_next_btn"
            >
              {currentStep === steps.length - 1 ? (
                <>
                  Get Started
                  <CheckCircle2 className="w-4 h-4 text-slate-100" />
                </>
              ) : (
                <>
                  Next
                  <ChevronRight className="w-4 h-4 text-slate-100" />
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
