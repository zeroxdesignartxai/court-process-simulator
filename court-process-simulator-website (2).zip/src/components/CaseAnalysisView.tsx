/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import {
  GitMerge,
  Scale,
  Calendar,
  AlertTriangle,
  Award,
  BookOpen,
  Printer,
  ChevronRight,
  UserCheck,
  CheckCircle,
  Clock,
  ExternalLink,
  ShieldAlert,
  Search,
} from 'lucide-react';
import { CaseReport, CourtNode, ClaimDefenseAnalysis, DeadlineItem } from '../types';

interface CaseAnalysisViewProps {
  report: CaseReport;
}

const FLOW_PHASES: CourtNode[] = [
  { id: 'n1', label: 'Demand / Notice Period', description: 'Mandatory pre-filing notices issued to responding party detailing claims and cure period.', status: 'completed', phase: 'pre_filing', requiredFilings: ['Form Notice to Cure', 'Proof of Mail'], deadlines: 'Typically 5, 10, or 30 days prior to filing.' },
  { id: 'n2', label: 'Complaint Draft & Filing', description: 'Drafting the complaint setting forth allegations of fact, claims, and prayer for relief.', status: 'completed', phase: 'pleadings', requiredFilings: ['Summons', 'Verified Complaint', 'Civil Cover Sheet'], deadlines: 'Controlled by Statute of Limitations.' },
  { id: 'n3', label: 'Service of Process', description: 'Delivering Summons and Complaint to Defendant via certified mail or licensed process server.', status: 'current', phase: 'pleadings', requiredFilings: ['Proof of Service Form', 'Affidavit of Process Server'], deadlines: 'Within 90-120 days after filing the complaint.' },
  { id: 'n4', label: 'Response Period (Answer)', description: 'Defendant files an Answer, Affirmative Defenses, or a Motion to Dismiss/Demurrer.', status: 'upcoming', phase: 'pleadings', requiredFilings: ['Answer with Defenses', 'Motion to Dismiss (Rule 12b)'], deadlines: 'Within 21-30 days after completed service.' },
  { id: 'n5', label: 'Case Management Conference', description: 'First appearance before the assigned judge to establish scheduling orders, ADR, and deadlines.', status: 'locked', phase: 'pretrial', requiredFilings: ['Case Management Statement'], deadlines: 'Set by Court Order, usually 90 days post-filing.' },
  { id: 'n6', label: 'Written & Oral Discovery', description: 'Exchanging Interrogatories, Requests for Production, and conducting depositions under oath.', status: 'locked', phase: 'discovery', requiredFilings: ['Interrogatories', 'Requests for Production', 'Deposition Notices'], deadlines: 'Completed 30 days prior to initial trial date.' },
  { id: 'n7', label: 'Summary Judgment Motion', description: 'Filing dispositive motions to resolve the dispute prior to trial based on undisputed discovery facts.', status: 'locked', phase: 'pretrial', requiredFilings: ['Motion for Summary Judgment', 'Statement of Undisputed Facts'], deadlines: 'Must be filed at least 75 days before trial.' },
  { id: 'n8', label: 'Bench / Jury Trial', description: 'Opening statements, presentation of physical exhibits, witness cross-examinations, and closing arguments.', status: 'locked', phase: 'trial', requiredFilings: ['Trial Briefs', 'Exhibit Lists', 'Proposed Jury Instructions'], deadlines: 'Scheduled by the Assigned Judge.' },
  { id: 'n9', label: 'Judgment & Cost Petitions', description: 'Tribunal issues final judgment order. Parties submit cost ledgers and petitions for attorney fees.', status: 'locked', phase: 'judgment', requiredFilings: ['Proposed Judgment Order', 'Bill of Costs', 'Fee Motion'], deadlines: 'Filing usually required within 14-30 days of verdict.' },
  { id: 'n10', label: 'Appellate Review', description: 'Filing a notice of appeal challenging legal rulings or trial court procedural decisions.', status: 'locked', phase: 'appeal', requiredFilings: ['Notice of Appeal', 'Appellate Docketing Statement'], deadlines: 'Strictly enforced 30 days from entry of final judgment.' },
];

export default function CaseAnalysisView({ report }: CaseAnalysisViewProps) {
  const [activeTab, setActiveTab] = useState<'flow' | 'merits' | 'outcomes' | 'deadlines' | 'actions'>('flow');
  const [selectedNode, setSelectedNode] = useState<CourtNode>(FLOW_PHASES[2]); // Default on Service of Process
  const [deadlineList, setDeadlineList] = useState<DeadlineItem[]>(report.deadlines);

  // Sync deadline list when report updates
  useEffect(() => {
    setDeadlineList(report.deadlines);
  }, [report.deadlines]);

  // Toggle deadline verification status
  const toggleDeadlineStatus = (id: string) => {
    setDeadlineList((prev) =>
      prev.map((dl) =>
        dl.id === id
          ? {
              ...dl,
              status: dl.status === 'verified' ? 'unverified' : 'verified',
            }
          : dl
      )
    );
  };

  // Generate printable Docket Pack (Printer friendly print trigger)
  const triggerPrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="analysis_view_root">
      {/* Risk Alert / Escalate Warning */}
      {report.escalationRequired && (
        <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 p-4 rounded-xl flex items-start gap-3 text-sm animate-pulse-slow">
          <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5 animate-bounce" />
          <div className="space-y-1">
            <span className="font-bold uppercase tracking-wider text-rose-200 text-xs">Escalation Threshold Exceeded</span>
            <p className="leading-relaxed text-xs">{report.escalationReason}</p>
          </div>
        </div>
      )}

      {/* Case Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="bg-indigo-500/10 text-indigo-400 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
              ANALYSIS DOSSIER
            </span>
            <span className="text-xs text-slate-500">Quality Index: {report.informationQualityRating}%</span>
          </div>
          <h2 className="text-lg font-bold text-slate-100 font-sans tracking-tight">Predicted Case Model & Process Map</h2>
          <p className="text-xs text-slate-400">
            Current status: <span className="font-semibold text-indigo-300">{report.proceduralStatusSummary}</span>
          </p>
        </div>

        <button
          onClick={triggerPrint}
          className="bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 py-2 px-4 rounded-lg transition-colors flex items-center gap-2 font-mono"
        >
          <Printer className="w-4 h-4 text-slate-400" />
          Print Pack / Save PDF
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-800 overflow-x-auto gap-2">
        {[
          { id: 'flow', label: 'Litigation Flowchart', icon: GitMerge },
          { id: 'merits', label: 'IRAC Merits Matrix', icon: Scale },
          { id: 'outcomes', label: 'Scenario Outcomes', icon: Award },
          { id: 'deadlines', label: 'Deadline Calendar', icon: Calendar },
          { id: 'actions', label: 'Priority Plan', icon: CheckCircle },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all shrink-0 ${
              activeTab === tab.id
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Panels */}

      {/* TAB 1: Visual Court Flowchart */}
      {activeTab === 'flow' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4">
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-slate-100">Interactive Court Process Map</h3>
              <p className="text-xs text-slate-400">
                Click on any node in the civil litigation flowchart below to view procedural requirements, filings, and waiver rules.
              </p>
            </div>

            {/* Scrollable Flowchart container */}
            <div className="overflow-x-auto pb-4 pr-2">
              <div className="flex items-center gap-3 min-w-[900px] py-4">
                {FLOW_PHASES.map((node, index) => {
                  const isCurrent = node.status === 'current';
                  const isCompleted = node.status === 'completed';
                  const isSelected = selectedNode?.id === node.id;

                  return (
                    <div key={node.id} className="flex items-center gap-3">
                      {/* Flow Node Card */}
                      <button
                        onClick={() => setSelectedNode(node)}
                        className={`w-44 text-left p-3 rounded-lg border transition-all ${
                          isSelected
                            ? 'bg-indigo-600/10 border-indigo-500 ring-2 ring-indigo-500/20'
                            : isCurrent
                            ? 'bg-amber-500/10 border-amber-500 animate-pulse'
                            : isCompleted
                            ? 'bg-emerald-500/5 border-emerald-500/50'
                            : 'bg-slate-950 border-slate-800 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-1">
                          <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                            isCompleted ? 'bg-emerald-500/10 text-emerald-400' : isCurrent ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {node.phase.replace('_', ' ')}
                          </span>
                          {isCompleted && <span className="text-emerald-400 text-xs font-bold">✓</span>}
                        </div>
                        <h4 className="mt-2 text-xs font-bold text-slate-200 leading-tight truncate">{node.label}</h4>
                        <p className="text-[10px] text-slate-400 truncate mt-1">{node.description}</p>
                      </button>

                      {/* Connection Arrow */}
                      {index < FLOW_PHASES.length - 1 && (
                        <ChevronRight className={`w-4 h-4 shrink-0 ${isCompleted ? 'text-emerald-500' : 'text-slate-700'}`} />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Node detail drawer card */}
          {selectedNode && (
            <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl grid grid-cols-1 md:grid-cols-3 gap-5 animate-slide-up">
              <div className="md:col-span-2 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-indigo-500/10 text-indigo-400 px-2.5 py-1 rounded-md uppercase font-mono font-bold">
                    Stage Details
                  </span>
                  <h3 className="text-base font-bold text-slate-100">{selectedNode.label}</h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{selectedNode.description}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="bg-slate-900 border border-slate-800/80 p-3 rounded-lg space-y-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Required Court Filings</span>
                    <ul className="text-xs text-slate-300 list-disc pl-4 space-y-1">
                      {selectedNode.requiredFilings.map((f, i) => <li key={i}>{f}</li>)}
                    </ul>
                  </div>
                  <div className="bg-slate-900 border border-slate-800/80 p-3 rounded-lg space-y-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Calculation & Deadlines</span>
                    <p className="text-xs text-slate-300 leading-relaxed">{selectedNode.deadlines}</p>
                  </div>
                </div>
              </div>

              <div className="bg-indigo-950/20 border border-indigo-500/20 p-4 rounded-xl space-y-3 flex flex-col justify-between">
                <div className="space-y-1">
                  <span className="text-[10px] text-indigo-400 font-mono uppercase tracking-widest font-bold">Eldorado Advisory</span>
                  <h4 className="text-xs font-bold text-slate-200">Waiver & Forfeiture Warning</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Neglecting or answering out of sequence in this stage can lead to immediate forfeiture of jurisdictional service defects. Special Appearances are required in many courts before responding.
                  </p>
                </div>
                <a
                  href="#intake_form_root"
                  className="bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-xs py-1.5 px-3 rounded text-center transition-colors font-medium flex items-center justify-center gap-1.5"
                >
                  Edit Evidentiary Foundations <Clock className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Claims & Defenses IRAC Matrix */}
      {activeTab === 'merits' && (
        <div className="space-y-6 animate-fade-in">
          {/* Executive Overview */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-3">
            <div className="flex items-center gap-2 text-indigo-400">
              <Scale className="w-5 h-5" />
              <h3 className="text-sm font-semibold text-slate-100">Claims & Counter-Defenses Merits Summary</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{report.overview}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {report.claimsAndDefenses.map((cd, index) => (
              <div key={index} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                {/* Header info */}
                <div className="flex justify-between items-start border-b border-slate-800 pb-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        cd.type === 'claim' ? 'bg-indigo-500/10 text-indigo-400' : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        {cd.type.toUpperCase()}
                      </span>
                      <h4 className="text-sm font-bold text-slate-100">{cd.name}</h4>
                    </div>
                    <span className="text-xs text-slate-500 font-mono">IRAC Analysis Matrix</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-mono text-slate-400">Strength Index</span>
                    <div className="flex items-baseline gap-1">
                      <span className="text-lg font-bold font-mono text-slate-100">{cd.overallScore}%</span>
                    </div>
                  </div>
                </div>

                {/* IRAC Core */}
                <div className="space-y-3 text-xs leading-relaxed">
                  <div className="space-y-1">
                    <span className="font-mono text-[10px] text-indigo-400 uppercase tracking-widest font-bold">Issue</span>
                    <p className="text-slate-200">{cd.iracIssue}</p>
                  </div>
                  <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800/80">
                    <span className="font-mono text-[10px] text-indigo-400 uppercase tracking-widest font-bold">Controlling Rule & Authority</span>
                    <p className="text-slate-300 italic">{cd.iracRule}</p>
                  </div>
                </div>

                {/* Elements details */}
                <div className="space-y-3 pt-2">
                  <span className="font-mono text-[10px] text-slate-400 uppercase tracking-widest font-bold">Substantive Elements under Burden</span>
                  {cd.elements.map((el, elIdx) => (
                    <div key={elIdx} className="bg-slate-950 rounded-lg p-3 border border-slate-800/80 space-y-2">
                      <div className="flex justify-between items-center border-b border-slate-900 pb-1.5">
                        <span className="text-xs font-bold text-slate-200">{el.elementName}</span>
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] text-slate-400 font-mono">Score:</span>
                          <span className="text-xs font-bold font-mono text-slate-200">{el.strengthScore}%</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 italic">{el.definition}</p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-[11px]">
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-emerald-400">Supporting Factual Assets</span>
                          <ul className="list-disc pl-3 text-slate-400 space-y-0.5">
                            {el.supportingFacts.map((sf, i) => <li key={i}>{sf}</li>)}
                          </ul>
                        </div>
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-amber-400">Contesting Allegations</span>
                          <ul className="list-disc pl-3 text-slate-400 space-y-0.5">
                            {el.opposingFacts.map((of, i) => <li key={i}>{of}</li>)}
                          </ul>
                        </div>
                      </div>

                      {/* Evidence & Admissibility details */}
                      <div className="border-t border-slate-900/80 pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-[10px]">
                        <div className="space-y-0.5 text-slate-400">
                          <span className="text-slate-500 font-medium">Exhibits:</span> {el.supportingEvidence.join(', ') || 'None Linked'}
                        </div>
                        {el.admissibilityConcerns.length > 0 && (
                          <div className="text-rose-400/90 flex gap-1 items-start">
                            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                            <span>Admissibility: {el.admissibilityConcerns.join(', ')}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Scenario Outcomes */}
      {activeTab === 'outcomes' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-1">
            <h3 className="text-sm font-semibold text-slate-100">Probabilistic Outcome Matrix</h3>
            <p className="text-xs text-slate-400">
              Simulation estimates based on rules-of-procedure weights and current record elements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {report.outcomes.map((out, idx) => (
              <div key={idx} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex justify-between items-start gap-2">
                    <h4 className="text-xs font-bold text-slate-100 leading-snug">{out.outcomeName}</h4>
                    <span className="text-xs text-indigo-400 font-mono font-bold shrink-0">{out.probabilityRange}</span>
                  </div>

                  {/* Custom progress bar */}
                  <div className="h-2 bg-slate-950 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-500 rounded-full"
                      style={{ width: `${out.probabilityValue}%` }}
                    />
                  </div>

                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-800/80 text-xs text-slate-300 space-y-2">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Key Supporting Factors</span>
                      <ul className="list-disc pl-3 text-slate-400 space-y-0.5">
                        {out.keySupportingFactors.map((f, i) => <li key={i}>{f}</li>)}
                      </ul>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Risks & Pitfalls</span>
                      <ul className="list-disc pl-3 text-slate-400 space-y-0.5">
                        {out.keyNegativeFactors.map((f, i) => <li key={i}>{f}</li>)}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-500 flex justify-between items-center">
                  <span>Confidence: <strong className="text-slate-300 uppercase font-mono">{out.confidenceLevel}</strong></span>
                  <span className="font-mono">Assumptions active</span>
                </div>
              </div>
            ))}
          </div>

          {/* Detailed Side-by-Side Adversarial Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" id="adversarial_bento_grid">
            
            {/* PLAINTIFF CARD */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-5 shadow-lg flex flex-col justify-between" id="plaintiff_arg_card">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h4 className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-emerald-400" />
                    Plaintiff Arguments
                  </h4>
                  <span className="text-[9px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full uppercase">
                    Offense
                  </span>
                </div>
                
                {/* Legal Theory */}
                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Core Legal Theory</span>
                  <p className="text-xs font-medium text-slate-200 leading-relaxed bg-slate-950/40 p-3 rounded-xl border border-slate-950">
                    {report.plaintiffArguments.legalTheory}
                  </p>
                </div>

                {/* Key Facts Grounding (Valid Info) */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Factual Grounding (Verified Information)</span>
                  {report.plaintiffArguments.keyFacts && report.plaintiffArguments.keyFacts.length > 0 ? (
                    <ul className="space-y-1.5 text-[11px] text-slate-300">
                      {report.plaintiffArguments.keyFacts.map((fact, idx) => (
                        <li key={idx} className="flex gap-2 items-start bg-slate-950/20 p-2 rounded-lg border border-slate-950/40">
                          <span className="text-emerald-500 font-bold shrink-0">✓</span>
                          <span>{fact}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No key facts specified.</p>
                  )}
                </div>

                {/* Exhibits / Key Evidence */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Physical Exhibits & Evidence</span>
                  {report.plaintiffArguments.keyEvidence && report.plaintiffArguments.keyEvidence.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">
                      {report.plaintiffArguments.keyEvidence.map((ev, idx) => (
                        <span key={idx} className="text-[10px] font-mono font-bold bg-slate-950 text-slate-300 border border-slate-850 px-2.5 py-1 rounded-lg flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
                          {ev}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No key evidence specified.</p>
                  )}
                </div>

                {/* Anticipated Objections & Counter-Arguments */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold text-amber-500 uppercase tracking-wider">Anticipated Objections & Rebuttals</span>
                  {report.plaintiffArguments.objections && report.plaintiffArguments.objections.length > 0 ? (
                    <ul className="space-y-1.5 text-[11px] text-slate-300">
                      {report.plaintiffArguments.objections.map((obj, idx) => (
                        <li key={idx} className="flex gap-2 items-start bg-amber-950/5 p-2 rounded-lg border border-amber-950/20">
                          <span className="text-amber-500 font-bold shrink-0">⚠</span>
                          <span className="italic">{obj}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No procedural objections registered.</p>
                  )}
                </div>
              </div>

              {/* Citations & Authorities */}
              <div className="space-y-1.5 pt-4 border-t border-slate-800 mt-4">
                <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Statutory Cites & Legal Authorities</span>
                <div className="flex flex-wrap gap-1.5">
                  {report.plaintiffArguments.authorities && report.plaintiffArguments.authorities.length > 0 ? (
                    report.plaintiffArguments.authorities.map((auth, idx) => (
                      <span key={idx} className="text-[10px] font-semibold bg-slate-950 text-indigo-300 border border-indigo-950/50 px-2 py-0.5 rounded">
                        {auth}
                      </span>
                    ))
                  ) : (
                    <span className="text-[11px] text-slate-500 italic">No specific authorities cited.</span>
                  )}
                </div>
              </div>
            </div>

            {/* DEFENDANT CARD */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-5 shadow-lg flex flex-col justify-between" id="defendant_arg_card">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h4 className="text-xs font-black text-amber-400 uppercase tracking-widest flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-amber-400" />
                    Defendant Arguments
                  </h4>
                  <span className="text-[9px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full uppercase">
                    Defense
                  </span>
                </div>
                
                {/* Legal Theory */}
                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Core Legal Theory</span>
                  <p className="text-xs font-medium text-slate-200 leading-relaxed bg-slate-950/40 p-3 rounded-xl border border-slate-950">
                    {report.defendantArguments.legalTheory}
                  </p>
                </div>

                {/* Key Facts Grounding (Valid Info) */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Factual Grounding (Verified Information)</span>
                  {report.defendantArguments.keyFacts && report.defendantArguments.keyFacts.length > 0 ? (
                    <ul className="space-y-1.5 text-[11px] text-slate-300">
                      {report.defendantArguments.keyFacts.map((fact, idx) => (
                        <li key={idx} className="flex gap-2 items-start bg-slate-950/20 p-2 rounded-lg border border-slate-950/40">
                          <span className="text-emerald-500 font-bold shrink-0">✓</span>
                          <span>{fact}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No key facts specified.</p>
                  )}
                </div>

                {/* Exhibits / Key Evidence */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Physical Exhibits & Evidence</span>
                  {report.defendantArguments.keyEvidence && report.defendantArguments.keyEvidence.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">
                      {report.defendantArguments.keyEvidence.map((ev, idx) => (
                        <span key={idx} className="text-[10px] font-mono font-bold bg-slate-950 text-slate-300 border border-slate-850 px-2.5 py-1 rounded-lg flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
                          {ev}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No key evidence specified.</p>
                  )}
                </div>

                {/* Anticipated Objections & Counter-Arguments */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono font-bold text-amber-500 uppercase tracking-wider">Anticipated Objections & Rebuttals</span>
                  {report.defendantArguments.objections && report.defendantArguments.objections.length > 0 ? (
                    <ul className="space-y-1.5 text-[11px] text-slate-300">
                      {report.defendantArguments.objections.map((obj, idx) => (
                        <li key={idx} className="flex gap-2 items-start bg-amber-950/5 p-2 rounded-lg border border-amber-950/20">
                          <span className="text-amber-500 font-bold shrink-0">⚠</span>
                          <span className="italic">{obj}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">No procedural objections registered.</p>
                  )}
                </div>
              </div>

              {/* Citations & Authorities */}
              <div className="space-y-1.5 pt-4 border-t border-slate-800 mt-4">
                <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Statutory Cites & Legal Authorities</span>
                <div className="flex flex-wrap gap-1.5">
                  {report.defendantArguments.authorities && report.defendantArguments.authorities.length > 0 ? (
                    report.defendantArguments.authorities.map((auth, idx) => (
                      <span key={idx} className="text-[10px] font-semibold bg-slate-950 text-indigo-300 border border-indigo-950/50 px-2 py-0.5 rounded">
                        {auth}
                      </span>
                    ))
                  ) : (
                    <span className="text-[11px] text-slate-500 italic">No specific authorities cited.</span>
                  )}
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB 4: Deadline Tracker Calendar */}
      {activeTab === 'deadlines' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-slate-100">Procedural Deadline Calculator</h3>
              <p className="text-xs text-slate-400">
                Calculations based on state civil practice standards, counting court vs. calendar days and service methods.
              </p>
            </div>
            <div className="bg-slate-950 border border-slate-800 text-[10px] font-mono py-1 px-2.5 rounded text-slate-400 uppercase tracking-wider">
              Verification Warning Enabled
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                  <th className="p-4 font-semibold">Deadline Event</th>
                  <th className="p-4 font-semibold">Due Date</th>
                  <th className="p-4 font-semibold">Calculation Standard</th>
                  <th className="p-4 font-semibold">Rule Authority</th>
                  <th className="p-4 font-semibold">Risk Rating</th>
                  <th className="p-4 font-semibold text-right">Verify Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {deadlineList.map((dl) => (
                  <tr key={dl.id} className="hover:bg-slate-950/40 transition-colors text-slate-300">
                    <td className="p-4 font-bold text-slate-200">{dl.label}</td>
                    <td className="p-4 font-mono text-indigo-300">{dl.dueDate}</td>
                    <td className="p-4 leading-relaxed">{dl.calculationMethod}</td>
                    <td className="p-4 text-slate-400 italic">{dl.ruleReliedOn}</td>
                    <td className="p-4">
                      <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded uppercase ${
                        dl.riskLevel === 'high'
                          ? 'bg-rose-500/10 text-rose-400'
                          : dl.riskLevel === 'medium'
                          ? 'bg-amber-500/10 text-amber-400'
                          : 'bg-emerald-500/10 text-emerald-400'
                      }`}>
                        {dl.riskLevel}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <button
                        onClick={() => toggleDeadlineStatus(dl.id)}
                        className={`text-[10px] font-mono px-2.5 py-1 rounded transition-colors ${
                          dl.status === 'verified'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-slate-950 text-slate-500 border border-slate-800 hover:text-slate-300'
                        }`}
                      >
                        {dl.status === 'verified' ? '✓ Verified' : 'Unverified'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: Actions Priority checklist */}
      {activeTab === 'actions' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-1">
            <h3 className="text-sm font-semibold text-slate-100">Action Plan Priority Log</h3>
            <p className="text-xs text-slate-400">
              Prioritized tactical tasks generated to secure evidence foundations, satisfy deadlines, and enhance case leverage.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {report.recommendations.map((rec) => (
              <div key={rec.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-start gap-3 justify-between shadow-sm hover:border-slate-700 transition-all">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded uppercase tracking-wider ${
                      rec.priority === 'high' ? 'bg-rose-500/10 text-rose-400' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {rec.priority} Priority
                    </span>
                    <h4 className="text-xs font-bold text-slate-200">{rec.action}</h4>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{rec.reason}</p>
                  <p className="text-[10px] leading-relaxed text-rose-400/80 bg-slate-950 p-2 rounded border border-slate-850">
                    <strong>Forfeiture Risk if Ignored:</strong> {rec.riskIfIgnored}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Printable Pack Hidden View (rendered only during print execution) */}
      <div className="hidden print:block space-y-8 bg-white text-slate-900 p-8 font-serif" id="print-pack-pdf">
        <div className="border-b-4 border-slate-900 pb-4 text-center">
          <h1 className="text-2xl font-black uppercase tracking-tight">ELDORADO COURT PROCESS MEMORANDUM</h1>
          <p className="text-xs uppercase font-mono tracking-widest text-slate-500 mt-1">AI-Powered Legal Decision-Support System</p>
        </div>

        <div className="grid grid-cols-2 gap-4 text-xs font-mono border-b border-slate-300 py-4">
          <div>
            <strong>CASE TITLE:</strong> {report.overview.split('.')[0]}
          </div>
          <div>
            <strong>DATE GENERATED:</strong> {new Date().toLocaleDateString()}
          </div>
          <div>
            <strong>CASE TYPE:</strong> {report.overview.split(' ')[2] || 'Substantive Dispute'}
          </div>
          <div>
            <strong>DOCKET CONFIDENCE:</strong> High-Grade Simulation
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-bold border-b border-slate-800 pb-1">1. Factual Summary</h2>
          <p className="text-xs leading-relaxed">{report.overview}</p>
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-bold border-b border-slate-800 pb-1">2. Claims & Defense Strengths</h2>
          {report.claimsAndDefenses.map((cd, i) => (
            <div key={i} className="text-xs space-y-2">
              <div className="flex justify-between font-bold">
                <span>{cd.name} ({cd.type.toUpperCase()})</span>
                <span>Strength: {cd.overallScore}%</span>
              </div>
              <p className="italic">{cd.iracIssue}</p>
              <p>{cd.iracRule}</p>
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <h2 className="text-lg font-bold border-b border-slate-800 pb-1">3. Estimated Outcome Probability</h2>
          {report.outcomes.map((out, i) => (
            <div key={i} className="text-xs flex justify-between">
              <span>{out.outcomeName}</span>
              <strong>{out.probabilityRange}</strong>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-400 pt-4 text-center text-[10px] text-slate-500">
          * Notice: This is an automated decision-support memorandum. It does not replace the counsel of a licensed attorney. *
        </div>
      </div>
    </div>
  );
}
