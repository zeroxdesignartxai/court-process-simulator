/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import {
  Briefcase,
  Users,
  Calendar,
  FileText,
  ShieldAlert,
  ArrowRight,
  ArrowLeft,
  Plus,
  Trash2,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { CaseIntake, Party, FactItem, EvidenceItem } from '../types';

interface CaseIntakeFormProps {
  onSimulate: (caseData: CaseIntake) => void;
  isSimulating: boolean;
}

// Pre-packaged realistic scenarios for frictionless simulation
const PRESETS = {
  contract_dispute: {
    title: 'Acme Software Dev Delivery Failure Dispute',
    caseType: 'contract_dispute' as const,
    jurisdiction: 'State of California (County of San Francisco)',
    courtName: 'Superior Court of San Francisco',
    currentStage: 'Pleadings / Answer Period',
    amountInControversy: 45000,
    remedyRequested: 'Compensatory Damages of $45,000 for non-performance and outstanding invoices.',
    parties: [
      { id: 'p_1', name: 'Acme Web Solutions Inc.', role: 'plaintiff' as const, type: 'organization' as const, represented: true, claims: ['Breach of Contract'], defenses: [] },
      { id: 'p_2', name: 'DevCorp Consulting Ltd.', role: 'defendant' as const, type: 'organization' as const, represented: true, claims: [], defenses: ['Constructive Failure', 'Improper Specifications Waiver'] },
    ],
    facts: [
      { id: 'f_1', description: 'Acme and DevCorp executed a signed software delivery agreement on June 15, 2025.', date: '2025-06-15', status: 'admitted' as const, evidenceIds: ['ev_1'] },
      { id: 'f_2', description: 'Acme paid a 40% initial deposit of $18,000 to DevCorp.', date: '2025-06-20', status: 'admitted' as const, evidenceIds: ['ev_3'] },
      { id: 'f_3', description: 'DevCorp missed the final production launch deadline of November 30, 2025.', date: '2025-11-30', status: 'disputed' as const, evidenceIds: ['ev_2'] },
      { id: 'f_4', description: 'Acme sent a formal notice of default via email giving 15 days to cure.', date: '2025-12-05', status: 'admitted' as const, evidenceIds: ['ev_4'] },
      { id: 'f_5', description: 'DevCorp alleges Acme failed to provide key API endpoints, preventing compilation.', date: '2025-11-10', status: 'disputed' as const, evidenceIds: [] },
    ],
    evidence: [
      { id: 'ev_1', title: 'Executed Software Contract', description: 'Final PDF contract signed by both CEOs containing timeline milestones.', type: 'document' as const, relevance: 'Establishes existence of agreement and delivery schedule.', source: 'Acme corporate database', disclosed: true, hearsayConcern: false, authenticityStatus: 'verified' as const, supportsClaims: ['Breach of Contract'] },
      { id: 'ev_2', title: 'Github Commit History Ledger', description: 'Exported git logs showing zero updates from DevCorp engineers after Oct 2025.', type: 'other' as const, relevance: 'Proves non-performance and failure to meet milestone deadlines.', source: 'Acme private Github repo', disclosed: true, hearsayConcern: false, authenticityStatus: 'verified' as const, supportsClaims: ['Breach of Contract'] },
      { id: 'ev_3', title: 'Wire Transfer Confirmation Receipt', description: 'Bank confirmation of $18,000 deposit wire paid to DevCorp.', type: 'document' as const, relevance: 'Proves plaintiff performed initial financial obligation.', source: 'Chase Bank Records', disclosed: true, hearsayConcern: false, authenticityStatus: 'verified' as const, supportsClaims: [] },
      { id: 'ev_4', title: 'Default Notice Email Exchange', description: 'Printed email chain containing Acme notice and DevCorp acknowledging delay.', type: 'email' as const, relevance: 'Proves notice of default was delivered and received.', source: 'Acme Outlook backup', disclosed: true, hearsayConcern: true, authenticityStatus: 'verified' as const, supportsClaims: ['Breach of Contract'] },
    ],
    claims: ['Breach of Written Agreement', 'Unjust Enrichment (Deposit Forfeiture)'],
    defenses: ['Failure of Condition Precedent (API Access Delay)', 'Mutual Estoppel'],
  },
  landlord_tenant: {
    title: 'Eldorado Realty Eviction Dispute (Oak St Apartment)',
    caseType: 'landlord_tenant' as const,
    jurisdiction: 'State of Illinois (Cook County Housing Division)',
    courtName: 'Circuit Court of Cook County',
    currentStage: 'Pre-filing Notice Period',
    amountInControversy: 8400,
    remedyRequested: 'Possession of Premises, Ejection of Tenant, and Unpaid Rent of $8,400.',
    parties: [
      { id: 'p_1', name: 'Eldorado Realty Corp', role: 'plaintiff' as const, type: 'organization' as const, represented: true, claims: ['Eviction', 'Unpaid Rent'], defenses: [] },
      { id: 'p_2', name: 'Marcus Sterling', role: 'defendant' as const, type: 'individual' as const, represented: false, claims: [], defenses: ['Defective Service of 5-Day Notice', 'Breach of Warranty of Habitability'] },
    ],
    facts: [
      { id: 'f_1', description: 'Marcus Sterling signed a 1-year apartment lease at $2,100 per month.', date: '2025-01-01', status: 'admitted' as const, evidenceIds: ['ev_1'] },
      { id: 'f_2', description: 'Tenant failed to pay full rent for March, April, and May 2026.', date: '2026-03-01', status: 'admitted' as const, evidenceIds: ['ev_3'] },
      { id: 'f_3', description: 'Landlord alleges hand-delivering a 5-day Notice to Quit to the tenant directly.', date: '2026-05-10', status: 'disputed' as const, evidenceIds: ['ev_2'] },
      { id: 'f_4', description: 'Tenant filed complaints regarding water leaks and structural mold in the kitchen.', date: '2026-02-15', status: 'admitted' as const, evidenceIds: ['ev_4'] },
      { id: 'f_5', description: 'The notice was allegedly left in a shared common lobby box, not served in-hand.', date: '2026-05-11', status: 'disputed' as const, evidenceIds: [] },
    ],
    evidence: [
      { id: 'ev_1', title: 'Oak Street Apartment Lease', description: '12-month residential lease signed by Eldorado agent and Marcus Sterling.', type: 'document' as const, relevance: 'Proves tenancy terms, rent rate ($2,100), and late payment covenants.', source: 'Landlord Records', disclosed: true, hearsayConcern: false, authenticityStatus: 'verified' as const, supportsClaims: ['Eviction'] },
      { id: 'ev_2', title: '5-Day Notice Proof of Service', description: 'An unsigned affidavit of service from a building maintenance worker.', type: 'document' as const, relevance: 'Crucial for jurisdiction; plaintiff alleges service compliance.', source: 'Maintenance Logbook', disclosed: true, hearsayConcern: true, authenticityStatus: 'disputed' as const, supportsClaims: ['Eviction'] },
      { id: 'ev_3', title: 'Rent Ledger Summary Report', description: 'Internal billing ledger showing $0 payments received for three consecutive cycles.', type: 'document' as const, relevance: 'Establishes arrears quantum of $8,400.', source: 'Eldorado accounting software', disclosed: true, hearsayConcern: false, authenticityStatus: 'verified' as const, supportsClaims: ['Unpaid Rent'] },
      { id: 'ev_4', title: 'Water Leak and Mold Photo Journal', description: 'High-definition photographs showing active mold and wall damage in the unit kitchen.', type: 'photo' as const, relevance: 'Supports Tenant constructive eviction / rent abatement defense.', source: 'Tenant mobile phone', disclosed: true, hearsayConcern: false, authenticityStatus: 'verified' as const, supportsClaims: [] },
    ],
    claims: ['Residential Eviction for Non-Payment', 'Recovery of Accrued Back-Rent'],
    defenses: ['Jurisdictional Defective Notice Service', 'Constructive Eviction (Breach of Habitability)'],
  },
};

export default function CaseIntakeForm({ onSimulate, isSimulating }: CaseIntakeFormProps) {
  const [activeStep, setActiveStep] = useState(1);
  const [caseData, setCaseData] = useState<CaseIntake>(PRESETS.contract_dispute);

  // Helper to load presets
  const applyPreset = (presetKey: keyof typeof PRESETS) => {
    setCaseData(PRESETS[presetKey]);
  };

  // Field update helpers
  const updateMainField = (key: keyof CaseIntake, value: any) => {
    setCaseData((prev) => ({ ...prev, [key]: value }));
  };

  // Parties CRUD
  const addParty = () => {
    const newParty: Party = {
      id: Math.random().toString(36).substring(7),
      name: '',
      role: 'defendant',
      type: 'individual',
      represented: false,
      claims: [],
      defenses: [],
    };
    setCaseData((prev) => ({ ...prev, parties: [...prev.parties, newParty] }));
  };

  const removeParty = (id: string) => {
    setCaseData((prev) => ({ ...prev, parties: prev.parties.filter((p) => p.id !== id) }));
  };

  const updateParty = (id: string, updated: Partial<Party>) => {
    setCaseData((prev) => ({
      ...prev,
      parties: prev.parties.map((p) => (p.id === id ? { ...p, ...updated } : p)),
    }));
  };

  // Facts CRUD
  const addFact = () => {
    const newFact: FactItem = {
      id: Math.random().toString(36).substring(7),
      description: '',
      date: new Date().toISOString().split('T')[0],
      status: 'allegation',
      evidenceIds: [],
    };
    setCaseData((prev) => ({ ...prev, facts: [...prev.facts, newFact] }));
  };

  const removeFact = (id: string) => {
    setCaseData((prev) => ({ ...prev, facts: prev.facts.filter((f) => f.id !== id) }));
  };

  const updateFact = (id: string, updated: Partial<FactItem>) => {
    setCaseData((prev) => ({
      ...prev,
      facts: prev.facts.map((f) => (f.id === id ? { ...f, ...updated } : f)),
    }));
  };

  // Evidence CRUD
  const addEvidence = () => {
    const newEvidence: EvidenceItem = {
      id: Math.random().toString(36).substring(7),
      title: '',
      description: '',
      type: 'document',
      relevance: '',
      source: '',
      disclosed: false,
      hearsayConcern: false,
      authenticityStatus: 'unverified',
      supportsClaims: [],
    };
    setCaseData((prev) => ({ ...prev, evidence: [...prev.evidence, newEvidence] }));
  };

  const removeEvidence = (id: string) => {
    setCaseData((prev) => ({ ...prev, evidence: prev.evidence.filter((e) => e.id !== id) }));
  };

  const updateEvidence = (id: string, updated: Partial<EvidenceItem>) => {
    setCaseData((prev) => ({
      ...prev,
      evidence: prev.evidence.map((e) => (e.id === id ? { ...e, ...updated } : e)),
    }));
  };

  // Simple string array fields
  const handleStringArrayChange = (field: 'claims' | 'defenses', index: number, value: string) => {
    const array = [...caseData[field]];
    array[index] = value;
    updateMainField(field, array);
  };

  const addStringArrayItem = (field: 'claims' | 'defenses') => {
    updateMainField(field, [...caseData[field], '']);
  };

  const removeStringArrayItem = (field: 'claims' | 'defenses', index: number) => {
    updateMainField(
      field,
      caseData[field].filter((_, i) => i !== index)
    );
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6" id="intake_form_root">
      {/* Preset Quick Select bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span className="text-xs font-semibold text-slate-200">Pre-populate Realistic Simulation Profiles:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => applyPreset('contract_dispute')}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
              caseData.caseType === 'contract_dispute'
                ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            Software Breach
          </button>
          <button
            onClick={() => applyPreset('landlord_tenant')}
            className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
              caseData.caseType === 'landlord_tenant'
                ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            Eviction Dispute
          </button>
        </div>
      </div>

      {/* Steps Indicator Progress bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        {[
          { step: 1, label: 'Case Basics', icon: Briefcase },
          { step: 2, label: 'Parties Involved', icon: Users },
          { step: 3, label: 'Timeline & Facts', icon: Calendar },
          { step: 4, label: 'Evidence Audit', icon: FileText },
          { step: 5, label: 'Legal Claims', icon: ShieldAlert },
        ].map(({ step, label, icon: Icon }) => (
          <button
            key={step}
            onClick={() => setActiveStep(step)}
            className={`flex items-center gap-2 text-xs transition-colors ${
              activeStep === step
                ? 'text-indigo-400 font-semibold'
                : activeStep > step
                ? 'text-emerald-400 font-medium'
                : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <span className={`w-6 h-6 rounded-full flex items-center justify-center border text-[10px] font-mono ${
              activeStep === step
                ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300'
                : activeStep > step
                ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400'
                : 'bg-slate-950 border-slate-800'
            }`}>
              {step}
            </span>
            <span className="hidden md:inline">{label}</span>
          </button>
        ))}
      </div>

      {/* STEP 1: Case Identification */}
      {activeStep === 1 && (
        <div className="space-y-4 animate-fade-in">
          <div className="border-l-2 border-indigo-500 pl-3">
            <h3 className="text-sm font-semibold text-slate-200">Step 1: Case Identification & Forum</h3>
            <p className="text-xs text-slate-400">Identify the fundamental nature of the dispute and the controlling tribunal.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400">Case Reference Title</label>
              <input
                type="text"
                value={caseData.title}
                onChange={(e) => updateMainField('title', e.target.value)}
                placeholder="E.g., Acme Corp Contractor Delivery Failure"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400">Case Type Module</label>
              <select
                value={caseData.caseType}
                onChange={(e) => updateMainField('caseType', e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="contract_dispute">Contractual Breach Dispute</option>
                <option value="landlord_tenant">Landlord-Tenant & Eviction</option>
                <option value="small_claims">Small Claims Action</option>
                <option value="debt_collection">Debt Collection Defense</option>
                <option value="employment">Employment & Wage Dispute</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400">Controlling Jurisdiction</label>
              <input
                type="text"
                value={caseData.jurisdiction}
                onChange={(e) => updateMainField('jurisdiction', e.target.value)}
                placeholder="E.g., State of California (San Francisco County)"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400">Filing Court or Tribunal Name</label>
              <input
                type="text"
                value={caseData.courtName}
                onChange={(e) => updateMainField('courtName', e.target.value)}
                placeholder="E.g., Superior Court of California"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400">Current Procedural Phase</label>
              <input
                type="text"
                value={caseData.currentStage}
                onChange={(e) => updateMainField('currentStage', e.target.value)}
                placeholder="E.g., Pre-filing notice, Answer period, Discovery"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-400">Amount in Controversy ($)</label>
              <input
                type="number"
                value={caseData.amountInControversy}
                onChange={(e) => updateMainField('amountInControversy', parseInt(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>

            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs text-slate-400">Requested Legal Remedy / Objective</label>
              <textarea
                rows={2}
                value={caseData.remedyRequested}
                onChange={(e) => updateMainField('remedyRequested', e.target.value)}
                placeholder="E.g., Complete rescission, compensatory damages of $45,000, or eviction order."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: Party Profiles */}
      {activeStep === 2 && (
        <div className="space-y-4 animate-fade-in">
          <div className="border-l-2 border-indigo-500 pl-3 flex justify-between items-center">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">Step 2: Adversarial Party Roster</h3>
              <p className="text-xs text-slate-400">Configure legal profiles, roles, and legal representation status of litigants.</p>
            </div>
            <button
              onClick={addParty}
              className="flex items-center gap-1.5 text-xs bg-indigo-600 hover:bg-indigo-500 text-slate-100 px-3 py-1.5 rounded-lg transition-colors font-medium"
            >
              <Plus className="w-4 h-4" /> Add Party
            </button>
          </div>

          <div className="space-y-4">
            {caseData.parties.map((party) => (
              <div key={party.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 relative">
                <button
                  onClick={() => removeParty(party.id)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-rose-400 transition-colors p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Party Legal Name</label>
                    <input
                      type="text"
                      value={party.name}
                      onChange={(e) => updateParty(party.id, { name: e.target.value })}
                      placeholder="E.g., John Doe LLC"
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Litigant Role</label>
                    <select
                      value={party.role}
                      onChange={(e) => updateParty(party.id, { role: e.target.value as 'plaintiff' | 'defendant' })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="plaintiff">Plaintiff (Claimant)</option>
                      <option value="defendant">Defendant (Responding)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Entity Type</label>
                    <select
                      value={party.type}
                      onChange={(e) => updateParty(party.id, { type: e.target.value as 'individual' | 'organization' })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="individual">Individual</option>
                      <option value="organization">Corporate / Organization</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Legal Representation</label>
                    <select
                      value={party.represented ? 'true' : 'false'}
                      onChange={(e) => updateParty(party.id, { represented: e.target.value === 'true' })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="true">Represented by Counsel</option>
                      <option value="false">Self-Represented (Pro Se)</option>
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STEP 3: Facts Timeline */}
      {activeStep === 3 && (
        <div className="space-y-4 animate-fade-in">
          <div className="border-l-2 border-indigo-500 pl-3 flex justify-between items-center">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">Step 3: Factual Timeline Chronology</h3>
              <p className="text-xs text-slate-400">Log material facts in chronological order, labeling conflict/admission status.</p>
            </div>
            <button
              onClick={addFact}
              className="flex items-center gap-1.5 text-xs bg-indigo-600 hover:bg-indigo-500 text-slate-100 px-3 py-1.5 rounded-lg transition-colors font-medium"
            >
              <Plus className="w-4 h-4" /> Add Event Fact
            </button>
          </div>

          <div className="space-y-3">
            {caseData.facts.map((fact) => (
              <div key={fact.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-4 items-start relative">
                <button
                  onClick={() => removeFact(fact.id)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-rose-400 transition-colors p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="w-full md:w-48 space-y-1 shrink-0">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider">Date of Occurrence</label>
                  <input
                    type="date"
                    value={fact.date}
                    onChange={(e) => updateFact(fact.id, { date: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>

                <div className="flex-1 space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider">Factual Allegation Statement</label>
                  <input
                    type="text"
                    value={fact.description}
                    onChange={(e) => updateFact(fact.id, { description: e.target.value })}
                    placeholder="E.g., Defendant received the default notice but did not respond..."
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="w-full md:w-40 space-y-1 shrink-0">
                  <label className="text-[10px] text-slate-500 uppercase tracking-wider">Admission Status</label>
                  <select
                    value={fact.status}
                    onChange={(e) => updateFact(fact.id, { status: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="admitted">Admitted Fact (Undisputed)</option>
                    <option value="disputed">Disputed Fact (Contested)</option>
                    <option value="allegation">Unverified Allegation</option>
                    <option value="unknown">Unknown / Needs Proof</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STEP 4: Evidence Audit */}
      {activeStep === 4 && (
        <div className="space-y-4 animate-fade-in">
          <div className="border-l-2 border-indigo-500 pl-3 flex justify-between items-center">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">Step 4: Evidence Foundation & Audit</h3>
              <p className="text-xs text-slate-400">Detail proposed exhibits, checking for authenticity status and hearsay concerns.</p>
            </div>
            <button
              onClick={addEvidence}
              className="flex items-center gap-1.5 text-xs bg-indigo-600 hover:bg-indigo-500 text-slate-100 px-3 py-1.5 rounded-lg transition-colors font-medium"
            >
              <Plus className="w-4 h-4" /> Add Evidence Item
            </button>
          </div>

          <div className="space-y-4">
            {caseData.evidence.map((exhibit) => (
              <div key={exhibit.id} className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 relative">
                <button
                  onClick={() => removeEvidence(exhibit.id)}
                  className="absolute right-3 top-3 text-slate-500 hover:text-rose-400 transition-colors p-1"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Exhibit / Document Title</label>
                    <input
                      type="text"
                      value={exhibit.title}
                      onChange={(e) => updateEvidence(exhibit.id, { title: e.target.value })}
                      placeholder="E.g., Certified Mail Return Receipt"
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Exhibit Type</label>
                    <select
                      value={exhibit.type}
                      onChange={(e) => updateEvidence(exhibit.id, { type: e.target.value as any })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="document">Written Document (PDF/Contract)</option>
                      <option value="email">Email Communications</option>
                      <option value="message">SMS / Text Message Ledger</option>
                      <option value="photo">Photographic Exhibit</option>
                      <option value="audio">Audio Transcript</option>
                      <option value="witness_statement">Witness Affidavit</option>
                      <option value="other">Physical / Other Exhibit</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Authenticity Status</label>
                    <select
                      value={exhibit.authenticityStatus}
                      onChange={(e) => updateEvidence(exhibit.id, { authenticityStatus: e.target.value as any })}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="verified">Verified Authenticity</option>
                      <option value="unverified">Unverified (Unsigned/Melted metadata)</option>
                      <option value="disputed">Disputed / Challenged</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 uppercase tracking-wider">Legal Relevance to Claims</label>
                    <input
                      type="text"
                      value={exhibit.relevance}
                      onChange={(e) => updateEvidence(exhibit.id, { relevance: e.target.value })}
                      placeholder="E.g., Proves service of 5-day notice was compiled correctly."
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-500 uppercase tracking-wider">Hearsay Vulnerability</label>
                      <select
                        value={exhibit.hearsayConcern ? 'true' : 'false'}
                        onChange={(e) => updateEvidence(exhibit.id, { hearsayConcern: e.target.value === 'true' })}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                      >
                        <option value="false">No (Exception applies)</option>
                        <option value="true">Yes (Hearsay concern present)</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-500 uppercase tracking-wider">Disclosed in Discovery</label>
                      <select
                        value={exhibit.disclosed ? 'true' : 'false'}
                        onChange={(e) => updateEvidence(exhibit.id, { disclosed: e.target.value === 'true' })}
                        className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                      >
                        <option value="true">Yes, Disclosed</option>
                        <option value="false">No, Withheld</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STEP 5: Claims and Defenses */}
      {activeStep === 5 && (
        <div className="space-y-4 animate-fade-in">
          <div className="border-l-2 border-indigo-500 pl-3">
            <h3 className="text-sm font-semibold text-slate-200">Step 5: Claims & Assertive Defenses</h3>
            <p className="text-xs text-slate-400">Map specific legal claims and affirmative defenses to be evaluated by the process simulator.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Claims list */}
            <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Plaintiff Claims</span>
                <button
                  onClick={() => addStringArrayItem('claims')}
                  className="text-[10px] text-slate-300 bg-slate-900 hover:bg-slate-800 px-2 py-1 rounded border border-slate-800"
                >
                  + Add Claim
                </button>
              </div>
              <div className="space-y-2">
                {caseData.claims.map((claim, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      type="text"
                      value={claim}
                      onChange={(e) => handleStringArrayChange('claims', idx, e.target.value)}
                      placeholder="E.g., Breach of Written Lease"
                      className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      onClick={() => removeStringArrayItem('claims', idx)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Defenses list */}
            <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Defendant Defenses</span>
                <button
                  onClick={() => addStringArrayItem('defenses')}
                  className="text-[10px] text-slate-300 bg-slate-900 hover:bg-slate-800 px-2 py-1 rounded border border-slate-800"
                >
                  + Add Defense
                </button>
              </div>
              <div className="space-y-2">
                {caseData.defenses.map((defense, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      type="text"
                      value={defense}
                      onChange={(e) => handleStringArrayChange('defenses', idx, e.target.value)}
                      placeholder="E.g., Defective Notice of Eviction"
                      className="flex-1 bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      onClick={() => removeStringArrayItem('defenses', idx)}
                      className="text-slate-500 hover:text-rose-400 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Buttons and Simulation Trigger */}
      <div className="flex items-center justify-between border-t border-slate-800 pt-4">
        <button
          onClick={() => setActiveStep((prev) => Math.max(1, prev - 1))}
          disabled={activeStep === 1}
          className="flex items-center gap-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 px-4 py-2 rounded-lg disabled:opacity-40 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Previous
        </button>

        {activeStep < 5 ? (
          <button
            onClick={() => setActiveStep((prev) => Math.min(5, prev + 1))}
            className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-500 text-xs text-slate-100 px-4 py-2 rounded-lg transition-colors"
          >
            Next Step <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={() => onSimulate(caseData)}
            disabled={isSimulating}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-xs text-slate-100 px-6 py-2.5 rounded-lg transition-colors font-semibold shadow-lg shadow-emerald-900/20 disabled:opacity-50"
          >
            {isSimulating ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white font-mono" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Processing Case Merits...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" /> Trigger Legal Process Simulation
              </>
            )}
          </button>
        )}
      </div>

      <div className="bg-slate-950/50 p-3.5 rounded-lg border border-slate-800/80 text-[10px] text-slate-400 flex items-start gap-2 leading-relaxed">
        <HelpCircle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <span>
          <strong>Decision-Support Notice:</strong> Eldorado Simulator renders educational procedural calculations and case evaluations based on probabilistic criteria. It does not issue binding judicial mandates, offer actual legal advice, or secure court outcomes.
        </span>
      </div>
    </div>
  );
}
