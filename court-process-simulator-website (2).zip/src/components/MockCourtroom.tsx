/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Gavel,
  MessageSquare,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  Send,
  RefreshCw,
  Scale,
  ShieldCheck,
  Users,
  Mic,
  FileText,
  Volume2,
  Award,
  Trophy,
  Zap,
  Shield,
  Crown,
} from 'lucide-react';
import { CourtroomMessage, CaseIntake } from '../types';

interface MockCourtroomProps {
  currentCase: CaseIntake | null;
}

const CHARACTER_PERSONAS = [
  {
    id: 'vance',
    name: 'Hon. Judge Arthur Vance',
    role: 'judge',
    mode: 'hearing',
    description: 'Formal, objective, and authoritative. Thoroughly questions statutory rules, notice adequacy, and evidence foundations with classical judicial skepticism.',
    tier: 'standard',
    stats: { winRate: 'N/A', style: 'Impartial Protocol', rating: '92', weapon: 'Jurisdictional Demurrers' }
  },
  {
    id: 'reynolds',
    name: 'Counsel Sarah Reynolds',
    role: 'plaintiff_counsel',
    mode: 'examination',
    description: 'Standard opposing attorney. Professional and assertive. Probes ledger balances, timeline consistency, and standard contract obligations.',
    tier: 'standard',
    stats: { winRate: '74%', style: 'Aggressive Standard', rating: '75', weapon: 'Rent Ledger Audits' }
  },
  {
    id: 'king',
    name: 'Alexander "The Hammer" King, Esq.',
    role: 'plaintiff_counsel',
    mode: 'examination',
    description: 'The World’s Ultimate Plaintiff Trial Attorney. Undefeated 98.6% trial track record. Employs laser-focused statutory penalties, ruthless cross-examinations, and crushing pre-trial pressure to force absolute concessions.',
    tier: 'elite',
    stats: { winRate: '98.6%', style: 'Surgical Heavy Offense', rating: '99', weapon: 'Relentless Statutory Restitution' }
  },
  {
    id: 'sterling',
    name: 'Marcus Sterling (Witness)',
    role: 'witness',
    mode: 'examination',
    description: 'A nervous but honest building tenant. Testifies strictly based on direct physical observations of apartment quality and shared lobby notice placement.',
    tier: 'standard',
    stats: { winRate: 'N/A', style: 'Factual Observations', rating: '70', weapon: 'On-the-ground Truth' }
  },
  {
    id: 'brooks',
    name: 'Mediator Elaine Brooks',
    role: 'defendant_counsel',
    mode: 'settlement',
    description: 'Standard defense mediator. Practical and compromising. Helps evaluate settlement math, risk allocations, and BATNA solutions.',
    tier: 'standard',
    stats: { winRate: '65%', style: 'Pragmatic Compromise', rating: '72', weapon: 'Mutual Release Settlements' }
  },
  {
    id: 'marshall',
    name: 'Sir Edward Marshall, K.C.',
    role: 'defendant_counsel',
    mode: 'settlement',
    description: 'The World’s Ultimate Defense Trial Counsel. Global legal legend (99.1% defense rate). Demolishes procedural service errors, triggers statutory dismissals, and builds impenetrable warranty of habitability walls.',
    tier: 'elite',
    stats: { winRate: '99.1%', style: 'Impenetrable Procedural Guard', rating: '99', weapon: 'Notice Service Nullification' }
  },
];

export default function MockCourtroom({ currentCase }: MockCourtroomProps) {
  const [plaintiffTier, setPlaintiffTier] = useState<'standard' | 'elite'>('standard');
  const [defendantTier, setDefendantTier] = useState<'standard' | 'elite'>('standard');
  const [activePersona, setActivePersona] = useState(CHARACTER_PERSONAS[0]);
  const [mode, setMode] = useState<'hearing' | 'examination' | 'settlement'>('hearing');
  const [messages, setMessages] = useState<CourtroomMessage[]>([
    {
      id: 'init_1',
      sender: 'judge',
      text: 'This Court is now in session. Counsel, you may proceed with your arguments regarding service of process. Address whether the physical summons was hand-delivered or merely posted.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  useEffect(() => {
    const isEliteOnboarding = localStorage.getItem('auto-elite-onboarding') === 'true';
    if (isEliteOnboarding) {
      setPlaintiffTier('elite');
      setDefendantTier('elite');
      const kingPersona = CHARACTER_PERSONAS.find((c) => c.id === 'king') || CHARACTER_PERSONAS[0];
      setActivePersona(kingPersona);
      setMode(kingPersona.mode as any);
      setMessages([
        {
          id: 'init_elite',
          sender: 'plaintiff_counsel',
          text: 'The statutory bounds of this case are absolute. Alexander King, Esq. here. Under California CCP § 1161(2), your rent default is crystal clear, and no collateral excuses will hold water. Explain why the full balance remains outstanding, or yield the keys immediately.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        }
      ]);
      localStorage.removeItem('auto-elite-onboarding');
    }
  }, []);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Handle character change and reset chat
  const handlePersonaChange = (charId: string) => {
    const persona = CHARACTER_PERSONAS.find((c) => c.id === charId) || CHARACTER_PERSONAS[0];
    setActivePersona(persona);
    setMode(persona.mode as any);

    // Initial greeting based on role
    let greeting = '';
    if (persona.id === 'vance') {
      greeting = `This tribunal is now in session. I have reviewed the pleadings on file. Counsel, please present your legal arguments regarding ${currentCase?.title || 'the disputed performance'}. Address notice sufficiency first.`;
    } else if (persona.id === 'reynolds') {
      greeting = 'Counsel Sarah Reynolds here. Your contractual default is fully documented in the ledger. How do you plan to justify withholding these payments?';
    } else if (persona.id === 'king') {
      greeting = 'The statutory bounds of this case are absolute. Alexander King, Esq. here. Under California CCP § 1161(2), your rent default is crystal clear, and no collateral excuses will hold water. Explain why the full balance remains outstanding, or yield the keys immediately.';
    } else if (persona.id === 'sterling') {
      greeting = 'I... I am ready to tell the truth. I will answer your questions about the conditions of the apartment and the notice in the lobby.';
    } else if (persona.id === 'brooks') {
      greeting = 'Welcome both parties. Elaine Brooks here. Litigation is a negative-sum game that drains both parties. Let us find a sensible, practical compromise zone today.';
    } else if (persona.id === 'marshall') {
      greeting = 'Sir Edward Marshall here for the defense. Let us dispense with the rhetoric and look at the structural threshold: your statutory notice service is procedurally fatal under CCP § 1162. Let us evaluate your compliance, or are you prepared to dismiss this defective petition right now?';
    } else {
      greeting = 'Tribunal active. Counsel, proceed.';
    }

    setMessages([
      {
        id: Math.random().toString(),
        sender: persona.role as any,
        text: greeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  const togglePlaintiffTier = (tier: 'standard' | 'elite') => {
    setPlaintiffTier(tier);
    const targetId = tier === 'standard' ? 'reynolds' : 'king';
    handlePersonaChange(targetId);
  };

  const toggleDefendantTier = (tier: 'standard' | 'elite') => {
    setDefendantTier(tier);
    const targetId = tier === 'standard' ? 'brooks' : 'marshall';
    handlePersonaChange(targetId);
  };

  // Submit chat dialogue to backend
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: CourtroomMessage = {
      id: Math.random().toString(),
      sender: 'user',
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInputText('');
    setIsTyping(true);
    setError(null);

    try {
      const res = await fetch('/api/mock-court', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          character: activePersona.name,
          messages: updatedMessages,
          currentCase,
        }),
      });

      if (!res.ok) throw new Error('Mock courtroom link disconnected');

      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender: activePersona.role as any,
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'AI Simulation error');
    } finally {
      setIsTyping(false);
    }
  };

  // Preset objections helper
  const triggerObjection = (objectionText: string) => {
    setInputText(`Objection, Counsel! ${objectionText}`);
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-5 gap-6" id="courtroom_simulator_root">
      {/* Courtroom Blueprint Interactive Floorplan */}
      <div className="xl:col-span-2 space-y-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shadow-xl relative overflow-hidden group">
          {/* Subtle grid pattern overlay */}
          <div 
            className="absolute inset-0 opacity-[0.06] pointer-events-none bg-[linear-gradient(rgba(14,165,233,0.3)_1px,transparent_1px),linear-gradient(90deg,rgba(14,165,233,0.3)_1px,transparent_1px)] bg-[size:12px_12px]"
          />

          <div className="relative z-10 space-y-4">
            {/* Blueprint Header */}
            <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                <h3 className="text-xs font-bold text-slate-100 tracking-wider font-mono uppercase">
                  Chamber B Floorplan Blueprint
                </h3>
              </div>
              <span className="text-[9px] font-mono text-indigo-400 bg-indigo-950/40 border border-indigo-500/30 px-1.5 py-0.5 rounded uppercase">
                Interactive Map
              </span>
            </div>

            {/* Chamber Schematic Map Container */}
            <div className="relative bg-slate-950/80 border border-slate-850 rounded-xl p-4 min-h-[350px] flex flex-col justify-between font-mono text-slate-400 select-none">
                       {/* Outer Coordinates & Blueprint labels */}
              <div className="absolute top-2.5 left-3 text-[8px] text-indigo-500/30 font-mono tracking-widest">CHAMBER_SECURE // ROOM_B02</div>
              <div className="absolute bottom-2.5 right-3 text-[8px] text-indigo-500/30 font-mono tracking-widest">ELEVATION_DAIS: +0.60M</div>

              {/* STAGE 1: THE BENCH DAIS (TOP) */}
              <div className="grid grid-cols-3 gap-2">
                {/* 1. Automated Clerk Station */}
                <div className="border border-slate-800/60 bg-slate-900/5 rounded-xl p-2 flex flex-col justify-between h-16 text-center opacity-40">
                  <span className="text-[7px] text-slate-500 font-bold uppercase tracking-wider leading-none">Clerk Desk</span>
                  <Volume2 className="w-3.5 h-3.5 text-slate-600 mx-auto" />
                  <span className="text-[6px] font-mono text-slate-500 truncate">REC LIVE // 48KHZ</span>
                </div>

                {/* 2. Judge Vance's Bench (Interactive) */}
                <button
                  type="button"
                  onClick={() => handlePersonaChange('vance')}
                  className={`border rounded-xl p-2 flex flex-col justify-between h-16 text-center transition-all relative ${
                    activePersona.id === 'vance'
                      ? 'border-indigo-500 bg-indigo-950/20 shadow-[0_0_15px_rgba(99,102,241,0.3)] text-indigo-200'
                      : 'border-slate-800 bg-slate-950 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {activePersona.id === 'vance' && (
                    <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 bg-indigo-500 text-slate-950 font-extrabold text-[5.5px] px-1.5 py-0.5 rounded uppercase tracking-widest animate-pulse shadow">
                      SPEAKER
                    </span>
                  )}
                  <span className="text-[7px] text-indigo-400/80 font-bold uppercase tracking-wider leading-none">Judge Bench</span>
                  <Gavel className={`w-3.5 h-3.5 mx-auto ${activePersona.id === 'vance' ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span className="text-[8px] font-bold truncate">HON. A. VANCE</span>
                </button>

                {/* 3. Witness Stand (Interactive) */}
                <button
                  type="button"
                  onClick={() => handlePersonaChange('sterling')}
                  className={`border rounded-xl p-2 flex flex-col justify-between h-16 text-center transition-all relative ${
                    activePersona.id === 'sterling'
                      ? 'border-indigo-500 bg-indigo-950/20 shadow-[0_0_15px_rgba(99,102,241,0.3)] text-indigo-200'
                      : 'border-slate-800 bg-slate-950 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {activePersona.id === 'sterling' && (
                    <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 bg-indigo-500 text-slate-950 font-extrabold text-[5.5px] px-1.5 py-0.5 rounded uppercase tracking-widest animate-pulse shadow">
                      WITNESS
                    </span>
                  )}
                  <span className="text-[7px] text-indigo-400/80 font-bold uppercase tracking-wider leading-none">Witness Stand</span>
                  <Mic className={`w-3.5 h-3.5 mx-auto ${activePersona.id === 'sterling' ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span className="text-[8px] font-bold truncate">M. STERLING</span>
                </button>
              </div>

              {/* STAGE 2: THE BARRIER BAR & JURY BOX (MIDDLE) */}
              <div className="my-2.5 space-y-2">
                <div className="grid grid-cols-4 gap-2 items-center">
                  {/* Jury Box Grid */}
                  <div className="col-span-3 border border-dashed border-slate-800 bg-slate-900/5 rounded-xl p-1.5 h-11 flex flex-col justify-center text-center">
                    <span className="text-[6px] text-slate-500 uppercase tracking-widest block mb-1 font-mono">JURY PANEL STAND (12 CYCLES)</span>
                    <div className="flex justify-center gap-1.5">
                      {[...Array(6)].map((_, i) => (
                        <div key={i} className="w-1.5 h-1.5 rounded-full bg-slate-800 border border-slate-750" />
                      ))}
                    </div>
                  </div>
                  {/* Neural Confidence Monitor */}
                  <div className="col-span-1 border border-slate-800 bg-slate-900/10 rounded-xl p-1.5 h-11 flex flex-col justify-between text-right">
                    <span className="text-[5.5px] text-slate-500 font-mono uppercase leading-none">JURY BIAS</span>
                    <span className="text-[9px] font-bold text-indigo-400/90 font-mono">68% BAL</span>
                  </div>
                </div>

                {/* Courtroom Bar Dotted Divider */}
                <div className="relative flex items-center justify-center py-0.5">
                  <div className="absolute inset-0 flex items-center" aria-hidden="true">
                    <div className="w-full border-t border-dashed border-indigo-500/15" />
                  </div>
                  <span className="relative px-2 bg-slate-950 text-[6.5px] text-indigo-500/40 uppercase tracking-widest font-mono">
                    CHAMBER STATUTORY BARRIER LIMIT
                  </span>
                </div>
              </div>

              {/* STAGE 3: ADVERSARY ADVOCATE TABLES (LOWER) */}
              <div className="grid grid-cols-2 gap-4">
                {/* Plaintiff Table */}
                <button
                  type="button"
                  onClick={() => handlePersonaChange(plaintiffTier === 'standard' ? 'reynolds' : 'king')}
                  className={`border rounded-xl p-3 flex flex-col justify-between h-24 text-left transition-all relative ${
                    activePersona.id === (plaintiffTier === 'standard' ? 'reynolds' : 'king')
                      ? plaintiffTier === 'elite'
                        ? 'border-amber-500 bg-amber-950/10 shadow-[0_0_15px_rgba(245,158,11,0.25)] text-amber-200'
                        : 'border-indigo-500 bg-indigo-950/20 shadow-[0_0_15px_rgba(99,102,241,0.25)] text-indigo-200'
                      : 'border-slate-800 bg-slate-950 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {activePersona.id === (plaintiffTier === 'standard' ? 'reynolds' : 'king') && (
                    <span className={`absolute -top-1.5 left-2 font-extrabold text-[5.5px] px-1.5 py-0.5 rounded uppercase tracking-widest shadow ${
                      plaintiffTier === 'elite' ? 'bg-amber-500 text-slate-950' : 'bg-indigo-500 text-slate-950'
                    }`}>
                      ACTIVE PLT
                    </span>
                  )}
                  <div className="flex justify-between items-center w-full">
                    <span className="text-[7px] text-slate-400 font-bold uppercase tracking-wider leading-none">Plaintiff Table</span>
                    <div className="flex gap-1 bg-slate-900 p-0.5 rounded-md border border-slate-800" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={() => togglePlaintiffTier('standard')}
                        className={`text-[6px] font-black px-1.5 py-0.5 rounded transition-all uppercase ${
                          plaintiffTier === 'standard' ? 'bg-slate-700 text-slate-100' : 'text-slate-500 hover:text-slate-300'
                        }`}
                        title="Standard Counsel"
                      >
                        Std
                      </button>
                      <button
                        type="button"
                        onClick={() => togglePlaintiffTier('elite')}
                        className={`text-[6px] font-black px-1.5 py-0.5 rounded transition-all uppercase flex items-center gap-0.5 ${
                          plaintiffTier === 'elite' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-500 hover:text-amber-300'
                        }`}
                        title="Elite World-Class Counsel"
                      >
                        <Crown className="w-1.5 h-1.5" /> Elite
                      </button>
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="text-[9px] font-bold flex items-center gap-1">
                      {plaintiffTier === 'elite' ? (
                        <>
                          <Crown className="w-3 h-3 text-amber-400 shrink-0" />
                          <span className="text-amber-400 truncate">A. KING, ESQ.</span>
                        </>
                      ) : (
                        <span className="truncate">C. S. REYNOLDS</span>
                      )}
                    </div>
                    <span className="text-[6px] text-slate-500 uppercase tracking-wider font-mono block">
                      {plaintiffTier === 'elite' ? 'WORLD CHAMPION PLT' : 'Standard Plaintiff Counsel'}
                    </span>
                  </div>
                </button>

                {/* Defendant Table */}
                <button
                  type="button"
                  onClick={() => handlePersonaChange(defendantTier === 'standard' ? 'brooks' : 'marshall')}
                  className={`border rounded-xl p-3 flex flex-col justify-between h-24 text-left transition-all relative ${
                    activePersona.id === (defendantTier === 'standard' ? 'brooks' : 'marshall')
                      ? defendantTier === 'elite'
                        ? 'border-amber-500 bg-amber-950/10 shadow-[0_0_15px_rgba(245,158,11,0.25)] text-amber-200'
                        : 'border-indigo-500 bg-indigo-950/20 shadow-[0_0_15px_rgba(99,102,241,0.25)] text-indigo-200'
                      : 'border-slate-800 bg-slate-950 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {activePersona.id === (defendantTier === 'standard' ? 'brooks' : 'marshall') && (
                    <span className={`absolute -top-1.5 left-2 font-extrabold text-[5.5px] px-1.5 py-0.5 rounded uppercase tracking-widest shadow ${
                      defendantTier === 'elite' ? 'bg-amber-500 text-slate-950' : 'bg-indigo-500 text-slate-950'
                    }`}>
                      ACTIVE DEF
                    </span>
                  )}
                  <div className="flex justify-between items-center w-full">
                    <span className="text-[7px] text-slate-400 font-bold uppercase tracking-wider leading-none">Defendant Table</span>
                    <div className="flex gap-1 bg-slate-900 p-0.5 rounded-md border border-slate-800" onClick={(e) => e.stopPropagation()}>
                      <button
                        type="button"
                        onClick={() => toggleDefendantTier('standard')}
                        className={`text-[6px] font-black px-1.5 py-0.5 rounded transition-all uppercase ${
                          defendantTier === 'standard' ? 'bg-slate-700 text-slate-100' : 'text-slate-500 hover:text-slate-300'
                        }`}
                        title="Standard Mediator/Counsel"
                      >
                        Std
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleDefendantTier('elite')}
                        className={`text-[6px] font-black px-1.5 py-0.5 rounded transition-all uppercase flex items-center gap-0.5 ${
                          defendantTier === 'elite' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-500 hover:text-amber-300'
                        }`}
                        title="Elite World-Class Counsel"
                      >
                        <Crown className="w-1.5 h-1.5" /> Elite
                      </button>
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="text-[9px] font-bold flex items-center gap-1">
                      {defendantTier === 'elite' ? (
                        <>
                          <Shield className="w-3 h-3 text-amber-400 shrink-0" />
                          <span className="text-amber-400 truncate">SIR E. MARSHALL, K.C.</span>
                        </>
                      ) : (
                        <span className="truncate">M. E. BROOKS</span>
                      )}
                    </div>
                    <span className="text-[6px] text-slate-500 uppercase tracking-wider font-mono block">
                      {defendantTier === 'elite' ? 'WORLD CHAMPION DEF' : 'Standard Mediation Counsel'}
                    </span>
                  </div>
                </button>
              </div>

              {/* STAGE 4: GALLERY (BOTTOM) */}
              <div className="mt-3 pt-2.5 border-t border-slate-900 grid grid-cols-5 gap-1.5">
                <div className="col-span-1 flex flex-col justify-center">
                  <span className="text-[5.5px] text-slate-500 uppercase leading-none font-mono">PUBLIC GALLERY</span>
                  <span className="text-[8px] font-bold text-slate-400 font-mono">24 CYCLES</span>
                </div>
                <div className="col-span-4 flex items-center justify-around bg-slate-950/40 border border-slate-900 rounded-lg px-2 h-6">
                  {[...Array(6)].map((_, i) => (
                    <Users key={i} className="w-3 h-3 text-slate-755" />
                  ))}
                </div>
              </div>

            </div>

            {/* Selection Card Detail & Dossier Stats Dashboard */}
            <div className={`border rounded-xl p-4 space-y-3 transition-all ${
              activePersona.tier === 'elite'
                ? 'bg-gradient-to-b from-amber-950/15 to-slate-950/80 border-amber-500/30 shadow-[0_4px_20px_rgba(245,158,11,0.08)] animate-pulse-slow'
                : 'bg-slate-950/50 border-slate-850'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-indigo-400 font-mono text-[9px] uppercase font-bold tracking-wider">
                  <span className={`w-2 h-2 rounded-full ${activePersona.tier === 'elite' ? 'bg-amber-400' : 'bg-indigo-400'} animate-pulse`} />
                  Station: {activePersona.role.replace('_', ' ')}
                </div>
                {activePersona.tier === 'elite' && (
                  <span className="flex items-center gap-1 text-[8px] font-mono font-black text-amber-400 bg-amber-950/40 border border-amber-500/40 px-2 py-0.5 rounded uppercase tracking-widest shadow">
                    <Trophy className="w-2 h-2" /> WORLD CLASS representation
                  </span>
                )}
              </div>

              <div className="flex justify-between items-start">
                <div>
                  <h4 className={`font-black text-sm tracking-tight ${activePersona.tier === 'elite' ? 'text-amber-400' : 'text-slate-100'}`}>
                    {activePersona.name}
                  </h4>
                  <p className="text-slate-400 text-[10.5px] leading-relaxed mt-1">
                    {activePersona.description}
                  </p>
                </div>
              </div>

              {/* Advanced Dossier Statistics Grid */}
              <div className="grid grid-cols-2 gap-2.5 pt-2 border-t border-slate-900">
                <div className="bg-slate-950/40 border border-slate-900 p-2 rounded-lg space-y-1">
                  <div className="text-[7.5px] font-mono text-slate-500 uppercase">Trial Success Rate</div>
                  <div className="flex items-baseline gap-1.5">
                    <span className={`text-xs font-black font-mono ${activePersona.tier === 'elite' ? 'text-amber-400' : 'text-indigo-400'}`}>
                      {activePersona.stats.winRate}
                    </span>
                    {activePersona.tier === 'elite' && (
                      <span className="text-[6.5px] font-bold text-amber-500/70 font-mono uppercase">Undefeated</span>
                    )}
                  </div>
                  {activePersona.stats.winRate !== 'N/A' && (
                    <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${activePersona.tier === 'elite' ? 'bg-amber-500' : 'bg-indigo-500'}`}
                        style={{ width: activePersona.stats.winRate }}
                      />
                    </div>
                  )}
                </div>

                <div className="bg-slate-950/40 border border-slate-900 p-2 rounded-lg space-y-1">
                  <div className="text-[7.5px] font-mono text-slate-500 uppercase">Tactical Style</div>
                  <div className={`text-[10px] font-bold font-mono truncate ${activePersona.tier === 'elite' ? 'text-amber-400/90' : 'text-slate-300'}`}>
                    {activePersona.stats.style}
                  </div>
                  <span className="text-[6px] text-slate-500 uppercase block font-mono">Cognitive Profile</span>
                </div>

                <div className="col-span-2 bg-slate-950/40 border border-slate-900 p-2 rounded-lg flex items-center justify-between">
                  <div>
                    <span className="text-[7.5px] font-mono text-slate-500 uppercase block">Signature Strategy</span>
                    <span className="text-[9.5px] font-bold text-slate-300 font-mono">{activePersona.stats.weapon}</span>
                  </div>
                  <Zap className={`w-3.5 h-3.5 ${activePersona.tier === 'elite' ? 'text-amber-400' : 'text-indigo-500/70'}`} />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[8px] font-mono text-slate-500">
            <span>DECK_MAP_REVISION_2.0</span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              SIMULATOR LINK SECURED
            </span>
          </div>
        </div>

        {/* Tactical objections helper panel */}
        {mode === 'examination' && (
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3 shadow-xl">
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <h4 className="text-[10px] font-mono font-black text-slate-300 uppercase tracking-widest">
                Objection Helper Board
              </h4>
            </div>
            <div className="grid grid-cols-1 gap-2">
              <button
                type="button"
                onClick={() => triggerObjection('Leading the witness on direct examination.')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-left text-[11px] p-2.5 rounded-lg text-slate-300 transition-colors flex items-center justify-between group"
              >
                <span>Objection: Leading</span>
                <span className="text-[7.5px] font-mono text-slate-500 group-hover:text-slate-300">CCP § 767</span>
              </button>
              <button
                type="button"
                onClick={() => triggerObjection('Speculation. The witness has no personal knowledge of this corporate decision.')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-left text-[11px] p-2.5 rounded-lg text-slate-300 transition-colors flex items-center justify-between group"
              >
                <span>Objection: Speculation</span>
                <span className="text-[7.5px] font-mono text-slate-500 group-hover:text-slate-300">CCP § 702</span>
              </button>
              <button
                type="button"
                onClick={() => triggerObjection('Hearsay. This out-of-court statement is offered to prove the truth of the matter.')}
                className="bg-slate-950 hover:bg-slate-850 border border-slate-800 text-left text-[11px] p-2.5 rounded-lg text-slate-300 transition-colors flex items-center justify-between group"
              >
                <span>Objection: Hearsay</span>
                <span className="text-[7.5px] font-mono text-slate-500 group-hover:text-slate-300">Evid. Code § 1200</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Primary chat room dialogue panel */}
      <div className="xl:col-span-3 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col min-h-[580px] shadow-2xl relative overflow-hidden">
        {/* Header bar */}
        <div className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${activePersona.tier === 'elite' ? 'bg-amber-400' : 'bg-emerald-500'} animate-pulse`} />
            <div>
              <div className="flex items-center gap-2">
                <h4 className={`text-xs font-black tracking-tight ${activePersona.tier === 'elite' ? 'text-amber-400' : 'text-slate-200'}`}>
                  {activePersona.name}
                </h4>
                {activePersona.tier === 'elite' && (
                  <span className="text-[7px] font-mono font-black text-amber-400 bg-amber-500/10 border border-amber-500/30 px-1.5 py-0.5 rounded uppercase">
                    ELITE
                  </span>
                )}
              </div>
              <span className="text-[9px] text-indigo-400 uppercase font-mono tracking-wider">
                Interactive Mock Simulation Mode: {mode}
              </span>
            </div>
          </div>

          <button
            onClick={() => handlePersonaChange(activePersona.id)}
            className="text-slate-500 hover:text-slate-300 transition-colors p-1.5 bg-slate-900 rounded-lg border border-slate-800 hover:border-slate-700"
            title="Reset simulation dialogue"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="bg-rose-500/10 border-b border-rose-500/20 text-rose-300 px-6 py-3 text-xs flex items-center gap-2 shrink-0">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>Fallback warning: {error}. Running in high-fidelity local character mode.</span>
          </div>
        )}

        {/* Scrollable messages container */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            const roleLabel = isUser ? 'You' : activePersona.name;

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[85%] ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
              >
                {/* Visual Avatar symbol */}
                <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 border text-xs font-mono font-black shadow-lg ${
                  isUser
                    ? 'bg-indigo-950 border-indigo-500 text-indigo-400'
                    : msg.sender === 'judge'
                    ? 'bg-slate-950 border-indigo-500/50 text-indigo-300'
                    : activePersona.tier === 'elite'
                    ? 'bg-amber-950/40 border-amber-500/50 text-amber-400'
                    : 'bg-slate-900 border-slate-800 text-slate-300'
                }`}>
                  {isUser ? 'YOU' : activePersona.tier === 'elite' ? '★' : msg.sender[0].toUpperCase()}
                </div>

                <div className="space-y-1">
                  <div className={`flex items-baseline gap-2 ${isUser ? 'justify-end' : ''}`}>
                    <span className="text-[10px] font-bold text-slate-400">{roleLabel}</span>
                    <span className="text-[9px] text-slate-500 font-mono">{msg.timestamp}</span>
                  </div>

                  <div className={`p-3.5 rounded-2xl text-[11.5px] leading-relaxed shadow ${
                    isUser
                      ? 'bg-indigo-600 text-slate-100 rounded-tr-none'
                      : activePersona.tier === 'elite'
                      ? 'bg-gradient-to-br from-amber-950/20 to-slate-950/90 border border-amber-500/30 text-amber-100 rounded-tl-none'
                      : 'bg-slate-950 border border-slate-850 text-slate-200 rounded-tl-none'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex gap-3 max-w-[80%] mr-auto items-center">
              <div className="w-9 h-9 rounded-full bg-slate-950 border border-slate-850 flex items-center justify-center text-xs font-mono text-slate-500 shrink-0">
                AI
              </div>
              <div className="bg-slate-950 border border-slate-850 px-4 py-2.5 rounded-2xl rounded-tl-none text-xs text-slate-400 flex items-center gap-2 font-mono">
                <svg className="animate-spin h-3.5 w-3.5 text-indigo-400" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Deliberating supreme strategy...
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Bottom submit form */}
        <form
          onSubmit={handleSendMessage}
          className="bg-slate-950 border-t border-slate-800 p-4 flex gap-2.5 shrink-0"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={`Instruct or challenge ${activePersona.name}...`}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder-slate-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isTyping}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-slate-100 px-4 py-2.5 rounded-xl transition-all flex items-center gap-1.5 font-bold shadow-lg"
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
}
