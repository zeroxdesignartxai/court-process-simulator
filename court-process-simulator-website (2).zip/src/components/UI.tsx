/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { ForwardRefRenderFunction, useImperativeHandle, forwardRef } from 'react';
import { LucideIcon } from 'lucide-react';

// Card Components
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}
export const Card: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <div 
    className={`bg-slate-900 border border-slate-850 rounded-2xl shadow-xl overflow-hidden transition-all hover:border-slate-800 ${className}`} 
    {...props}
  >
    {children}
  </div>
);

export const CardHeader: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <div className={`p-5 border-b border-slate-850 flex items-center justify-between gap-4 ${className}`} {...props}>
    {children}
  </div>
);

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({ className = '', children, ...props }) => (
  <h3 className={`text-sm font-black text-slate-100 uppercase tracking-tight font-sans ${className}`} {...props}>
    {children}
  </h3>
);

export const CardDescription: React.FC<React.HTMLAttributes<HTMLParagraphElement>> = ({ className = '', children, ...props }) => (
  <p className={`text-xs text-slate-400 ${className}`} {...props}>
    {children}
  </p>
);

export const CardContent: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <div className={`p-5 ${className}`} {...props}>
    {children}
  </div>
);

// Badge Component
interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'secondary' | 'success' | 'warning' | 'destructive' | 'info' | 'purple';
}
export const Badge: React.FC<BadgeProps> = ({ className = '', variant = 'default', children, ...props }) => {
  const styles = {
    default: 'bg-indigo-950 text-indigo-400 border-indigo-850/50',
    secondary: 'bg-slate-800 text-slate-400 border-slate-700/50',
    success: 'bg-emerald-950/40 text-emerald-400 border-emerald-900/30',
    warning: 'bg-amber-950/40 text-amber-400 border-amber-900/30',
    destructive: 'bg-rose-950/40 text-rose-400 border-rose-900/30',
    info: 'bg-blue-950/40 text-blue-400 border-blue-900/30',
    purple: 'bg-purple-950/40 text-purple-400 border-purple-900/30',
  };

  return (
    <span 
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-mono tracking-wide font-bold uppercase border ${styles[variant]} ${className}`} 
      {...props}
    >
      {children}
    </span>
  );
};

// Button Component
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'destructive';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  icon?: LucideIcon;
}
export const Button: React.FC<ButtonProps> = ({ 
  className = '', 
  variant = 'primary', 
  size = 'md', 
  icon: Icon, 
  children, 
  ...props 
}) => {
  const baseStyle = 'inline-flex items-center justify-center gap-2 font-bold transition-all duration-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer';
  
  const variants = {
    primary: 'bg-indigo-600 hover:bg-indigo-500 text-slate-100 shadow-lg shadow-indigo-950/40 border border-indigo-500/30 active:scale-98',
    secondary: 'bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700/40 active:scale-98',
    outline: 'bg-transparent hover:bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-750 active:scale-98',
    ghost: 'bg-transparent hover:bg-slate-900 text-slate-400 hover:text-slate-200',
    destructive: 'bg-rose-600 hover:bg-rose-500 text-slate-100 shadow-lg shadow-rose-950/40 border border-rose-500/30 active:scale-98'
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-[10px] h-8',
    md: 'px-4 py-2.5 text-xs h-10',
    lg: 'px-6 py-3 text-sm h-12',
    icon: 'p-2 w-10 h-10'
  };

  return (
    <button className={`${baseStyle} ${variants[variant]} ${sizes[size]} ${className}`} {...props}>
      {Icon && <Icon className="w-4 h-4 shrink-0" />}
      {children}
    </button>
  );
};

// Progress Component
interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number;
  max?: number;
  colorClass?: string;
}
export const Progress: React.FC<ProgressProps> = ({ 
  className = '', 
  value, 
  max = 100, 
  colorClass = 'bg-indigo-500', 
  ...props 
}) => {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className={`w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-900/60 ${className}`} {...props}>
      <div 
        className={`h-full rounded-full transition-all duration-300 ${colorClass}`} 
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
};

// Input Components
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}
export const Input: React.FC<InputProps> = forwardRef<HTMLInputElement, InputProps>(({ 
  className = '', 
  label, 
  error, 
  id, 
  ...props 
}, ref) => {
  return (
    <div className="space-y-1.5 w-full">
      {label && (
        <label htmlFor={id} className="block text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
          {label}
        </label>
      )}
      <input
        ref={ref}
        id={id}
        className={`w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 transition-all ${
          error ? 'border-rose-500/50 focus:ring-rose-500/10' : ''
        } ${className}`}
        {...props}
      />
      {error && <p className="text-[10px] text-rose-400 font-medium font-mono">{error}</p>}
    </div>
  );
});

Input.displayName = 'Input';

// Select Component
interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: { value: string; label: string }[];
}
export const Select: React.FC<SelectProps> = forwardRef<HTMLSelectElement, SelectProps>(({ 
  className = '', 
  label, 
  error, 
  options, 
  id, 
  ...props 
}, ref) => {
  return (
    <div className="space-y-1.5 w-full">
      {label && (
        <label htmlFor={id} className="block text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
          {label}
        </label>
      )}
      <div className="relative">
        <select
          ref={ref}
          id={id}
          className={`w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 transition-all appearance-none ${
            error ? 'border-rose-500/50 focus:ring-rose-500/10' : ''
          } ${className}`}
          {...props}
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value} className="bg-slate-950 text-slate-100">
              {opt.label}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3.5 text-slate-400">
          <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
          </svg>
        </div>
      </div>
      {error && <p className="text-[10px] text-rose-400 font-medium font-mono">{error}</p>}
    </div>
  );
});

Select.displayName = 'Select';

// Textarea Component
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}
export const Textarea: React.FC<TextareaProps> = forwardRef<HTMLTextAreaElement, TextareaProps>(({ 
  className = '', 
  label, 
  error, 
  id, 
  ...props 
}, ref) => {
  return (
    <div className="space-y-1.5 w-full">
      {label && (
        <label htmlFor={id} className="block text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        id={id}
        className={`w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 transition-all min-h-[80px] ${
          error ? 'border-rose-500/50 focus:ring-rose-500/10' : ''
        } ${className}`}
        {...props}
      />
      {error && <p className="text-[10px] text-rose-400 font-medium font-mono">{error}</p>}
    </div>
  );
});

Textarea.displayName = 'Textarea';

// Tooltip helper (simplified CSS-only or light interactive representation)
export const Tooltip: React.FC<{ content: string; children: React.ReactElement }> = ({ content, children }) => {
  return (
    <div className="relative group inline-block">
      {children}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block bg-slate-900 border border-slate-800 text-slate-100 text-[10px] px-2 py-1 rounded shadow-lg z-50 whitespace-nowrap">
        {content}
      </div>
    </div>
  );
};
