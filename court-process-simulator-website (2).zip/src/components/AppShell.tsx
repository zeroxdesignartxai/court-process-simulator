/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { 
  Activity, 
  Clock, 
  FileText, 
  Scale, 
  Gavel, 
  TrendingUp, 
  MessageSquare, 
  Calendar, 
  Settings, 
  Search, 
  Plus, 
  Bell, 
  HelpCircle, 
  ChevronDown, 
  RefreshCw, 
  CheckCircle2,
  Lock,
  Home,
  BookOpen,
  Binary,
  Sparkles,
  Menu,
  X
} from 'lucide-react';
import { CaseIntake } from '../types';

interface AppShellProps {
  children: React.ReactNode;
  activeHash: string;
  cases: CaseIntake[];
  activeCase: CaseIntake;
  onSelectCase: (caseTitle: string) => void;
  onTriggerNewCase: () => void;
  lastUpdated: string;
  onRefresh: () => void;
  alertsCount?: number;
  onAcknowledgeAlerts?: () => void;
  onTriggerOnboarding?: () => void;
}

export const AppShell: React.FC<AppShellProps> = ({
  children,
  activeHash,
  cases,
  activeCase,
  onSelectCase,
  onTriggerNewCase,
  lastUpdated,
  onRefresh,
  alertsCount = 3,
  onAcknowledgeAlerts,
  onTriggerOnboarding
}) => {
  const [caseDropdownOpen, setCaseDropdownOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    try {
      const savedPreferences = JSON.parse(localStorage.getItem('legal-simulator-preferences-v1') || '{}');
      return savedPreferences.notifsEnabled !== false;
    } catch {
      return true;
    }
  });

  const primaryItems = [
    { id: '#dashboard', label: 'Dashboard', icon: Activity },
    { id: '#simulator', label: 'Simulator Arena', icon: Gavel },
    { id: '#claims', label: 'Claims & Defenses', icon: Scale },
    { id: '#outcomes', label: 'Outcomes & Risk', icon: TrendingUp },
  ];

  const secondaryItems = [
    { id: '#landing', label: 'Portal Home', icon: Home },
    { id: '#timeline', label: 'Case Timeline', icon: Clock },
    { id: '#evidence', label: 'Documents & Files', icon: FileText },
    { id: '#research', label: 'Legal Research', icon: BookOpen },
    { id: '#tasks', label: 'Tasks & Deadlines', icon: Calendar },
    { id: '#reports', label: 'Reports', icon: MessageSquare },
    { id: '#testing', label: 'Stress Tester', icon: Binary },
    { id: '#settings', label: 'Settings', icon: Settings },
  ];

  const [secondaryOpen, setSecondaryOpen] = useState(() => {
    return secondaryItems.some(item => item.id === activeHash);
  });

  const handleNavClick = (hash: string) => {
    window.location.hash = hash;
    setMobileNavOpen(false);
    setSearchQuery('');
  };

  const normalizedSearch = searchQuery.trim().toLowerCase();
  const navigationSearchResults = [...primaryItems, ...secondaryItems].filter((item) =>
    item.label.toLowerCase().includes(normalizedSearch)
  );
  const caseSearchResults = cases.filter((item) =>
    `${item.title} ${item.courtName} ${item.caseType}`.toLowerCase().includes(normalizedSearch)
  );

  useEffect(() => {
    const handlePreferencesUpdated = (event: Event) => {
      const customEvent = event as CustomEvent<{ notifsEnabled?: boolean }>;
      setNotificationsEnabled(customEvent.detail?.notifsEnabled !== false);
    };
    window.addEventListener('legal-simulator-preferences-updated', handlePreferencesUpdated);
    return () => window.removeEventListener('legal-simulator-preferences-updated', handlePreferencesUpdated);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* SIDEBAR */}
      <aside
        id="primary-navigation"
        className={`w-72 lg:w-64 bg-slate-900 border-r border-slate-850 flex flex-col justify-between shrink-0 fixed top-0 bottom-0 z-50 transition-transform duration-200 lg:translate-x-0 ${
          mobileNavOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col">
          {/* Logo / Brand Header */}
          <div className="p-6 border-b border-slate-850 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-950/40">
              <Gavel className="w-5 h-5 text-slate-100" />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="text-sm font-black tracking-tight text-slate-100 uppercase">LEGAL SIMULATOR</h2>
              <p className="text-[10px] text-indigo-400 font-medium font-mono">Court Process Simulator</p>
            </div>
            <button
              type="button"
              className="lg:hidden w-9 h-9 rounded-lg border border-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-800 flex items-center justify-center"
              onClick={() => setMobileNavOpen(false)}
              aria-label="Close navigation"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="p-4 space-y-4">
            {/* Primary Nav Section */}
            <div className="space-y-1">
              <span className="block px-4 text-[9px] font-mono font-bold text-slate-500 uppercase tracking-widest mb-2">
                Primary Case Workspace
              </span>
              {primaryItems.map((item) => {
                const isActive = activeHash === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-150 group cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-slate-100 shadow-md shadow-indigo-950/30 font-black'
                        : 'text-slate-400 hover:bg-slate-850/60 hover:text-slate-200'
                    }`}
                  >
                    <item.icon className={`w-4 h-4 shrink-0 transition-transform duration-150 group-hover:scale-110 ${
                      isActive ? 'text-slate-100' : 'text-slate-500 group-hover:text-slate-400'
                    }`} />
                    {item.label}
                  </button>
                );
              })}
            </div>

            {/* Secondary Nav Section (Collapsible Menu) */}
            <div className="border-t border-slate-850/60 pt-3">
              <button
                onClick={() => setSecondaryOpen(!secondaryOpen)}
                className="w-full flex items-between justify-between px-4 py-1 text-[9px] font-mono font-bold text-slate-500 hover:text-slate-300 uppercase tracking-widest cursor-pointer group"
              >
                <span>Secondary Utilities</span>
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${secondaryOpen ? 'rotate-180 text-slate-400' : 'text-slate-600'}`} />
              </button>

              {secondaryOpen && (
                <div className="mt-2 space-y-1 pl-1 animate-fade-in">
                  {secondaryItems.map((item) => {
                    const isActive = activeHash === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleNavClick(item.id)}
                        className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-[11px] font-bold transition-all duration-150 group cursor-pointer ${
                          isActive
                            ? 'bg-slate-800 text-indigo-400 border border-slate-700 font-black shadow-sm'
                            : 'text-slate-400 hover:bg-slate-850/40 hover:text-slate-200'
                        }`}
                      >
                        <item.icon className={`w-3.5 h-3.5 shrink-0 transition-transform duration-150 group-hover:scale-110 ${
                          isActive ? 'text-indigo-400' : 'text-slate-600 group-hover:text-slate-500'
                        }`} />
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </nav>
        </div>

        {/* Sidebar Footer Profile Area */}
        <div className="p-4 border-t border-slate-850 space-y-3">
          {/* Profile Card */}
          <div className="flex items-center gap-3 p-2 bg-slate-950/40 border border-slate-850/40 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-slate-800 border-2 border-indigo-500/20 overflow-hidden shrink-0">
              <span className="w-full h-full flex items-center justify-center text-xs font-black text-indigo-200 bg-indigo-950">
                MS
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <h4 className="text-xs font-black text-slate-100 truncate">Mauricio S.</h4>
              <span className="inline-flex items-center gap-1 text-[9px] font-mono font-bold text-indigo-400 uppercase tracking-wider">
                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse"></span>
                Case Owner
              </span>
            </div>
          </div>

          {/* Help & Support Button */}
          <button 
            onClick={() => handleNavClick('#settings')}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 text-[10px] font-mono font-bold text-slate-400 hover:text-slate-200 rounded-xl transition-all cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
            Help & Support
          </button>
        </div>
      </aside>

      {mobileNavOpen && (
        <button
          type="button"
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileNavOpen(false)}
          aria-label="Close navigation overlay"
        />
      )}

      {/* MAIN CONTENT WORKSPACE */}
      <div className="min-w-0 flex-1 flex flex-col pl-0 lg:pl-64">
        
        {/* TOP BAR / HEADER */}
        <header className="h-16 md:h-20 bg-slate-900 border-b border-slate-850 flex items-center justify-between px-4 md:px-8 sticky top-0 z-30">
          {/* Left Title */}
          <div className="flex items-center gap-2 md:gap-3">
            <button
              type="button"
              className="lg:hidden w-10 h-10 rounded-xl bg-slate-950/40 border border-slate-850 flex items-center justify-center text-slate-300"
              onClick={() => setMobileNavOpen(true)}
              aria-label="Open navigation"
              aria-expanded={mobileNavOpen}
              aria-controls="primary-navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden sm:flex w-10 h-10 rounded-xl bg-slate-950/40 border border-slate-850 items-center justify-center text-indigo-400 shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h1 className="text-[10px] md:text-xs font-black uppercase tracking-tight text-slate-100 font-sans truncate max-w-[36vw] sm:max-w-none">
                COURT PROCESS SIMULATOR & LEGAL TELEMETRY DASHBOARD
              </h1>
              <p className="hidden sm:block text-[10px] text-slate-400 font-medium">Prepare. Practice. Verify. Decide.</p>
            </div>
          </div>

          {/* Center Search bar */}
          <div className="max-w-md w-full mx-4 relative hidden xl:block">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search cases, documents, or hearings..." 
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              className="w-full bg-slate-950 border border-slate-850 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 transition-all"
              aria-label="Search case workspace"
            />
            {normalizedSearch && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-2 z-50 max-h-80 overflow-y-auto">
                {navigationSearchResults.map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-xs text-slate-300 hover:bg-slate-800"
                  >
                    <item.icon className="w-3.5 h-3.5 text-indigo-400" />
                    {item.label}
                  </button>
                ))}
                {caseSearchResults.map((item) => (
                  <button
                    type="button"
                    key={item.title}
                    onClick={() => {
                      onSelectCase(item.title);
                      setSearchQuery('');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-xs text-slate-300 hover:bg-slate-800"
                  >
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="truncate">{item.title}</span>
                  </button>
                ))}
                {navigationSearchResults.length === 0 && caseSearchResults.length === 0 && (
                  <p className="px-3 py-4 text-center text-[11px] text-slate-500">No matching pages or cases.</p>
                )}
              </div>
            )}
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-3">
            
            {/* Getting Started Onboarding Trigger */}
            {onTriggerOnboarding && (
              <button
                onClick={onTriggerOnboarding}
                className="hidden 2xl:flex px-3.5 py-2 bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 text-xs font-bold text-slate-300 rounded-xl transition-all items-center gap-1.5 cursor-pointer"
                title="View onboarding simulation guide"
                id="header_getting_started_btn"
              >
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                <span className="hidden sm:inline">Getting Started</span>
              </button>
            )}

            {/* Case Selector Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setCaseDropdownOpen(!caseDropdownOpen)}
                className="bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-950/30 transition-all duration-200 cursor-pointer"
                aria-label="Choose or create a case"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden md:inline">New Case</span>
                <ChevronDown className="hidden md:block w-3.5 h-3.5 opacity-80" />
              </button>

              {caseDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setCaseDropdownOpen(false)} />
                  <div className="absolute right-0 mt-2 w-[min(16rem,calc(100vw-2rem))] bg-slate-900 border border-slate-800 rounded-xl shadow-xl p-2 z-50 animate-slide-up">
                    <div className="px-3 py-1.5 border-b border-slate-850 mb-1.5">
                      <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-widest">Select Case File</span>
                    </div>
                    {cases.map((cs) => {
                      const isActive = cs.title === activeCase.title;
                      return (
                        <button
                          key={cs.title}
                          onClick={() => {
                            onSelectCase(cs.title);
                            setCaseDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 text-xs rounded-lg transition-colors flex items-center justify-between ${
                            isActive 
                              ? 'bg-indigo-600/15 text-indigo-400 font-bold' 
                              : 'text-slate-300 hover:bg-slate-850'
                          }`}
                        >
                          <span className="truncate pr-2">{cs.title}</span>
                          {isActive && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                        </button>
                      );
                    })}
                    <div className="border-t border-slate-850 mt-1.5 pt-1.5">
                      <button
                        onClick={() => {
                          onTriggerNewCase();
                          setCaseDropdownOpen(false);
                        }}
                        className="w-full text-center px-3 py-2 text-xs font-bold text-indigo-400 hover:bg-indigo-950/30 border border-dashed border-indigo-950 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Configure New Case
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Notification Bell */}
            {notificationsEnabled && <div className="relative">
              <button 
                onClick={() => {
                  setNotificationOpen(!notificationOpen);
                  if (onAcknowledgeAlerts && alertsCount > 0) {
                    onAcknowledgeAlerts();
                  }
                }}
                className="hidden sm:flex w-10 h-10 rounded-xl bg-slate-950/40 border border-slate-850 hover:bg-slate-850/60 text-slate-400 hover:text-slate-200 items-center justify-center transition-all cursor-pointer relative"
                aria-label="Open workspace notifications"
              >
                <Bell className="w-4.5 h-4.5" />
                {alertsCount > 0 && (
                  <span className="absolute top-2 right-2 w-4 h-4 bg-rose-600 text-[9px] text-slate-100 font-black rounded-full flex items-center justify-center ring-2 ring-slate-900 animate-pulse">
                    {alertsCount}
                  </span>
                )}
              </button>

              {notificationOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setNotificationOpen(false)} />
                  <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-800 rounded-xl shadow-xl p-3 z-50 animate-slide-up">
                    <div className="flex justify-between items-center mb-2 pb-2 border-b border-slate-850">
                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Workspace Alerts</span>
                      <span className="text-[9px] bg-indigo-950/40 text-indigo-400 px-1.5 py-0.5 rounded border border-indigo-900/30 font-mono">Simulation Active</span>
                    </div>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      <div className="p-2 bg-slate-950/40 border border-slate-850/50 rounded-lg text-[11px] leading-normal text-slate-300">
                        <p className="font-bold text-indigo-400 mb-0.5">Sanchez v. AHM Resicom</p>
                        <p>Case workspace is ready for evidence and deadline review.</p>
                      </div>
                      <div className="p-2 bg-slate-950/40 border border-slate-850/50 rounded-lg text-[11px] leading-normal text-slate-300">
                        <p className="font-bold text-amber-400 mb-0.5">Simulation Notice</p>
                        <p>Readiness and risk values are simulated strategy signals, not court predictions.</p>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>}

          </div>
        </header>

        {/* PAGE BREADCRUMBS & SUB-NAV */}
        <div className="bg-slate-950 border-b border-slate-900/60 px-4 md:px-8 py-3.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <span>Dashboard</span>
            <span>/</span>
            <span className="text-indigo-400 font-extrabold uppercase tracking-wide">
              {activeHash.replace('#', '').replace('_', ' ') || 'Case Analysis'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden sm:flex text-[10px] text-slate-500 font-mono items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
              Last updated: {lastUpdated}
            </span>
            <button 
              onClick={onRefresh}
              className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 text-slate-400 hover:text-slate-200 transition-all cursor-pointer"
              title="Refresh simulator telemetry"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* CONTAINER PAGE WORKSPACE */}
        <main className="flex-1 p-4 md:p-8 overflow-y-auto pb-16">
          {children}
        </main>

      </div>
    </div>
  );
};
