/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Suspense, lazy, useState, useEffect } from 'react';
import { AppShell } from './components/AppShell';
import { OnboardingModal } from './components/OnboardingModal';

// Types & Mock Data
import { CaseIntake, CaseReport, EvidenceItem } from './types';
import { SMITH_VS_ABC_CASE, SMITH_VS_ABC_REPORT } from './data/mockData';

const SANCHEZ_CASE: CaseIntake = {
  title: 'Sanchez v. AHM Resicom LLC',
  caseType: 'landlord_tenant',
  jurisdiction: 'State of California (County of Los Angeles)',
  courtName: 'Los Angeles County Superior Court',
  currentStage: 'Intake',
  amountInControversy: 15000,
  remedyRequested: 'Compensatory damages, rent abatement, and constructive eviction offsets.',
  parties: [
    { id: 'p_s1', name: 'AHM Resicom LLC', role: 'plaintiff', type: 'organization', represented: true, claims: ['Breach of Lease', 'Arrears ($6,200)'], defenses: [] },
    { id: 'p_s2', name: 'Mauricio Sanchez', role: 'defendant', type: 'individual', represented: true, claims: [], defenses: ['Warranty of Habitability Breach', 'Retaliatory Rent Increase'] }
  ],
  facts: [
    { id: 'f_s1', description: 'Sanchez moved in under a written 12-month residential contract.', date: '2023-08-01', status: 'admitted', evidenceIds: [] },
    { id: 'f_s2', description: 'Main service pipe cracked, causing bathroom ceiling flooding and mold growth.', date: '2024-01-10', status: 'admitted', evidenceIds: [] }
  ],
  evidence: [],
  claims: ['Breach of Lease Covenant'],
  defenses: ['Habitability Exception']
};

const LandingPage = lazy(() => import('./pages/LandingPage').then((module) => ({ default: module.LandingPage })));
const DashboardPage = lazy(() => import('./pages/DashboardPage').then((module) => ({ default: module.DashboardPage })));
const IntakePage = lazy(() => import('./pages/IntakePage').then((module) => ({ default: module.IntakePage })));
const TimelinePage = lazy(() => import('./pages/TimelinePage').then((module) => ({ default: module.TimelinePage })));
const EvidencePage = lazy(() => import('./pages/EvidencePage').then((module) => ({ default: module.EvidencePage })));
const ClaimsPage = lazy(() => import('./pages/ClaimsPage').then((module) => ({ default: module.ClaimsPage })));
const SimulatorPage = lazy(() => import('./pages/SimulatorPage').then((module) => ({ default: module.SimulatorPage })));
const OutcomesPage = lazy(() => import('./pages/OutcomesPage').then((module) => ({ default: module.OutcomesPage })));
const TasksPage = lazy(() => import('./pages/TasksPage').then((module) => ({ default: module.TasksPage })));
const ReportsPage = lazy(() => import('./pages/ReportsPage').then((module) => ({ default: module.ReportsPage })));
const SettingsPage = lazy(() => import('./pages/SettingsPage').then((module) => ({ default: module.SettingsPage })));
const ResearchPage = lazy(() => import('./pages/ResearchPage').then((module) => ({ default: module.ResearchPage })));
const TestingPage = lazy(() => import('./pages/TestingPage').then((module) => ({ default: module.TestingPage })));

const CASES_STORAGE_KEY = 'legal-simulator-cases-v2';
const ACTIVE_CASE_STORAGE_KEY = 'legal-simulator-active-case-v2';

function loadSavedCases(): CaseIntake[] {
  try {
    const saved = localStorage.getItem(CASES_STORAGE_KEY);
    if (!saved) return [SMITH_VS_ABC_CASE, SANCHEZ_CASE];
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : [SMITH_VS_ABC_CASE, SANCHEZ_CASE];
  } catch {
    return [SMITH_VS_ABC_CASE, SANCHEZ_CASE];
  }
}

const PageLoadingState = () => (
  <div className="min-h-[50vh] flex items-center justify-center" role="status" aria-live="polite">
    <div className="flex items-center gap-3 text-xs font-bold text-slate-400">
      <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
      Loading case workspace…
    </div>
  </div>
);

export default function App() {
  const [activeHash, setActiveHash] = useState<string>('#landing');
  const [cases, setCases] = useState<CaseIntake[]>(loadSavedCases);
  const [activeCase, setActiveCase] = useState<CaseIntake>(() => {
    const activeTitle = localStorage.getItem(ACTIVE_CASE_STORAGE_KEY);
    return cases.find((item) => item.title === activeTitle) ?? cases[0] ?? SANCHEZ_CASE;
  });
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);

  // Trigger onboarding on first visit
  useEffect(() => {
    const completed = localStorage.getItem('onboarding-completed');
    if (!completed) {
      setIsOnboardingOpen(true);
    }
  }, []);
  const [activeReport, setActiveReport] = useState<CaseReport>(SMITH_VS_ABC_REPORT);
  const [isSimulating, setIsSimulating] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toLocaleTimeString());
  const [alertsCount, setAlertsCount] = useState(2);

  // Synchronize hash-based routing state
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash || '#landing';
      setActiveHash(hash);
    };

    window.addEventListener('hashchange', handleHashChange);
    // Initialize hash if not present
    if (!window.location.hash) {
      window.location.hash = '#landing';
    } else {
      setActiveHash(window.location.hash);
    }

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  useEffect(() => {
    localStorage.setItem(CASES_STORAGE_KEY, JSON.stringify(cases));
  }, [cases]);

  useEffect(() => {
    localStorage.setItem(ACTIVE_CASE_STORAGE_KEY, activeCase.title);
  }, [activeCase.title]);

  // Handler to sync edited case details
  const handleUpdateCase = (updated: CaseIntake) => {
    const previousTitle = activeCase.title;
    setActiveCase(updated);
    setCases((prev) => prev.map((c) => (c.title === previousTitle ? updated : c)));
  };

  // Handler to switch or select an active case
  const handleSelectCase = (caseTitle: string) => {
    const selected = cases.find((c) => c.title === caseTitle);
    if (selected) {
      setActiveCase(selected);
      if (window.location.hash === '#landing' || activeHash === '#landing') {
        window.location.hash = '#dashboard';
      }
    }
  };

  const handleNavigate = (hash: string) => {
    window.location.hash = hash;
  };

  // Trigger Gemini AI simulated predictive metrics computation
  const handleSimulateCase = async (caseData?: any) => {
    const isCaseIntake = caseData && 
                         typeof caseData === 'object' && 
                         'title' in caseData && 
                         typeof caseData.title === 'string' &&
                         'caseType' in caseData &&
                         'courtName' in caseData;
    const dataToSimulate = isCaseIntake ? caseData : activeCase;
    setIsSimulating(true);
    try {
      const response = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caseIntake: dataToSimulate })
      });

      if (!response.ok) throw new Error('Simulation failed');
      const data = await response.json();
      
      if (data.report) {
        setActiveReport(data.report);
      }
      setLastUpdated(new Date().toLocaleTimeString());
      window.location.hash = '#dashboard';
    } catch (err) {
      console.error(err);
      // Fallback update to simulate real-time analysis if server offline
      setLastUpdated(new Date().toLocaleTimeString());
      window.location.hash = '#dashboard';
    } finally {
      setIsSimulating(false);
    }
  };

  // Setup a new case structure
  const handleTriggerNewCase = () => {
    const isSanchezLoaded = cases.some((c) => c.title === SANCHEZ_CASE.title);
    if (!isSanchezLoaded) {
      setCases((prev) => [...prev, SANCHEZ_CASE]);
    }
    setActiveCase(SANCHEZ_CASE);
    window.location.hash = '#intake';
  };

  // Add evidence item
  const handleAddEvidence = (item: EvidenceItem) => {
    const updatedCase = {
      ...activeCase,
      evidence: [...activeCase.evidence, item]
    };
    handleUpdateCase(updatedCase);
  };

  // Remove evidence item
  const handleRemoveEvidence = (id: string) => {
    const updatedCase = {
      ...activeCase,
      evidence: activeCase.evidence.filter((e) => e.id !== id)
    };
    handleUpdateCase(updatedCase);
  };

  const handleRefresh = () => {
    setLastUpdated(new Date().toLocaleTimeString());
    setAlertsCount(0);
  };

  // RENDER CORRESPONDING NAVIGATION PAGES
  const renderPage = () => {
    switch (activeHash) {
      case '#dashboard':
        return (
          <DashboardPage 
            activeCase={activeCase} 
            report={activeReport} 
            onNavigate={handleNavigate}
            onSimulate={handleSimulateCase}
          />
        );
      case '#intake':
        return (
          <IntakePage 
            activeCase={activeCase} 
            onUpdateCase={handleUpdateCase}
            onProcessCase={handleSimulateCase}
            isProcessing={isSimulating}
          />
        );
      case '#timeline':
        return <TimelinePage />;
      case '#evidence':
        return (
          <EvidencePage 
            evidence={activeCase.evidence}
            onAddEvidence={handleAddEvidence}
            onRemoveEvidence={handleRemoveEvidence}
          />
        );
      case '#claims':
        return <ClaimsPage report={activeReport} />;
      case '#research':
        return <ResearchPage activeCase={activeCase} />;
      case '#simulator':
        return <SimulatorPage activeCase={activeCase} />;
      case '#outcomes':
        return <OutcomesPage report={activeReport} />;
      case '#tasks':
        return <TasksPage report={activeReport} />;
      case '#reports':
        return <ReportsPage report={activeReport} />;
      case '#testing':
        return <TestingPage />;
      case '#settings':
        return <SettingsPage />;
      default:
        // Default Landing/Dashboard Fallback
        return (
          <DashboardPage 
            activeCase={activeCase} 
            report={activeReport} 
            onNavigate={handleNavigate}
            onSimulate={handleSimulateCase}
          />
        );
    }
  };

  if (activeHash === '#landing') {
    return (
      <Suspense fallback={<PageLoadingState />}>
        <LandingPage 
          cases={cases}
          onSelectCase={handleSelectCase}
          onLaunchNewCase={handleTriggerNewCase}
        />
      </Suspense>
    );
  }

  return (
    <>
      <AppShell
        activeHash={activeHash}
        cases={cases}
        activeCase={activeCase}
        onSelectCase={handleSelectCase}
        onTriggerNewCase={handleTriggerNewCase}
        lastUpdated={lastUpdated}
        onRefresh={handleRefresh}
        alertsCount={alertsCount}
        onAcknowledgeAlerts={() => setAlertsCount(0)}
        onTriggerOnboarding={() => setIsOnboardingOpen(true)}
      >
        <Suspense fallback={<PageLoadingState />}>
          {renderPage()}
        </Suspense>
      </AppShell>

      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onNavigate={handleNavigate}
      />
    </>
  );
}
