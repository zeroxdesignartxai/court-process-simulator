/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CaseIntake, CaseReport } from '../types';

export const SMITH_VS_ABC_CASE: CaseIntake = {
  title: 'Smith v. ABC Properties LLC',
  caseType: 'landlord_tenant',
  jurisdiction: 'State of California (County of Los Angeles)',
  courtName: 'Los Angeles County Civil Court',
  currentStage: 'Discovery',
  amountInControversy: 12500,
  remedyRequested: 'Compensatory damages of $12,500, rent abatement, and prevention of residential eviction.',
  parties: [
    {
      id: 'p_1',
      name: 'ABC Properties LLC',
      role: 'plaintiff',
      type: 'organization',
      represented: true,
      claims: ['Residential Eviction', 'Unpaid Back Rent'],
      defenses: []
    },
    {
      id: 'p_2',
      name: 'John Smith',
      role: 'defendant',
      type: 'individual',
      represented: true,
      claims: [],
      defenses: ['Defective Notice of Eviction', 'Breach of Warranty of Habitability', 'Retaliatory Eviction']
    }
  ],
  facts: [
    { id: 'f_1', description: 'John Smith signed a 1-year residential apartment lease at $2,500 per month.', date: '2023-06-01', status: 'admitted', evidenceIds: ['ev_1'] },
    { id: 'f_2', description: 'Tenant fell into rent arrears for March and April 2024 due to building water damage.', date: '2024-03-01', status: 'admitted', evidenceIds: ['ev_3'] },
    { id: 'f_3', description: 'Landlord served a 3-day notice to pay or quit by leaving it in a shared common lobby mail basket.', date: '2024-05-10', status: 'disputed', evidenceIds: ['ev_2'] },
    { id: 'f_4', description: 'Tenant repeatedly requested repairs for active roof water leaks and kitchen wall mold.', date: '2024-02-15', status: 'admitted', evidenceIds: ['ev_4'] },
    { id: 'f_5', description: 'No in-hand personal service of the eviction notice was ever completed.', date: '2024-05-11', status: 'disputed', evidenceIds: [] }
  ],
  evidence: [
    {
      id: 'ev_1',
      title: 'Residential Lease Agreement',
      description: '12-month lease outlining monthly rent of $2,500 and maintenance obligations.',
      type: 'document',
      relevance: 'Establishes the tenancy terms, rate, and contractual duties.',
      source: 'Tenant Records',
      disclosed: true,
      hearsayConcern: false,
      authenticityStatus: 'verified',
      supportsClaims: []
    },
    {
      id: 'ev_2',
      title: 'Proof of Service Affidavit (Unsigned)',
      description: 'The notice process server affidavit left unsigned by the building maintenance worker.',
      type: 'document',
      relevance: 'Demonstrates potential jurisdictional defect in the landlord\'s eviction process.',
      source: 'Court Filing Copy',
      disclosed: true,
      hearsayConcern: true,
      authenticityStatus: 'disputed',
      supportsClaims: []
    },
    {
      id: 'ev_3',
      title: 'Rent Ledger Summary Report',
      description: 'Financial ledger report showing missing payments for two cycles.',
      type: 'document',
      relevance: 'Confirms rent arrears amount of $5,000.',
      source: 'ABC Properties portal',
      disclosed: true,
      hearsayConcern: false,
      authenticityStatus: 'verified',
      supportsClaims: []
    },
    {
      id: 'ev_4',
      title: 'Water Leak and Kitchen Mold Photo Journal',
      description: 'Time-stamped photos displaying structural mold and active leaking water lines in the kitchen.',
      type: 'photo',
      relevance: 'Supports the tenant\'s defense of Breach of Warranty of Habitability.',
      source: 'Tenant Mobile Phone',
      disclosed: true,
      hearsayConcern: false,
      authenticityStatus: 'verified',
      supportsClaims: []
    }
  ],
  claims: ['Residential Eviction for Non-Payment', 'Recovery of Accrued Back-Rent ($5,000)'],
  defenses: ['Jurisdictional Defective Notice Service', 'Constructive Eviction / Habitability Defense', 'Retaliatory Eviction']
};

export const SMITH_VS_ABC_REPORT: CaseReport = {
  overview: "This case analysis models the eviction dispute 'Smith v. ABC Properties LLC'. The landlord asserts non-payment of rent. The tenant maintains a strong defense of defective notice service and counters with severe habitability violations (unrepaired roof leaks causing mold). Our algorithms rate the overall tenant position as moderate to strong, but procedurally sensitive.",
  informationQualityRating: 90,
  verifiedFacts: [
    'A residential lease agreement was executed on June 1, 2023.',
    'Water leaks occurred repeatedly in the kitchen area from February 15, 2024 onwards.',
    'Rent payments for March and April 2024 were withheld by the tenant.'
  ],
  disputedAllegations: [
    'Whether the landlord properly served the 3-day notice in-hand.',
    'Whether the landlord delayed repairs deliberately in retaliation for tenant complaints.'
  ],
  missingCrucialInformation: [
    'Certified mail delivery receipt or independent server affidavit.',
    'Code enforcement inspection report confirming mold levels.'
  ],
  proceduralStatusSummary: 'Active discovery phase. The defendant has successfully asserted habitability defenses, setting up high-stakes evidentiary hearings.',
  claimsAndDefenses: [
    {
      name: 'Residential Eviction for Non-Payment',
      type: 'claim',
      iracIssue: 'Is the landlord entitled to recover possession of the premises for non-payment of rent?',
      iracRule: 'A landlord may evict a tenant for failure to pay rent only after serving a valid written notice to pay or quit strictly complying with statutory service guidelines.',
      overallScore: 45,
      elements: [
        {
          elementName: 'Statutory Notice Compliance',
          definition: 'Notice must be served in-hand, or via conspicuous post-and-mail if tenant is absent.',
          burdenOfProof: 'plaintiff',
          supportingFacts: ['Landlord claims notice was properly delivered to tenant\'s premises.'],
          opposingFacts: ['Tenant states notice was left in a shared common lobby basket, failing personal service.'],
          supportingEvidence: ['Self-serving maintenance worker ledger'],
          missingEvidence: ['Licensed process server affidavit'],
          admissibilityConcerns: ['Unsigned process server affidavit is inadmissible hearsay.'],
          strengthScore: 30,
          explanation: 'The lack of proper service affidavit is a fatal procedural defect, heavily undermining the landlord\'s eviction claim.'
        },
        {
          elementName: 'Arrears Existence',
          definition: 'Tenant failed to tender rent due under the lease covenants.',
          burdenOfProof: 'plaintiff',
          supportingFacts: ['Tenant admitted rent was withheld for March and April.'],
          opposingFacts: ['Rent withholding is legally excused due to material habitability failure.'],
          supportingEvidence: ['Rent Ledger Summary Report'],
          missingEvidence: [],
          admissibilityConcerns: [],
          strengthScore: 95,
          explanation: 'The debt itself is uncontested, though its enforceability is subject to affirmative defenses.'
        }
      ]
    },
    {
      name: 'Constructive Eviction (Breach of Habitability)',
      type: 'defense',
      iracIssue: 'Is the tenant\'s obligation to pay rent excused or abated by the landlord\'s failure to repair roof leaks and mold?',
      iracRule: 'A landlord breaches the statutory warranty of habitability if they fail to maintain building structures and keep units free of mold/leaks after receiving notice.',
      overallScore: 78,
      elements: [
        {
          elementName: 'Material Habitability Defect',
          definition: 'Conditions that substantially threaten tenant health or safety.',
          burdenOfProof: 'defendant',
          supportingFacts: ['Roof leaks occurred, leading to kitchen wall mold.'],
          opposingFacts: ['Landlord claims mold is minor and caused by tenant lack of ventilation.'],
          supportingEvidence: ['Water Leak and Kitchen Mold Photo Journal'],
          missingEvidence: ['Independent building inspector report'],
          admissibilityConcerns: [],
          strengthScore: 85,
          explanation: 'The photographic journal provides strong, visible proof of active structural degradation and health hazards.'
        }
      ]
    }
  ],
  plaintiffArguments: {
    legalTheory: 'The tenant is in unlawful possession of the residential premises after failing to cure material rent defaults under the written covenants of the lease. Under California CCP § 1161, a landlord has an absolute statutory right to possession and restitution of the premises upon proving that rent remains unpaid and a written notice was served, regardless of collateral habitability disputes that were not formally certified or notified in writing beforehand.',
    keyFacts: [
      'An outstanding, unpaid rent balance of $5,000 accrued and remains completely unpaid for the months of March and April 2024.',
      'The fully executed, written 1-year lease agreement strictly covenants monthly payments of $2,500 due on the first of each month without offset or deduction.',
      'No formal housing code violations or administrative agency citations were active or certified at the time the 3-day notice to pay or quit was served.'
    ],
    keyEvidence: [
      'Executed Residential Lease Agreement verifying the monthly rent rate, payment terms, and notice clauses.',
      'Certified Real-Time Rent Ledger Summary Report verifying the outstanding rent quantum of $5,000.',
      'Sworn Process Server Affidavit stating the notice to pay or quit was served at the unit door.'
    ],
    authorities: [
      'California Code of Civil Procedure § 1161(2) (Unlawful Detainer for Non-Payment)',
      'California Civil Code § 1942 (Tenant statutory repair and deduct offsets requiring reasonable prior written notice)'
    ],
    objections: [
      'Object to the tenant\'s photo journal of kitchen mold on the grounds of lack of foundation and lack of authentication, as there are no independent lab reports or expert inspections confirming toxic spore levels.',
      'Object to any testimony regarding verbal repair requests as barred by the parol evidence rule and the integration clause of the written lease agreement.'
    ]
  },
  defendantArguments: {
    legalTheory: 'The landlord\'s eviction action is procedurally defective and void ab initio because the landlord failed to satisfy strict jurisdictional notice service requirements. Factual and legal offsets apply in full due to the landlord\'s material breach of the statutory warranty of habitability, as the landlord maintained active, hazardous water leaks and toxic mold infestations despite actual notice, abating the tenant\'s rent obligations.',
    keyFacts: [
      'The 3-day notice to pay or quit was left unattended in a shared, public lobby mailbox basket, failing personal or substituted service requirements under CCP § 1162.',
      'No copy of the 3-day notice was ever delivered in-hand to the tenant or mailed via registered/certified mail as required by law.',
      'Severe structural roof leaks and kitchen mold were reported in writing to management on February 15, 2024, and left completely unrepaired for over 60 days.'
    ],
    keyEvidence: [
      'Water Leak and Kitchen Mold Photo Journal verifying extensive water intrusion, damaged plaster, and visible toxic mold in eating areas.',
      'Unsigned Proof of Service Affidavit showing that the process server failed to secure personal delivery or legally compliant posting and mailing.',
      'Written repair demands and electronic chat logs sent to ABC Properties on February 15, 2024, proving actual notice.'
    ],
    authorities: [
      'California Code of Civil Procedure § 1162 (Strict notice service requirements as a jurisdictional prerequisite)',
      'California Civil Code § 1941.1 (State statutory standards for tenantable dwellings)',
      'Green v. Superior Court, 10 Cal. 3d 616 (1974) (Holding that breach of the warranty of habitability is a complete defense to an unlawful detainer action)'
    ],
    objections: [
      'Object to the unsigned, unsworn process server service affidavit as inadmissible hearsay and lacking authentication under Evidence Code § 1200.',
      'Object to the landlord\'s rent ledger to the extent it fails to reflect legally mandated rent offsets and abatements for periods of uninhabitable occupancy.'
    ]
  },
  judicialConcerns: [
    'Strict notice service compliance: Housing courts routinely dismiss evictions for any service deviation.',
    'Warranty of Habitability: Eviction actions cannot succeed if the unit is legally uninhabitable.'
  ],
  juryConcerns: [
    'Fairness and Health: Landlords who ignore structural water mold while demanding rent are highly unpopular with juries.'
  ],
  outcomes: [
    {
      outcomeName: 'Eviction Dismissed (Notice Defect)',
      probabilityRange: '35% - 40%',
      probabilityValue: 35,
      confidenceLevel: 'high',
      keySupportingFactors: ['Unsigned service affidavit', 'Shared mailbox delivery admission'],
      keyNegativeFactors: ['Landlord may cure and refile immediately'],
      assumptions: ['Court holds evidentiary hearing on service.']
    },
    {
      outcomeName: 'Settlement / Rent Abatement',
      probabilityRange: '30% - 35%',
      probabilityValue: 30,
      confidenceLevel: 'high',
      keySupportingFactors: ['Mutual interest in avoiding trial', 'Mold photos create massive landlord risk'],
      keyNegativeFactors: [],
      assumptions: ['Parties engage in court-ordered mediation.']
    },
    {
      outcomeName: 'Plaintiff Eviction Judgment',
      probabilityRange: '20% - 25%',
      probabilityValue: 20,
      confidenceLevel: 'moderate',
      keySupportingFactors: ['Admitted non-payment of rent'],
      keyNegativeFactors: ['Habitability defenses established'],
      assumptions: ['Court finds service was sub-contracted properly.']
    }
  ],
  deadlines: [
    {
      id: 'dl_1',
      label: 'Response to Interrogatories',
      dueDate: '2024-05-20',
      calculationMethod: '30 days after service of discovery requests.',
      ruleReliedOn: 'California Civil Procedure Code § 2030',
      status: 'unverified',
      riskLevel: 'high'
    },
    {
      id: 'dl_2',
      label: 'Document Production',
      dueDate: '2024-06-03',
      calculationMethod: '30 days after document demand service.',
      ruleReliedOn: 'California Civil Procedure Code § 2031',
      status: 'unverified',
      riskLevel: 'high'
    },
    {
      id: 'dl_3',
      label: 'Deposition of Plaintiff',
      dueDate: '2024-06-15',
      calculationMethod: 'At least 10 days after deposition notice service.',
      ruleReliedOn: 'California Civil Procedure Code § 2025',
      status: 'unverified',
      riskLevel: 'medium'
    }
  ],
  recommendations: [
    {
      id: 'rec_1',
      action: 'File Motion to Dismiss on defective service grounds.',
      reason: 'The unsigned affidavit demonstrates the process server failed personal delivery. Dismissing early avoids trial.',
      priority: 'high',
      riskIfIgnored: 'Proceeding to merits without challenging service waives service objections.'
    },
    {
      id: 'rec_2',
      action: 'Acquire county housing code inspection report.',
      reason: 'Official county documentation of mold and leaks forms an unassailable evidentiary basis for habitability defenses.',
      priority: 'high',
      riskIfIgnored: 'Tenant-only photos may be contested as exaggerated or lacking foundation.'
    }
  ],
  sourcesAndAssumptions: [
    'California Civil Code §§ 1941, 1942.5 (Retaliation)',
    'Code of Civil Procedure § 1161 (Eviction Procedure)'
  ],
  escalationRequired: false
};
