/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Core Case Intake Types
export interface Party {
  id: string;
  name: string;
  role: 'plaintiff' | 'defendant';
  type: 'individual' | 'organization';
  represented: boolean;
  claims: string[];
  defenses: string[];
  voucherType?: 'none' | 'section8' | 'public_housing' | 'vash' | 'lihtc' | 'other';
  disabilityStatus?: 'none' | 'mobility' | 'cognitive' | 'animal' | 'other';
  serviceMethod?: 'none' | 'personal' | 'defective_lobby' | 'defective_none' | 'substituted' | 'nail_and_mail';
}

export interface EvidenceItem {
  id: string;
  title: string;
  description: string;
  type: 'document' | 'email' | 'message' | 'photo' | 'audio' | 'witness_statement' | 'other';
  relevance: string;
  source: string;
  disclosed: boolean;
  hearsayConcern: boolean;
  authenticityStatus: 'verified' | 'unverified' | 'disputed';
  supportsClaims: string[]; // IDs of claims/defenses supported
}

export interface FactItem {
  id: string;
  description: string;
  date: string;
  status: 'admitted' | 'disputed' | 'allegation' | 'unknown';
  evidenceIds: string[];
}

export interface CaseIntake {
  title: string;
  caseType: 'landlord_tenant' | 'small_claims' | 'contract_dispute' | 'debt_collection' | 'employment';
  jurisdiction: string;
  courtName: string;
  currentStage: string;
  amountInControversy: number;
  remedyRequested: string;
  parties: Party[];
  facts: FactItem[];
  evidence: EvidenceItem[];
  claims: string[];
  defenses: string[];
}

// Procedural Flow Chart Types
export interface CourtNode {
  id: string;
  label: string;
  description: string;
  status: 'completed' | 'current' | 'upcoming' | 'locked' | 'warning';
  phase: 'pre_filing' | 'pleadings' | 'discovery' | 'pretrial' | 'trial' | 'judgment' | 'appeal';
  requiredFilings: string[];
  deadlines: string;
}

// Analysis Engine Result Types
export interface LegalElementAnalysis {
  elementName: string;
  definition: string;
  burdenOfProof: 'plaintiff' | 'defendant';
  supportingFacts: string[];
  opposingFacts: string[];
  supportingEvidence: string[];
  missingEvidence: string[];
  admissibilityConcerns: string[];
  strengthScore: number; // 0 - 100
  explanation: string;
}

export interface ClaimDefenseAnalysis {
  name: string;
  type: 'claim' | 'defense';
  iracIssue: string;
  iracRule: string;
  elements: LegalElementAnalysis[];
  overallScore: number; // 0 - 100
}

export interface AdversarialArgument {
  legalTheory: string;
  keyFacts: string[];
  keyEvidence: string[];
  authorities: string[];
  objections: string[];
}

export interface PotentialOutcome {
  outcomeName: string;
  probabilityRange: string; // e.g., "55% - 70%"
  probabilityValue: number; // e.g., 62 for chart
  confidenceLevel: 'low' | 'moderate' | 'high';
  keySupportingFactors: string[];
  keyNegativeFactors: string[];
  assumptions: string[];
}

export interface DeadlineItem {
  id: string;
  label: string;
  dueDate: string;
  calculationMethod: string;
  ruleReliedOn: string;
  status: 'unverified' | 'verified' | 'completed' | 'missed';
  riskLevel: 'low' | 'medium' | 'high';
}

export interface CaseReport {
  overview: string;
  informationQualityRating: number; // 0 - 100
  verifiedFacts: string[];
  disputedAllegations: string[];
  missingCrucialInformation: string[];
  proceduralStatusSummary: string;
  claimsAndDefenses: ClaimDefenseAnalysis[];
  plaintiffArguments: AdversarialArgument;
  defendantArguments: AdversarialArgument;
  judicialConcerns: string[];
  juryConcerns: string[];
  outcomes: PotentialOutcome[];
  deadlines: DeadlineItem[];
  recommendations: {
    id: string;
    action: string;
    reason: string;
    priority: 'low' | 'medium' | 'high';
    riskIfIgnored: string;
  }[];
  sourcesAndAssumptions: string[];
  escalationRequired: boolean;
  escalationReason?: string;
}

// Mock Courtroom types
export interface CourtroomMessage {
  id: string;
  sender: 'judge' | 'plaintiff_counsel' | 'defense_counsel' | 'witness' | 'user';
  text: string;
  timestamp: string;
}

export interface CourtroomSession {
  mode: 'hearing' | 'examination' | 'settlement';
  character: string; // e.g., "Judge Arthur Vance"
  messages: CourtroomMessage[];
}

// Live Sensor Telemetry Dashboard Types
export interface SensorMetric {
  timestamp: string;
  courtroomNoise: number; // dB
  docketQueueSize: number; // number of cases in queue
  serverCpuLoad: number; // %
  filingStreamRate: number; // cases per minute
  objectionDetections: number; // objections flagged in live hearings
}

export interface TelemetryAlert {
  id: string;
  timestamp: string;
  metric: 'noise' | 'docket' | 'cpu' | 'filings' | 'objections';
  severity: 'info' | 'warning' | 'critical';
  message: string;
  acknowledged: boolean;
}
