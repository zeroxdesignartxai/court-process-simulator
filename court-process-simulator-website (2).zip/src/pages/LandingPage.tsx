/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Gavel, Scale, Activity, ArrowRight, ShieldCheck, Cpu, Play, Plus } from 'lucide-react';
import { Card, CardContent, Button, Badge } from '../components/UI';
import { CaseIntake } from '../types';

interface LandingPageProps {
  cases: CaseIntake[];
  onSelectCase: (caseTitle: string) => void;
  onLaunchNewCase: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ cases, onSelectCase, onLaunchNewCase }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-indigo-500/30 selection:text-indigo-200 overflow-x-hidden">
      
      {/* Background Decor */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[400px] bg-indigo-900/10 rounded-full blur-[160px] pointer-events-none z-0" />
      
      {/* HEADER */}
      <header className="border-b border-slate-900/80 px-8 py-5 flex items-center justify-between z-10 relative">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-950/40">
            <Gavel className="w-4.5 h-4.5 text-slate-100" />
          </div>
          <div>
            <h2 className="text-xs font-black tracking-widest text-slate-100 uppercase">LEGAL SIMULATOR</h2>
            <p className="text-[9px] text-slate-500 font-mono">Case Strategy Workspace</p>
          </div>
        </div>
        
        <Badge variant="purple" className="px-2.5 py-1">
          <ShieldCheck className="w-3 h-3 text-purple-400" />
          Workspace Ready
        </Badge>
      </header>

      {/* HERO SECTION */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-6 py-16 flex flex-col items-center justify-center text-center space-y-12 z-10 relative">
        
        <div className="space-y-4 max-w-3xl">
          <Badge variant="default" className="px-3 py-1 text-[10px]">
            AI-Assisted Litigation Preparation
          </Badge>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-100 uppercase font-sans leading-tight">
            Build Your Case Before <br />
            <span className="text-indigo-500">You Enter Court</span>
          </h1>
          <p className="text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto">
            Organize facts and evidence, map deadlines, stress-test arguments, and practice hearing scenarios
            in one focused legal preparation workspace. Every AI result is an estimate that should be checked
            against current law and qualified legal advice.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <Button 
            onClick={onLaunchNewCase} 
            variant="primary" 
            size="lg" 
            icon={Plus}
            className="w-full sm:w-auto px-8"
          >
            Launch Custom Intake
          </Button>
          <Button 
            onClick={() => {
              const sanchezCase = cases.find(c => c.title.toLowerCase().includes('sanchez'));
              onSelectCase(sanchezCase ? sanchezCase.title : (cases[0]?.title || ''));
            }} 
            variant="outline" 
            size="lg" 
            icon={Play}
            className="w-full sm:w-auto px-8"
          >
            Open Sanchez Case
          </Button>
        </div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full pt-6">
          <Card className="text-left bg-slate-900/50 backdrop-blur-sm border-slate-850">
            <CardContent className="p-6 space-y-3">
              <div className="w-10 h-10 bg-indigo-950 border border-indigo-800/30 text-indigo-400 rounded-xl flex items-center justify-center">
                <Scale className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black uppercase text-slate-200">Procedure & Deadline Map</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Build a step-by-step timeline for notices, responses, discovery, motions, hearings, trial, and post-trial work.
              </p>
            </CardContent>
          </Card>

          <Card className="text-left bg-slate-900/50 backdrop-blur-sm border-slate-850">
            <CardContent className="p-6 space-y-3">
              <div className="w-10 h-10 bg-emerald-950 border border-emerald-800/30 text-emerald-400 rounded-xl flex items-center justify-center">
                <Cpu className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black uppercase text-slate-200">Interactive Hearing Practice</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Practice direct examination, objections, exhibit foundations, and answers to difficult questions in a simulated courtroom.
              </p>
            </CardContent>
          </Card>

          <Card className="text-left bg-slate-900/50 backdrop-blur-sm border-slate-850">
            <CardContent className="p-6 space-y-3">
              <div className="w-10 h-10 bg-purple-950 border border-purple-800/30 text-purple-400 rounded-xl flex items-center justify-center">
                <Activity className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-black uppercase text-slate-200">Case Strategy Signals</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Review simulated risk, readiness, evidence gaps, argument strength, and workflow alerts without presenting them as court predictions.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Case File Previews */}
        <div className="w-full text-left space-y-4 pt-10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider">Active Legal Dossiers</h3>
              <p className="text-xs text-slate-500">Select an existing litigation case file to load the telemetry simulator dashboard</p>
            </div>
            <Badge variant="secondary">{cases.length} Loaded {cases.length === 1 ? 'File' : 'Files'}</Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cases.map((cs) => {
              const isDetainer = cs.caseType === 'landlord_tenant';
              return (
                <button
                  type="button"
                  key={cs.title}
                  onClick={() => onSelectCase(cs.title)}
                  className="w-full text-left bg-slate-900 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 p-5 rounded-2xl flex items-center justify-between gap-4 cursor-pointer transition-all duration-150 group"
                  aria-label={`Open case ${cs.title}`}
                >
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <Badge variant={isDetainer ? "success" : "info"}>
                        {cs.caseType.replace('_', ' ')}
                      </Badge>
                      <span className="text-[10px] text-slate-500 font-mono">{cs.courtName}</span>
                    </div>
                    <h4 className="text-sm font-black text-slate-200 group-hover:text-indigo-400 transition-colors truncate">
                      {cs.title}
                    </h4>
                    <p className="text-xs text-slate-400 line-clamp-1">{cs.remedyRequested}</p>
                  </div>
                  <div className="w-9 h-9 bg-slate-950 group-hover:bg-indigo-600 rounded-lg flex items-center justify-center transition-colors text-slate-500 group-hover:text-slate-100 shrink-0 shadow-inner">
                    <ArrowRight className="w-4.5 h-4.5 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-900/80 px-8 py-6 text-center z-10 relative bg-slate-950/60">
        <p className="text-[10px] text-slate-600 font-mono uppercase tracking-widest leading-relaxed">
          CASE-PREPARATION SIMULATOR • VERIFY ALL AI OUTPUTS • NOT LEGAL ADVICE OR AN ATTORNEY-CLIENT RELATIONSHIP
        </p>
      </footer>

    </div>
  );
};
