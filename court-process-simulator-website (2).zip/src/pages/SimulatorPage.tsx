/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Gavel, 
  MessageSquare, 
  Send, 
  User, 
  ShieldAlert, 
  Play, 
  Info, 
  AlertCircle, 
  HelpCircle,
  Scale,
  FileText,
  ListTodo,
  BookmarkPlus,
  ClipboardCopy,
  Check,
  FileCheck,
  Cpu,
  Sparkles,
  ChevronRight,
  Plus,
  Trash2
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Button, Select, Badge } from '../components/UI';
import { CaseIntake, CourtroomMessage } from '../types';
import MockCourtroom from '../components/MockCourtroom';

interface SimulatorPageProps {
  activeCase: CaseIntake;
}

const DEFAULT_PRECEDENTS = [
  { id: 'p1', title: 'Resicom LLC v. Sanchez', citation: '412 F.3d 204 (2023)', summary: 'Reaffirmed that standard landlord-tenant service requires strict adherence to physical notices, and constructive service fails if tenant is in active occupancy.', category: 'Service of Process' },
  { id: 'p2', title: 'McIntyre v. Metro Housing', citation: '89 Wash. 2d 102 (2019)', summary: 'Failing to serve notices at the actual unit of residency, or leaving notices in public corridors, renders the subsequent legal filing void ab initio.', category: 'Condition Precedent' },
  { id: 'p3', title: 'Celotex Corp. v. Catrett', citation: '477 U.S. 317 (1986)', summary: 'The moving party only needs to point out that there is an absence of evidence supporting the nonmoving party\'s case on summary judgment.', category: 'Summary Judgment' },
  { id: 'p4', title: 'Hadley v. Baxendale', citation: '9 Exch. 341 (1854)', summary: 'Establishes the rule for consequential damages in contract cases, limiting recovery to foreseeable losses.', category: 'Contract Damages' }
];

const CHARACTERS = [
  { id: 'Judge Arthur Vance', name: 'Judge Arthur Vance', role: 'judge', subtitle: 'Presiding Judicial Magistrate', avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&fit=crop&q=80' },
  { id: 'Ms. Hastings', name: 'Ms. Hastings (Opposing Counsel)', role: 'defense_counsel', subtitle: 'AHM Lead Trial Advocate', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&fit=crop&q=80' },
  { id: 'Mrs. Ramirez', name: 'Mrs. Ramirez (Lead Witness)', role: 'witness', subtitle: 'Building Caretaker / Server', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&fit=crop&q=80' },
  { id: 'Mediator Vance', name: 'Mediator Vance', role: 'mediator', subtitle: 'ADR Settlement Specialist', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&fit=crop&q=80' }
];

const PRESET_RESPONSES: Record<string, string[]> = {
  'Judge Arthur Vance': [
    "Your Honor, the process server failed to complete personal hand-delivery; the summons was merely left in a common area basket.",
    "The amount in controversy does not support punitive damages under state landlord-tenant code.",
    "We request a brief recess to inspect the unsigned affidavit of service and call the process server.",
    "Our client complied with all pre-filing notice periods, as documented in our certified mail receipt."
  ],
  'Ms. Hastings': [
    "The written residential lease contains an explicit waiver of jury trial for arrears disputes.",
    "Your client remained in possession of the premises for four consecutive months without raising any formal habitability complaints.",
    "We object to the introduction of unauthenticated email correspondence from January 10th.",
    "The landlord completed repairs within 48 hours of receiving written notice, which constitutes reasonable diligence."
  ],
  'Mrs. Ramirez': [
    "Mrs. Ramirez, can you confirm if you personally handed the physical summons to the defendant?",
    "Were you present in the building when the main service pipe cracked on January 10th?",
    "Did you write or sign the entries in the building caretaker maintenance log on that day?",
    "Did you observe any active mold remediation or clean-up efforts in the bathroom ceiling?"
  ],
  'Mediator Vance': [
    "Our client is willing to settle for a 50% abatement of the alleged rent arrears in exchange for a mutual release.",
    "We propose an immediate, mutual lease termination and full release of all civil claims by both parties.",
    "What is the opposing party's bottom-line financial expectation to settle this dispute out of court today?",
    "We are prepared to pay $3,500 over a 3-month payment plan to fully resolve this matter without trial."
  ]
};

export const SimulatorPage: React.FC<SimulatorPageProps> = ({ activeCase }) => {
  const [mode, setMode] = useState<'hearing' | 'examination' | 'settlement'>('hearing');
  const [character, setCharacter] = useState(CHARACTERS[0]);
  const [messages, setMessages] = useState<CourtroomMessage[]>([
    { id: '1', sender: 'judge', text: 'Counsel, we are on the record in the matter of ' + activeCase.title + '. You may proceed with your opening arguments or raise any prelim motions.', timestamp: new Date().toLocaleTimeString() }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // New states for the All-in-One Legal Strategy & Case Management Engine
  const [activeTab, setActiveTab] = useState<'courtroom' | 'argument' | 'dismissal' | 'drafting' | 'precedent'>('courtroom');
  const [stance, setStance] = useState<'plaintiff' | 'defense'>('defense');
  const [loadingStrategy, setLoadingStrategy] = useState(false);
  const [strategyResult, setStrategyResult] = useState<any>(null);

  const [opposingArgs, setOpposingArgs] = useState('Opposing party asserts that physical notice delivery was fully compliant and arrears are outstanding.');
  const [loadingDismissal, setLoadingDismissal] = useState(false);
  const [dismissalResult, setDismissalResult] = useState<any>(null);

  const [templateType, setTemplateType] = useState<'motion_dismiss' | 'complaint' | 'answer' | 'discovery_request'>('motion_dismiss');
  const [draftMetadata, setDraftMetadata] = useState({
    partyName: activeCase.defendantName || 'AHM RESICOM LLC',
    opposingParty: activeCase.plaintiffName || 'MAURICIO SANCHEZ',
    courtName: activeCase.jurisdiction || 'Superior Court of Washington',
    citationText: 'Rule 12(b)(5)'
  });
  const [loadingDraft, setLoadingDraft] = useState(false);
  const [draftResult, setDraftResult] = useState<any>(null);
  const [draftCopied, setDraftCopied] = useState(false);

  // Precedents tracker repository state
  const [precedents, setPrecedents] = useState<any[]>(DEFAULT_PRECEDENTS);
  const [newPrecedentTitle, setNewPrecedentTitle] = useState('');
  const [newPrecedentCitation, setNewPrecedentCitation] = useState('');
  const [newPrecedentSummary, setNewPrecedentSummary] = useState('');
  const [newPrecedentCategory, setNewPrecedentCategory] = useState('General');

  // Triggering hooks to retrieve content from backend Legal Engine API
  const handleFetchStrategy = async () => {
    setLoadingStrategy(true);
    try {
      const response = await fetch('/api/legal-engine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'strategy',
          caseData: activeCase,
          payload: { stance }
        })
      });
      const data = await response.json();
      setStrategyResult(data.analysis || data);
    } catch (err) {
      console.error('Error fetching legal strategy:', err);
    } finally {
      setLoadingStrategy(false);
    }
  };

  const handleFetchDismissal = async () => {
    setLoadingDismissal(true);
    try {
      const response = await fetch('/api/legal-engine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'dismissal',
          caseData: activeCase,
          payload: { opposingArguments: opposingArgs }
        })
      });
      const data = await response.json();
      setDismissalResult(data.analysis || data);
    } catch (err) {
      console.error('Error fetching dismissal grounds:', err);
    } finally {
      setLoadingDismissal(false);
    }
  };

  const handleFetchDraft = async () => {
    setLoadingDraft(true);
    setDraftCopied(false);
    try {
      const response = await fetch('/api/legal-engine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'draft',
          caseData: activeCase,
          payload: { templateType, metadata: draftMetadata }
        })
      });
      const data = await response.json();
      setDraftResult(data);
    } catch (err) {
      console.error('Error drafting document:', err);
    } finally {
      setLoadingDraft(false);
    }
  };

  const handleAddPrecedent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPrecedentTitle || !newPrecedentCitation) return;
    const item = {
      id: 'p_' + Date.now(),
      title: newPrecedentTitle,
      citation: newPrecedentCitation,
      summary: newPrecedentSummary || 'No summary provided.',
      category: newPrecedentCategory
    };
    setPrecedents([item, ...precedents]);
    setNewPrecedentTitle('');
    setNewPrecedentCitation('');
    setNewPrecedentSummary('');
  };

  const handleCopyDraft = () => {
    if (!draftResult?.draft) return;
    navigator.clipboard.writeText(draftResult.draft);
    setDraftCopied(true);
    setTimeout(() => setDraftCopied(false), 2000);
  };

  // Scroll to bottom on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMsg: CourtroomMessage = {
      id: Math.random().toString(),
      sender: 'user',
      text: inputText,
      timestamp: new Date().toLocaleTimeString()
    };

    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInputText('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/mock-court', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          character: character.name,
          messages: updatedMessages,
          currentCase: activeCase
        })
      });

      const data = await response.json();
      
      const charMsg: CourtroomMessage = {
        id: Math.random().toString(),
        sender: character.role as any,
        text: data.reply || 'Silence in court.',
        timestamp: new Date().toLocaleTimeString()
      };

      setMessages((prev) => [...prev, charMsg]);
    } catch (err) {
      console.error(err);
      // Fallback
      const fallbackMsg: CourtroomMessage = {
        id: Math.random().toString(),
        sender: character.role as any,
        text: `[FALLBACK RESPONSE] Understood, counsel. I have received your filing in the ${mode} session of ${activeCase.title}. Let us proceed to examine the authenticity of the process server affidavit.`,
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="simulator_page_root">
      
      {/* HEADER WITH METADATA SUMMARY */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-indigo-600/10 rounded-full filter blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <Badge variant="purple" id="header_badge_engine">Legal Strategy & Case Management Engine</Badge>
              <Badge variant="outline" className="text-[10px] text-slate-400 border-slate-800 uppercase font-mono">
                {activeCase.caseType?.replace('_', ' ')}
              </Badge>
            </div>
            <h2 className="text-xl font-black text-slate-100 uppercase tracking-tight flex items-center gap-2" id="header_title">
              <Scale className="w-5 h-5 text-indigo-400" />
              {activeCase.title || 'Untitled Case Strategy'}
            </h2>
            <p className="text-xs text-slate-400 max-w-2xl">
              Active Jurisdiction: <strong className="text-slate-300 font-medium">{activeCase.jurisdiction || 'Federal District Court'}</strong> • Amount in Controversy: <strong className="text-indigo-400 font-mono font-bold">${activeCase.amountInControversy?.toLocaleString() || 'Unknown'}</strong>
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">AI Coprocessor:</span>
            <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800/80 rounded-xl px-3 py-1.5 shadow-inner">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-mono font-bold text-emerald-400 tracking-wide uppercase">Active & Ready</span>
            </div>
          </div>
        </div>
      </div>

      {/* METRIC HORIZONTAL STATS RIBBON */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900/45 border border-slate-850 p-4 rounded-xl flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center border border-indigo-500/10">
            <MessageSquare className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Sim Mode</div>
            <div className="text-xs font-black text-slate-200 uppercase mt-0.5">{mode}</div>
          </div>
        </div>
        <div className="bg-slate-900/45 border border-slate-850 p-4 rounded-xl flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center border border-amber-500/10">
            <Cpu className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Active Stance</div>
            <div className="text-xs font-black text-slate-200 uppercase mt-0.5">{stance}</div>
          </div>
        </div>
        <div className="bg-slate-900/45 border border-slate-850 p-4 rounded-xl flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center border border-emerald-500/10">
            <FileCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Draft Template</div>
            <div className="text-xs font-black text-slate-200 uppercase mt-0.5">{templateType.replace('_', ' ')}</div>
          </div>
        </div>
        <div className="bg-slate-900/45 border border-slate-850 p-4 rounded-xl flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-pink-500/10 flex items-center justify-center border border-pink-500/10">
            <Scale className="w-4 h-4 text-pink-400" />
          </div>
          <div>
            <div className="text-[9px] font-mono text-slate-500 uppercase tracking-wider">Saved Precedents</div>
            <div className="text-xs font-black text-slate-200 uppercase mt-0.5">{precedents.length} Cases</div>
          </div>
        </div>
      </div>

      {/* CORE NAVIGATION TAB SWITCHER */}
      <div className="bg-slate-900/80 border border-slate-850 p-1.5 rounded-xl flex flex-wrap gap-1 shadow-md">
        <button
          onClick={() => setActiveTab('courtroom')}
          className={`flex-1 min-w-[120px] text-xs font-bold py-2.5 px-3 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'courtroom'
              ? 'bg-indigo-600 text-slate-100 shadow-md shadow-indigo-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40'
          }`}
          id="tab_btn_courtroom"
        >
          <Gavel className="w-3.5 h-3.5" />
          Courtroom Arena
        </button>

        <button
          onClick={() => setActiveTab('argument')}
          className={`flex-1 min-w-[120px] text-xs font-bold py-2.5 px-3 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'argument'
              ? 'bg-indigo-600 text-slate-100 shadow-md shadow-indigo-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40'
          }`}
          id="tab_btn_argument"
        >
          <Scale className="w-3.5 h-3.5" />
          Argument Builder
        </button>

        <button
          onClick={() => setActiveTab('dismissal')}
          className={`flex-1 min-w-[120px] text-xs font-bold py-2.5 px-3 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'dismissal'
              ? 'bg-indigo-600 text-slate-100 shadow-md shadow-indigo-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40'
          }`}
          id="tab_btn_dismissal"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          Dismissal Analyst
        </button>

        <button
          onClick={() => setActiveTab('drafting')}
          className={`flex-1 min-w-[120px] text-xs font-bold py-2.5 px-3 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'drafting'
              ? 'bg-indigo-600 text-slate-100 shadow-md shadow-indigo-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40'
          }`}
          id="tab_btn_drafting"
        >
          <FileText className="w-3.5 h-3.5" />
          Drafting Assistant
        </button>

        <button
          onClick={() => setActiveTab('precedent')}
          className={`flex-1 min-w-[120px] text-xs font-bold py-2.5 px-3 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'precedent'
              ? 'bg-indigo-600 text-slate-100 shadow-md shadow-indigo-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40'
          }`}
          id="tab_btn_precedent"
        >
          <BookmarkPlus className="w-3.5 h-3.5" />
          Precedent Tracker
        </button>
      </div>

      {/* RENDER ACTIVE TAB VIEW CONTENT */}
      <div className="w-full">
        
        {/* TAB 1: COURTROOM SIMULATOR ARENA */}
        {activeTab === 'courtroom' && (
          <MockCourtroom currentCase={activeCase} />
        )}

        {/* DEPRECATED SIMPLE COURTROOM (DEACTIVATED) */}
        {false && activeTab === 'courtroom' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="view_courtroom_root">
            
            {/* LEFT COLUMN: SIMULATOR PANEL CONTROLS */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Session Configuration</CardTitle>
                  <CardDescription>Select hearing mode and active courtroom participant.</CardDescription>
                </CardHeader>
                <CardContent className="p-5 space-y-4">
                  <Select 
                    label="Trial Session Mode" 
                    value={mode} 
                    onChange={(e) => setMode(e.target.value as any)} 
                    options={[
                      { value: 'hearing', label: 'Motion Hearing (Argument)' },
                      { value: 'examination', label: 'Witness Examination (Q&A)' },
                      { value: 'settlement', label: 'Settlement Conference (ADR)' }
                    ]}
                  />

                  <div className="space-y-2">
                    <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Active Participant</span>
                    <div className="grid grid-cols-1 gap-2">
                      {CHARACTERS.map((char) => {
                        const isSelected = character.id === char.id;
                        return (
                          <button
                            key={char.id}
                            onClick={() => setCharacter(char)}
                            className={`w-full text-left p-3 rounded-xl border flex items-center gap-3 transition-all duration-150 cursor-pointer ${
                              isSelected 
                                ? 'bg-indigo-600/10 border-indigo-500 ring-2 ring-indigo-500/20' 
                                : 'bg-slate-950/40 border-slate-850 hover:bg-slate-950/80'
                            }`}
                          >
                            <div className="w-10 h-10 rounded-full bg-slate-850 border border-slate-800 overflow-hidden shrink-0">
                              <img 
                                src={char.avatar} 
                                alt={char.name} 
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="min-w-0">
                              <h4 className={`text-xs font-black truncate ${isSelected ? 'text-indigo-400' : 'text-slate-200'}`}>
                                {char.name}
                              </h4>
                              <p className="text-[10px] text-slate-500 truncate mt-0.5">{char.subtitle}</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Rules of engagement */}
                  <div className="p-4 bg-slate-950/40 border border-slate-850 rounded-xl space-y-2 text-[11px] text-slate-400 leading-relaxed">
                    <div className="flex items-center gap-1.5 font-bold text-indigo-400 uppercase tracking-widest text-[9px]">
                      <Info className="w-4.5 h-4.5 text-indigo-400 shrink-0" />
                      Trial Rules of Engagement
                    </div>
                    <p>When examinations are active, you can formulate standard legal questions.</p>
                    <p>For motion arguments, defend your positions citing local codes, rules of civil procedure, or lack of licensed service affidavits.</p>
                  </div>

                </CardContent>
              </Card>
            </div>

            {/* RIGHT COLUMN: INTERACTIVE SPEECH CHAT LOG */}
            <div className="lg:col-span-2">
              <Card className="h-[550px] flex flex-col justify-between overflow-hidden border-slate-850/80">
                <CardHeader className="bg-slate-900/30 p-4 border-b border-slate-850">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4.5 h-4.5 text-indigo-400" />
                      <CardTitle>Courtroom Speech Log</CardTitle>
                    </div>
                    <Badge variant="purple">Trial Session Mode: {mode}</Badge>
                  </div>
                </CardHeader>

                {/* MESSAGE SCROLLING AREA */}
                <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-950/20">
                  {messages.map((msg) => {
                    const isUser = msg.sender === 'user';
                    const senderMeta = CHARACTERS.find((c) => c.role === msg.sender) || { name: 'Presiding Judge', avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&fit=crop&q=80' };
                    
                    return (
                      <div key={msg.id} className={`flex gap-3 max-w-[85%] ${isUser ? 'ml-auto flex-row-reverse text-right' : 'mr-auto'}`}>
                        
                        {/* Avatar icon */}
                        <div className="w-9 h-9 rounded-full bg-slate-900 border border-slate-800 overflow-hidden shrink-0 shadow-md">
                          {isUser ? (
                            <img 
                              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&fit=crop&q=80" 
                              alt="Mauricio S." 
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <img 
                              src={senderMeta.avatar} 
                              alt={senderMeta.name} 
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>

                        <div className="space-y-1 min-w-0">
                          <div className="flex items-center gap-2 justify-end md:justify-start flex-row-reverse md:flex-row">
                            <span className="text-[10px] font-black text-slate-300 uppercase">
                              {isUser ? 'Counsel (You)' : senderMeta.name}
                            </span>
                            <span className="text-[9px] font-mono text-slate-600">{msg.timestamp}</span>
                          </div>
                          
                          <div className={`p-3.5 rounded-2xl text-xs leading-relaxed text-left ${
                            isUser 
                              ? 'bg-indigo-600 text-slate-100 rounded-tr-none shadow-md shadow-indigo-950/25' 
                              : 'bg-slate-900 border border-slate-850 text-slate-200 rounded-tl-none'
                          }`}>
                            {msg.text}
                          </div>
                        </div>

                      </div>
                    );
                  })}

                  {/* Typing indicator */}
                  {isTyping && (
                    <div className="flex gap-3 max-w-[85%] mr-auto items-center">
                      <div className="w-9 h-9 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-slate-500 animate-pulse text-[10px]">
                        ...
                      </div>
                      <div className="p-3 bg-slate-900/60 border border-slate-850 text-slate-500 text-xs rounded-2xl rounded-tl-none font-mono font-medium animate-pulse">
                        {character.name} is formulating a response...
                      </div>
                    </div>
                  )}

                  <div ref={scrollRef} />
                </div>

                {/* INPUT INPUT BOX */}
                <div className="p-4 bg-slate-900/30 border-t border-slate-850 space-y-3">
                  {/* Preset Options Dropdown */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 justify-between">
                    <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">
                      Pre-formulated Statements & Questions:
                    </span>
                    <select
                      value=""
                      onChange={(e) => {
                        if (e.target.value) {
                          setInputText(e.target.value);
                        }
                      }}
                      className="w-full sm:w-auto max-w-full bg-slate-950 border border-slate-850 rounded-lg px-3 py-1.5 text-xs text-indigo-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="" disabled>-- Select a pre-formulated statement --</option>
                      {(PRESET_RESPONSES[character.id] || []).map((preset, idx) => (
                        <option key={idx} value={preset}>
                          {preset.length > 70 ? preset.substring(0, 67) + '...' : preset}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center gap-3">
                    <input 
                      type="text" 
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder={`Formulate legal speech to ${character.name}...`}
                      className="flex-1 bg-slate-950 border border-slate-850 rounded-xl px-4 py-3 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 transition-all"
                    />
                    <Button onClick={handleSend} variant="primary" size="md" icon={Send} className="px-5">
                      Speak
                    </Button>
                  </div>
                </div>

              </Card>
            </div>

          </div>
        )}

        {/* TAB 2: ARGUMENT BUILDER */}
        {activeTab === 'argument' && (
          <div className="space-y-6 animate-fade-in" id="view_argument_root">
            <Card>
              <CardHeader className="border-b border-slate-850/60">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <CardTitle className="text-sm font-black text-slate-100 flex items-center gap-2">
                      <Scale className="w-4 h-4 text-indigo-400" />
                      Litigation Argument Builder
                    </CardTitle>
                    <CardDescription className="text-xs">
                      Analyze the legal threshold of the claims, formulate strategic arguments, cite binding local code authorities, and prepare preemptive rebuttals.
                    </CardDescription>
                  </div>
                  
                  {/* Select litigation stance */}
                  <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 rounded-xl p-1 shrink-0">
                    <button
                      onClick={() => setStance('plaintiff')}
                      className={`text-[10px] font-mono font-bold px-3 py-1.5 rounded-lg uppercase tracking-wide cursor-pointer transition-all ${
                        stance === 'plaintiff'
                          ? 'bg-indigo-600 text-slate-100'
                          : 'text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      Plaintiff/Prosecution
                    </button>
                    <button
                      onClick={() => setStance('defense')}
                      className={`text-[10px] font-mono font-bold px-3 py-1.5 rounded-lg uppercase tracking-wide cursor-pointer transition-all ${
                        stance === 'defense'
                          ? 'bg-indigo-600 text-slate-100'
                          : 'text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      Defense Stance
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-6 space-y-6">
                {/* Fact Summary Preview Box */}
                <div className="bg-slate-950/50 border border-slate-850 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-1.5 font-bold text-[10px] text-indigo-400 uppercase tracking-widest">
                    <Info className="w-3.5 h-3.5" />
                    Fact Pattern Under Review
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {activeCase.facts && activeCase.facts.length > 0 
                      ? activeCase.facts.map((f: any) => f.description).join(' ')
                      : 'No factual narrative loaded.'}
                  </p>
                </div>

                {/* Fetch action button */}
                <div className="flex justify-end">
                  <Button
                    onClick={handleFetchStrategy}
                    disabled={loadingStrategy}
                    variant="primary"
                    size="md"
                    icon={loadingStrategy ? Cpu : Sparkles}
                    className="relative px-6"
                  >
                    {loadingStrategy ? 'Processing Legal Thresholds...' : 'Build Custom Case Strategy'}
                  </Button>
                </div>

                {/* Strategy results area */}
                {strategyResult ? (
                  <div className="space-y-6 pt-4 border-t border-slate-850 animate-fade-in">
                    
                    {/* 1. Legal Threshold */}
                    <div className="space-y-2">
                      <h4 className="text-[11px] font-mono font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        1. Analyze the Legal Threshold
                      </h4>
                      <div className="p-4 bg-slate-900/30 border border-slate-850/80 rounded-xl text-xs text-slate-300 leading-relaxed">
                        {strategyResult.legalThreshold}
                      </div>
                    </div>

                    {/* 2. Legal Maneuvers */}
                    <div className="space-y-3">
                      <h4 className="text-[11px] font-mono font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        2. Proposed Litigation Maneuvers
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {(strategyResult.legalManeuvers || []).map((maneuver: any, idx: number) => (
                          <div key={idx} className="bg-slate-950 border border-slate-850 rounded-xl p-4 flex flex-col justify-between space-y-3">
                            <div className="space-y-1.5">
                              <span className="text-[10px] font-mono font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded uppercase">
                                Action Code: {idx + 1}
                              </span>
                              <h5 className="text-xs font-black text-slate-200 uppercase tracking-tight mt-1">{maneuver.title}</h5>
                              <p className="text-[11px] text-slate-400 leading-relaxed">{maneuver.description}</p>
                            </div>
                            <div className="pt-2 border-t border-slate-900 text-[10px] text-slate-500 font-mono italic">
                              Authority: {maneuver.citations}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 3. Citations */}
                    <div className="space-y-3">
                      <h4 className="text-[11px] font-mono font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        3. Cite Authority & Controlling Code
                      </h4>
                      <div className="space-y-2.5">
                        {(strategyResult.supportingAuthority || []).map((auth: any, idx: number) => (
                          <div key={idx} className="bg-slate-900/20 border border-slate-850/60 rounded-xl p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-4 hover:border-slate-850 transition">
                            <div className="space-y-1">
                              <span className="text-xs font-black text-indigo-300 font-mono">{auth.citation}</span>
                              <p className="text-[11px] text-slate-400 max-w-3xl leading-relaxed">{auth.summary}</p>
                            </div>
                            <button
                              onClick={() => {
                                // Add to precedent binder
                                setPrecedents([
                                  {
                                    id: 'p_added_' + Math.random(),
                                    title: auth.citation.split(',')[0],
                                    citation: auth.citation,
                                    summary: auth.summary,
                                    category: 'Controlling Case Law'
                                  },
                                  ...precedents
                                ]);
                                alert('Authority citation saved to Precedent Tracker repository!');
                              }}
                              className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 shrink-0 flex items-center gap-1 bg-indigo-500/5 hover:bg-indigo-500/10 px-2.5 py-1.5 rounded-lg border border-indigo-500/10 transition-all cursor-pointer"
                            >
                              <BookmarkPlus className="w-3.5 h-3.5" />
                              Save to Binder
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 4. Risk Assessment */}
                    <div className="space-y-3">
                      <h4 className="text-[11px] font-mono font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                        4. Risk Assessment & Rebuttals
                      </h4>
                      <div className="space-y-3">
                        {(strategyResult.riskAssessment || []).map((risk: any, idx: number) => (
                          <div key={idx} className="grid grid-cols-1 md:grid-cols-2 gap-4 border border-slate-850 rounded-xl overflow-hidden shadow-inner">
                            <div className="p-4 bg-rose-950/10 border-r border-slate-850 space-y-1.5">
                              <span className="text-[9px] font-mono font-bold text-rose-500 uppercase tracking-widest flex items-center gap-1">
                                <AlertCircle className="w-3.5 h-3.5" />
                                Likely Opposing Claim
                              </span>
                              <p className="text-xs text-slate-300 leading-relaxed italic">
                                "{risk.opponentArgument}"
                              </p>
                            </div>
                            <div className="p-4 bg-emerald-950/10 space-y-1.5">
                              <span className="text-[9px] font-mono font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-1">
                                <FileCheck className="w-3.5 h-3.5" />
                                Defense Rebuttal Strategy
                              </span>
                              <p className="text-xs text-slate-300 leading-relaxed font-medium">
                                {risk.rebuttal}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="h-40 flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-2xl text-slate-500 space-y-2">
                    <Scale className="w-8 h-8 text-slate-600 animate-pulse" />
                    <p className="text-xs">No active case analysis compiled yet. Select a stance and press 'Build Custom Case Strategy' above.</p>
                  </div>
                )}

              </CardContent>
            </Card>
          </div>
        )}

        {/* TAB 3: DISMISSAL ANALYST */}
        {activeTab === 'dismissal' && (
          <div className="space-y-6 animate-fade-in" id="view_dismissal_root">
            <Card>
              <CardHeader className="border-b border-slate-850/60">
                <CardTitle className="text-sm font-black text-slate-100 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-indigo-400" />
                  Procedural & Substantive Dismissal Analyst
                </CardTitle>
                <CardDescription className="text-xs">
                  Review claims, analyze procedural defects (insufficient service, lack of standing, statute limitations), and generate comprehensive grounds for dismissal.
                </CardDescription>
              </CardHeader>

              <CardContent className="p-6 space-y-6">
                
                {/* Input opposing arguments */}
                <div className="space-y-2">
                  <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                    Opposing Side's Allegations & Arguments
                  </label>
                  <textarea
                    value={opposingArgs}
                    onChange={(e) => setOpposingArgs(e.target.value)}
                    rows={3}
                    placeholder="Describe what the opposing party or complaint alleges in detail..."
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 transition"
                  />
                  <p className="text-[10px] text-slate-500">
                    Provide the core theories asserted in their pleadings (e.g., non-payment of rent, breach of lease, default on covenant).
                  </p>
                </div>

                {/* Fetch button */}
                <div className="flex justify-end">
                  <Button
                    onClick={handleFetchDismissal}
                    disabled={loadingDismissal}
                    variant="primary"
                    size="md"
                    icon={loadingDismissal ? Cpu : Sparkles}
                  >
                    {loadingDismissal ? 'Analyzing Dismissal Jurisprudence...' : 'Spot Grounds for Dismissal'}
                  </Button>
                </div>

                {/* Dismissal output result */}
                {dismissalResult ? (
                  <div className="space-y-6 pt-4 border-t border-slate-850 animate-fade-in">
                    
                    {/* Summary Diagnostics */}
                    <div className="bg-slate-900/30 border border-slate-850 rounded-xl p-5 space-y-2">
                      <div className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">
                        Dismissal Diagnostic Summary
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {dismissalResult.summary}
                      </p>
                    </div>

                    {/* Procedural vs Substantive split bento */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      {/* Procedural Grounds */}
                      <div className="space-y-3">
                        <h4 className="text-[11px] font-mono font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                          Procedural Defects Identified
                        </h4>
                        <div className="space-y-3">
                          {(dismissalResult.proceduralGrounds || []).map((ground: any, idx: number) => (
                            <div key={idx} className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-2.5">
                              <span className="text-[9px] font-mono font-black bg-indigo-500/10 text-indigo-300 px-2 py-0.5 rounded uppercase">
                                {ground.rule}
                              </span>
                              <p className="text-xs text-slate-300 leading-relaxed">
                                {ground.argument}
                              </p>
                              <div className="pt-2 border-t border-slate-900 text-[10px] font-mono text-slate-500">
                                Civil Code Standard: {ground.authority}
                              </div>
                            </div>
                          ))}
                          {(!dismissalResult.proceduralGrounds || dismissalResult.proceduralGrounds.length === 0) && (
                            <div className="text-xs text-slate-500 italic p-4 text-center border border-dashed border-slate-850 rounded-xl">
                              No significant procedural defects found.
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Substantive Grounds */}
                      <div className="space-y-3">
                        <h4 className="text-[11px] font-mono font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          Substantive/Merits Deficiencies
                        </h4>
                        <div className="space-y-3">
                          {(dismissalResult.substantiveGrounds || []).map((ground: any, idx: number) => (
                            <div key={idx} className="bg-slate-950 border border-slate-850 rounded-xl p-4 space-y-2.5">
                              <span className="text-[9px] font-mono font-black bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded uppercase">
                                {ground.theory || ground.rule}
                              </span>
                              <p className="text-xs text-slate-300 leading-relaxed">
                                {ground.argument}
                              </p>
                              <div className="pt-2 border-t border-slate-900 text-[10px] font-mono text-slate-500">
                                Precedent Standard: {ground.authority}
                              </div>
                            </div>
                          ))}
                          {(!dismissalResult.substantiveGrounds || dismissalResult.substantiveGrounds.length === 0) && (
                            <div className="text-xs text-slate-500 italic p-4 text-center border border-dashed border-slate-850 rounded-xl">
                              No significant substantive flaws flagged.
                            </div>
                          )}
                        </div>
                      </div>

                    </div>

                    {/* Recommendation Rule */}
                    <div className="p-4 bg-indigo-950/10 border border-indigo-900/30 rounded-xl flex items-start gap-3">
                      <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono font-black text-indigo-400 uppercase tracking-wider">
                          Strategic Recommendation
                        </span>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {dismissalResult.recommendation}
                        </p>
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="h-40 flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-2xl text-slate-500 space-y-2">
                    <ShieldAlert className="w-8 h-8 text-slate-600 animate-pulse" />
                    <p className="text-xs">Enter opposing claims and click 'Spot Grounds for Dismissal' to execute strategic audits.</p>
                  </div>
                )}

              </CardContent>
            </Card>
          </div>
        )}

        {/* TAB 4: DRAFTING ASSISTANT */}
        {activeTab === 'drafting' && (
          <div className="space-y-6 animate-fade-in" id="view_drafting_root">
            <Card>
              <CardHeader className="border-b border-slate-850/60">
                <CardTitle className="text-sm font-black text-slate-100 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  AI Document Drafting Assistant
                </CardTitle>
                <CardDescription className="text-xs">
                  Generate fully-formatted formal court pleadings, Motions to Dismiss, Complaints, and discovery requests conforming to standard jurisdictional caption regulations.
                </CardDescription>
              </CardHeader>

              <CardContent className="p-6 space-y-6">
                
                {/* Inputs Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                      Template Type
                    </label>
                    <select
                      value={templateType}
                      onChange={(e) => setTemplateType(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="motion_dismiss">Motion to Dismiss</option>
                      <option value="complaint">Complaint for Damages</option>
                      <option value="answer">Answer & Defenses</option>
                      <option value="discovery_request">Discovery Production Demand</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                      Filing Party Name
                    </label>
                    <input
                      type="text"
                      value={draftMetadata.partyName}
                      onChange={(e) => setDraftMetadata({ ...draftMetadata, partyName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                      Opposing Party
                    </label>
                    <input
                      type="text"
                      value={draftMetadata.opposingParty}
                      onChange={(e) => setDraftMetadata({ ...draftMetadata, opposingParty: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                      Court Name/Jurisdiction
                    </label>
                    <input
                      type="text"
                      value={draftMetadata.courtName}
                      onChange={(e) => setDraftMetadata({ ...draftMetadata, courtName: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* Compile action button */}
                <div className="flex justify-end pt-2">
                  <Button
                    onClick={handleFetchDraft}
                    disabled={loadingDraft}
                    variant="primary"
                    size="md"
                    icon={loadingDraft ? Cpu : Sparkles}
                  >
                    {loadingDraft ? 'Compiling Legal Captions...' : 'Compile Formal Legal Document'}
                  </Button>
                </div>

                {/* Drafting layout result bento */}
                {draftResult ? (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4 border-t border-slate-850 animate-fade-in">
                    
                    {/* LEFT COLUMN (2 spans): Draft preview text */}
                    <div className="lg:col-span-2 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                          Formed Pleading Text (Scrollable)
                        </span>
                        <button
                          onClick={handleCopyDraft}
                          className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 bg-indigo-500/5 px-2 py-1 rounded-lg border border-indigo-500/10 transition cursor-pointer"
                        >
                          {draftCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <ClipboardCopy className="w-3.5 h-3.5" />}
                          {draftCopied ? 'Copied Pleading!' : 'Copy to Clipboard'}
                        </button>
                      </div>

                      <div className="bg-slate-950 border border-slate-850 rounded-xl p-5 font-mono text-[11px] leading-relaxed text-slate-300 h-[450px] overflow-y-auto whitespace-pre-wrap select-text scrollbar-thin shadow-inner">
                        {draftResult.draft}
                      </div>
                    </div>

                    {/* RIGHT COLUMN (1 span): Checklist & Attachments */}
                    <div className="space-y-6">
                      
                      {/* Checklist */}
                      <Card className="border-slate-850/60 bg-slate-900/10 shadow-none">
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5 text-slate-200">
                            <ListTodo className="w-4 h-4 text-amber-500" />
                            Filing Deadlines Checklist
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-2 space-y-2.5">
                          {(draftResult.checklist || []).map((item: string, idx: number) => (
                            <div key={idx} className="flex gap-2 text-[11px] text-slate-400 leading-relaxed items-start">
                              <span className="w-4 h-4 rounded-full bg-slate-950 border border-slate-850 flex items-center justify-center font-mono font-bold text-indigo-400 shrink-0 mt-0.5 text-[9px]">
                                {idx + 1}
                              </span>
                              <p className="flex-1">{item}</p>
                            </div>
                          ))}
                        </CardContent>
                      </Card>

                      {/* Required attachments */}
                      <Card className="border-slate-850/60 bg-slate-900/10 shadow-none">
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-xs font-black uppercase tracking-wider flex items-center gap-1.5 text-slate-200">
                            <BookmarkPlus className="w-4 h-4 text-emerald-500" />
                            Required Exhibits Binder
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-2 space-y-2 text-[11px] text-slate-400">
                          {(draftResult.attachments || []).map((item: string, idx: number) => (
                            <div key={idx} className="flex items-center gap-2 bg-slate-950/40 border border-slate-850/50 p-2.5 rounded-lg">
                              <FileCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                              <span className="font-mono text-slate-300 truncate">{item}</span>
                            </div>
                          ))}
                        </CardContent>
                      </Card>

                    </div>

                  </div>
                ) : (
                  <div className="h-40 flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-2xl text-slate-500 space-y-2">
                    <FileText className="w-8 h-8 text-slate-600 animate-pulse" />
                    <p className="text-xs">Setup pleading parameters and click 'Compile Formal Legal Document' to preview litigation drafts.</p>
                  </div>
                )}

              </CardContent>
            </Card>
          </div>
        )}

        {/* TAB 5: PRECEDENT TRACKER */}
        {activeTab === 'precedent' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="view_precedent_root">
            
            {/* LEFT COLUMN: Add custom precedent */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Binder Precedent Notebook</CardTitle>
                  <CardDescription>Log and record binding precedents or secondary source citations during trial preparation.</CardDescription>
                </CardHeader>
                <CardContent className="p-5">
                  <form onSubmit={handleAddPrecedent} className="space-y-4">
                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                        Precedent Title/Parties
                      </label>
                      <input
                        type="text"
                        required
                        value={newPrecedentTitle}
                        onChange={(e) => setNewPrecedentTitle(e.target.value)}
                        placeholder="e.g., Celotex Corp. v. Catrett"
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                        Official Legal Citation
                      </label>
                      <input
                        type="text"
                        required
                        value={newPrecedentCitation}
                        onChange={(e) => setNewPrecedentCitation(e.target.value)}
                        placeholder="e.g., 477 U.S. 317 (1986)"
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                        Category Classification
                      </label>
                      <select
                        value={newPrecedentCategory}
                        onChange={(e) => setNewPrecedentCategory(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                      >
                        <option value="Service of Process">Service of Process</option>
                        <option value="Condition Precedent">Condition Precedent</option>
                        <option value="Summary Judgment">Summary Judgment</option>
                        <option value="Contract Damages">Contract Damages</option>
                        <option value="Evidentiary Rules">Evidentiary Rules</option>
                        <option value="Constitutional Doctrine">Constitutional Doctrine</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
                        Core Holding Summary
                      </label>
                      <textarea
                        value={newPrecedentSummary}
                        onChange={(e) => setNewPrecedentSummary(e.target.value)}
                        rows={3}
                        placeholder="Provide the key rule statement or holding summary..."
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <Button type="submit" variant="primary" size="md" icon={Plus} className="w-full justify-center">
                      Save Precedent to Binder
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* RIGHT COLUMN: Precedent Grid Repository */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">
                  Controlling Authorities & Saved Cases ({precedents.length})
                </span>
                <span className="text-[10px] text-slate-500 font-mono italic">
                  Saved locally under active intake binder.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {precedents.map((prec) => (
                  <div key={prec.id} className="bg-slate-900/40 border border-slate-850 hover:border-slate-800 p-4 rounded-xl flex flex-col justify-between space-y-4 transition">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-mono font-bold text-indigo-400 bg-indigo-500/5 border border-indigo-500/10 px-2 py-0.5 rounded">
                          {prec.category}
                        </span>
                        <button
                          onClick={() => {
                            setPrecedents(precedents.filter(p => p.id !== prec.id));
                          }}
                          className="text-slate-600 hover:text-rose-400 transition cursor-pointer"
                          title="Delete from binder"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <h4 className="text-xs font-black text-slate-200 uppercase mt-2">{prec.title}</h4>
                      <p className="text-[10px] font-mono text-slate-400 font-bold">{prec.citation}</p>
                      <p className="text-[11px] text-slate-400 leading-relaxed pt-1">{prec.summary}</p>
                    </div>

                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(prec.citation);
                        alert(`Citation copied: ${prec.citation}`);
                      }}
                      className="text-[10px] font-bold text-slate-400 hover:text-slate-200 shrink-0 flex items-center gap-1 transition"
                    >
                      <ClipboardCopy className="w-3.5 h-3.5" />
                      Copy Citation
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
