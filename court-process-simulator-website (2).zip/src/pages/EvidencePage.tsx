/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Folder, FileText, Camera, ShieldCheck, ShieldAlert, Plus, Trash2, CheckCircle2, AlertTriangle, Eye } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Button, Input, Select, Textarea, Badge } from '../components/UI';
import { EvidenceItem } from '../types';

interface EvidencePageProps {
  evidence: EvidenceItem[];
  onAddEvidence: (item: EvidenceItem) => void;
  onRemoveEvidence: (id: string) => void;
}

export const EvidencePage: React.FC<EvidencePageProps> = ({
  evidence,
  onAddEvidence,
  onRemoveEvidence
}) => {
  const [selectedItem, setSelectedItem] = useState<EvidenceItem | null>(evidence[0] || null);

  // Form State
  const [title, setTitle] = useState('');
  const [type, setType] = useState<EvidenceItem['type']>('document');
  const [description, setDescription] = useState('');
  const [relevance, setRelevance] = useState('');
  const [source, setSource] = useState('');
  const [hearsayConcern, setHearsayConcern] = useState(false);
  const [authenticityStatus, setAuthenticityStatus] = useState<EvidenceItem['authenticityStatus']>('unverified');

  const handleUpload = () => {
    if (!title.trim() || !description.trim()) return;
    const newItem: EvidenceItem = {
      id: `ev_${Date.now()}`,
      title,
      description,
      type,
      relevance,
      source: source || 'Self-provided',
      disclosed: true,
      hearsayConcern,
      authenticityStatus,
      supportsClaims: []
    };
    onAddEvidence(newItem);
    setSelectedItem(newItem);
    // Reset Form
    setTitle('');
    setDescription('');
    setRelevance('');
    setSource('');
    setHearsayConcern(false);
    setAuthenticityStatus('unverified');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onRemoveEvidence(id);
    if (selectedItem?.id === id) {
      setSelectedItem(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" id="evidence_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <Badge variant="purple">Trial Exhibit Index</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Evidence Locker & Legal Discovery Logs</h2>
          <p className="text-xs text-slate-400">Classify physical and digital exhibits, identify hearsay objections, and evaluate chain of custody.</p>
        </div>
        <Badge variant="success">68% Disclosed to Court</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: EVIDENCE LISTING */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Authenticated Evidence & Exhibits</CardTitle>
              <CardDescription>Click an item below to view detailed admissibility index sheets.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-3">
              {evidence.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No exhibits indexed in this case file.</p>
              ) : (
                <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                  {evidence.map((item) => {
                    const isSelected = selectedItem?.id === item.id;
                    const isDoc = item.type === 'document';
                    const isPhoto = item.type === 'photo';

                    return (
                      <div
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className={`p-4 rounded-xl border flex items-center justify-between gap-4 cursor-pointer transition-all duration-150 ${
                          isSelected
                            ? 'bg-indigo-600/10 border-indigo-500 ring-2 ring-indigo-500/20'
                            : 'bg-slate-950/40 border-slate-850/80 hover:bg-slate-950/80'
                        }`}
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <div className={`p-2.5 rounded-lg border ${
                            isDoc 
                              ? 'bg-rose-950/30 text-rose-400 border-rose-900/10' 
                              : isPhoto 
                              ? 'bg-blue-950/30 text-blue-400 border-blue-900/10'
                              : 'bg-slate-900 text-slate-400 border-slate-800'
                          }`}>
                            {isDoc ? <FileText className="w-5 h-5" /> : <Camera className="w-5 h-5" />}
                          </div>
                          <div className="min-w-0 space-y-0.5">
                            <h4 className="text-xs font-black text-slate-200 truncate">{item.title}</h4>
                            <p className="text-[10px] text-slate-500 font-mono">Source: {item.source}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Badge variant={
                            item.authenticityStatus === 'verified' 
                              ? 'success' 
                              : item.authenticityStatus === 'disputed' 
                              ? 'destructive' 
                              : 'secondary'
                          }>
                            {item.authenticityStatus}
                          </Badge>
                          {item.hearsayConcern && (
                            <Badge variant="warning">Hearsay Warning</Badge>
                          )}
                          <button
                            onClick={(e) => handleDelete(item.id, e)}
                            className="p-1.5 hover:bg-rose-950/20 text-slate-500 hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* FORM TO ADD NEW EVIDENCE */}
          <Card>
            <CardHeader>
              <CardTitle>Index New Legal Exhibit</CardTitle>
              <CardDescription>Upload physical mock logs and assign evidentiary support channels.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input 
                  label="Exhibit Title" 
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)} 
                  placeholder="e.g. Water Damage Repair Ledger"
                />
                <Select 
                  label="Exhibit File Type" 
                  value={type} 
                  onChange={(e) => setType(e.target.value as any)} 
                  options={[
                    { value: 'document', label: 'Document / File PDF' },
                    { value: 'photo', label: 'Photographic Proof' },
                    { value: 'email', label: 'Email Exchange' },
                    { value: 'witness_statement', label: 'Witness Statement' },
                    { value: 'other', label: 'Other Exhibit' }
                  ]}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input 
                  label="Chain of Custody / Source" 
                  value={source} 
                  onChange={(e) => setSource(e.target.value)} 
                  placeholder="e.g. County Inspector Records"
                />
                <Select 
                  label="Authenticity Status" 
                  value={authenticityStatus} 
                  onChange={(e) => setAuthenticityStatus(e.target.value as any)} 
                  options={[
                    { value: 'verified', label: 'Verified Authenticity' },
                    { value: 'disputed', label: 'Disputed Authenticity' },
                    { value: 'unverified', label: 'Unverified Origin' }
                  ]}
                />
              </div>

              <Input 
                label="General Description" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Brief description of the document or photograph content."
              />

              <Textarea 
                label="Relevance / Evidentiary Foundation" 
                value={relevance} 
                onChange={(e) => setRelevance(e.target.value)} 
                placeholder="How does this support your claims/defenses? Establish the legal foundation."
              />

              <div className="flex items-center gap-3.5 bg-slate-950/40 p-4 rounded-xl border border-slate-850">
                <input 
                  type="checkbox" 
                  id="hearsay"
                  checked={hearsayConcern}
                  onChange={(e) => setHearsayConcern(e.target.checked)}
                  className="w-4.5 h-4.5 rounded border-slate-800 text-indigo-600 focus:ring-indigo-500 bg-slate-950 cursor-pointer"
                />
                <label htmlFor="hearsay" className="text-xs text-slate-300 leading-normal cursor-pointer select-none">
                  <span className="block font-bold text-slate-200">Flag Potential Hearsay Concern</span>
                  Contains statements made outside the active courtroom trial; potentially inadmissible without exception.
                </label>
              </div>

              <Button onClick={handleUpload} variant="primary" icon={Plus} className="w-full">
                Index Trial Exhibit
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN: DETAILED INFO VIEWER */}
        <div>
          {selectedItem ? (
            <Card className="sticky top-24">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Badge variant="purple">Admissibility Sheet</Badge>
                  <CardTitle>Exhibit Analysis</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-5 text-xs">
                
                <div className="space-y-1.5 pb-3 border-b border-slate-850">
                  <h3 className="text-sm font-black text-slate-100 uppercase">{selectedItem.title}</h3>
                  <p className="text-[10px] text-slate-500 font-mono">Dossier Exhibit #{selectedItem.id}</p>
                </div>

                <div className="space-y-1.5">
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Description</span>
                  <p className="text-slate-300 leading-normal">{selectedItem.description}</p>
                </div>

                <div className="space-y-1.5">
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Evidentiary Relevance</span>
                  <p className="text-slate-300 leading-normal">{selectedItem.relevance || 'No specific relevance statement recorded.'}</p>
                </div>

                <div className="grid grid-cols-2 gap-4 py-2 border-t border-b border-slate-850">
                  <div>
                    <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Authenticity</span>
                    <div className="flex items-center gap-1.5 font-bold text-slate-200">
                      {selectedItem.authenticityStatus === 'verified' ? (
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <ShieldAlert className="w-4 h-4 text-rose-400" />
                      )}
                      <span className="capitalize">{selectedItem.authenticityStatus}</span>
                    </div>
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Hearsay Exception</span>
                    <div className="flex items-center gap-1.5 font-bold text-slate-200">
                      {selectedItem.hearsayConcern ? (
                        <AlertTriangle className="w-4 h-4 text-amber-400 animate-pulse" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      )}
                      <span>{selectedItem.hearsayConcern ? 'Yes (Requires Exception)' : 'No (Direct Evidence)'}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Authentication Strategy</span>
                  <p className="text-slate-400 leading-normal">
                    {selectedItem.authenticityStatus === 'verified' 
                      ? 'Exhibit has been verified with digital signatures or direct testimony foundation. Self-authenticating.' 
                      : 'Requires process server testimony or declaration under penalty of perjury to introduce into the trial record.'}
                  </p>
                </div>

              </CardContent>
            </Card>
          ) : (
            <Card className="p-6 text-center text-slate-500 italic">
              Select an indexed exhibit from the list to view its complete legal evaluation.
            </Card>
          )}
        </div>

      </div>

    </div>
  );
};
