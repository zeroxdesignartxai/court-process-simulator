/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Scale, BookOpen, CheckCircle, ShieldAlert, AlertTriangle, ArrowRight, BookMarked } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge, Progress } from '../components/UI';
import { CaseReport } from '../types';

interface ClaimsPageProps {
  report: CaseReport;
}

export const ClaimsPage: React.FC<ClaimsPageProps> = ({ report }) => {
  return (
    <div className="space-y-6 animate-fade-in" id="claims_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg">
        <div className="space-y-1">
          <Badge variant="purple">Legal Merits Matrix</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Claims & Defenses IRAC Merits Matrix</h2>
          <p className="text-xs text-slate-400">Review IRAC analysis sheets, evaluate burdens of proof, and inspect evidentiary support on a per-element basis.</p>
        </div>
      </div>

      {/* OVERVIEW PANEL */}
      <Card className="bg-indigo-950/15 border-indigo-900/20">
        <CardContent className="p-6 flex items-start gap-4">
          <div className="p-3 bg-indigo-950 border border-indigo-800/30 text-indigo-400 rounded-xl shrink-0">
            <Scale className="w-6 h-6" />
          </div>
          <div className="space-y-1.5 text-xs text-slate-300 leading-relaxed">
            <span className="block text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-widest">Case Merits Dossier Summary</span>
            <p>{report.overview}</p>
          </div>
        </CardContent>
      </Card>

      {/* MATRIX GRID OF CLAIMS AND DEFENSES */}
      <div className="grid grid-cols-1 gap-6">
        {report.claimsAndDefenses.map((cd, cdIndex) => {
          const isClaim = cd.type === 'claim';
          return (
            <Card key={cdIndex} className="border-slate-850/80">
              <CardHeader className="bg-slate-900/40 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-850">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Badge variant={isClaim ? 'default' : 'secondary'}>
                      {cd.type}
                    </Badge>
                    <h3 className="text-base font-black text-slate-200 uppercase">{cd.name}</h3>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <BookMarked className="w-3.5 h-3.5 text-slate-500" />
                    <span className="font-mono text-[10px] text-slate-500 uppercase">Issue:</span>
                    <span className="font-semibold text-slate-300">{cd.iracIssue}</span>
                  </div>
                </div>

                <div className="w-full md:w-48 space-y-1 bg-slate-950/40 border border-slate-850 p-3 rounded-xl shrink-0">
                  <div className="flex justify-between text-[10px] font-mono font-bold text-slate-400 mb-0.5">
                    <span>Overall Merits</span>
                    <span className={cd.overallScore > 60 ? 'text-emerald-400' : 'text-amber-400'}>{cd.overallScore}%</span>
                  </div>
                  <Progress value={cd.overallScore} colorClass={cd.overallScore > 60 ? 'bg-emerald-500' : 'bg-amber-500'} />
                </div>
              </CardHeader>

              <CardContent className="p-6 space-y-6">
                
                {/* IRAC Rule Banner */}
                <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1 text-xs">
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">IRAC Rule (Statutory Authority)</span>
                  <p className="text-slate-300 leading-relaxed font-serif italic pr-4">"{cd.iracRule}"</p>
                </div>

                {/* Elements Breakdown */}
                <div className="space-y-4">
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest font-mono border-b border-slate-900 pb-1.5">Statutory Elements Breakdown</span>
                  
                  <div className="grid grid-cols-1 gap-4">
                    {cd.elements.map((elem, elIndex) => {
                      return (
                        <div key={elIndex} className="bg-slate-950/20 border border-slate-850/60 rounded-xl p-5 hover:border-slate-850 transition-all space-y-4">
                          
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-900">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
                                <h4 className="text-xs font-black text-slate-200 uppercase">{elem.elementName}</h4>
                              </div>
                              <p className="text-[11px] text-slate-400 leading-normal">{elem.definition}</p>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <Badge variant={elem.burdenOfProof === 'plaintiff' ? 'default' : 'secondary'}>
                                Burden: {elem.burdenOfProof}
                              </Badge>
                              <Badge variant={elem.strengthScore > 60 ? 'success' : 'warning'}>
                                {elem.strengthScore}% Strength
                              </Badge>
                            </div>
                          </div>

                          {/* Facts / Evidence Mapping */}
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 text-[11px]">
                            
                            {/* Supporting Facts */}
                            <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-900 space-y-2">
                              <span className="block text-[9px] font-mono font-bold text-emerald-400 uppercase tracking-widest">Supporting Facts</span>
                              {elem.supportingFacts.length === 0 ? (
                                <p className="text-slate-500 italic">No supporting facts mapped.</p>
                              ) : (
                                <ul className="list-disc pl-3.5 space-y-1.5 text-slate-300 leading-normal">
                                  {elem.supportingFacts.map((f, i) => <li key={i}>{f}</li>)}
                                </ul>
                              )}
                            </div>

                            {/* Opposing / Defeating Facts */}
                            <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-900 space-y-2">
                              <span className="block text-[9px] font-mono font-bold text-rose-400 uppercase tracking-widest">Opposing Facts / Risks</span>
                              {elem.opposingFacts.length === 0 ? (
                                <p className="text-slate-500 italic">No opposing facts identified.</p>
                              ) : (
                                <ul className="list-disc pl-3.5 space-y-1.5 text-slate-300 leading-normal">
                                  {elem.opposingFacts.map((f, i) => <li key={i}>{f}</li>)}
                                </ul>
                              )}
                            </div>

                            {/* Exhibits & Admissibility Concerns */}
                            <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-900 space-y-3 lg:col-span-1">
                              <div className="space-y-1.5">
                                <span className="block text-[9px] font-mono font-bold text-indigo-400 uppercase tracking-widest font-mono">Exhibits</span>
                                {elem.supportingEvidence.length === 0 ? (
                                  <p className="text-slate-500 italic">No physical exhibits linked.</p>
                                ) : (
                                  <ul className="list-disc pl-3.5 space-y-1 text-slate-300 leading-normal font-mono text-[10px]">
                                    {elem.supportingEvidence.map((e, i) => <li key={i}>{e}</li>)}
                                  </ul>
                                )}
                              </div>

                              {elem.admissibilityConcerns.length > 0 && (
                                <div className="p-2.5 bg-amber-950/20 border border-amber-900/30 text-amber-300 rounded-lg flex items-start gap-1.5">
                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5 animate-pulse" />
                                  <div className="text-[10px] leading-normal font-bold">
                                    Admissibility Alert:
                                    <span className="block font-medium text-slate-400 mt-0.5 leading-normal">{elem.admissibilityConcerns.join(', ')}</span>
                                  </div>
                                </div>
                              )}
                            </div>

                          </div>

                          {/* Element Explanation */}
                          <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-900 text-xs text-slate-300 leading-relaxed space-y-1">
                            <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider font-mono">Application & Analysis</span>
                            <p>{elem.explanation}</p>
                          </div>

                        </div>
                      );
                    })}
                  </div>

                </div>

              </CardContent>
            </Card>
          );
        })}
      </div>

    </div>
  );
};
