/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Calendar, 
  FileText, 
  Clock, 
  User, 
  MapPin, 
  Scale, 
  TrendingUp, 
  Upload, 
  CheckSquare, 
  Folder, 
  AlertTriangle,
  Play,
  ArrowRight,
  ChevronRight,
  CheckCircle2,
  FileSpreadsheet,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge, Progress, Button } from '../components/UI';
import { CaseIntake, CaseReport } from '../types';

interface DashboardPageProps {
  activeCase: CaseIntake;
  report: CaseReport;
  onNavigate: (hash: string) => void;
  onSimulate: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ 
  activeCase, 
  report, 
  onNavigate, 
  onSimulate 
}) => {
  const [actionsExpanded, setActionsExpanded] = React.useState(false);
  const isSanchez = activeCase.title.includes('Sanchez');

  // Hardcode the gorgeous metadata for high fidelity to the screenshot
  const caseNumber = isSanchez ? '24STCV123456' : '24STCV987654';
  const assignedJudge = isSanchez ? 'Hon. Daniel R. Chavez' : 'Hon. Arthur Vance';
  const location = isSanchez ? 'Stanley Mosk Courthouse' : 'Los Angeles County Civil Court';
  const nextHearing = isSanchez ? 'May 28, 2025 - 9:30 AM' : 'June 14, 2026 - 10:00 AM';
  const filedDate = isSanchez ? 'May 12, 2025' : 'June 01, 2025';

  return (
    <div className="space-y-6 animate-fade-in" id="dashboard_page_root">
      
      {/* SECTION 1: PRIMARY CASE DETAIL & QUICK ACTIONS */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        
        {/* Case Info Card */}
        <Card className="xl:col-span-3">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 border-b border-slate-850 pb-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-indigo-950/40 border border-indigo-900/30 text-indigo-400 rounded-2xl flex items-center justify-center shrink-0">
                  <Scale className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-xl font-black text-slate-100 uppercase tracking-tight">{activeCase.title}</h2>
                    <Badge variant="success">Active</Badge>
                  </div>
                  <p className="text-xs text-slate-400">{activeCase.jurisdiction}</p>
                </div>
              </div>
            </div>

            {/* Grid of properties */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-xs leading-relaxed">
              <div className="space-y-3">
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Case Type</span>
                  <span className="font-semibold text-slate-200 capitalize">{activeCase.caseType.replace('_', ' ')}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Court</span>
                  <span className="font-semibold text-slate-200">{activeCase.courtName}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Case Number</span>
                  <span className="font-semibold text-slate-200 font-mono">{caseNumber}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Next Hearing</span>
                  <span className="font-bold text-slate-100 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    {nextHearing}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Filed Date</span>
                  <span className="font-semibold text-slate-200">{filedDate}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Remedy Requested</span>
                  <span className="font-semibold text-slate-200 line-clamp-1" title={activeCase.remedyRequested}>
                    {activeCase.remedyRequested}
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Assigned Judge</span>
                  <span className="font-bold text-slate-200 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    {assignedJudge}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Courtroom Location</span>
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {location}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-0.5">Amount in Controversy</span>
                  <span className="font-black text-indigo-400 font-mono">${activeCase.amountInControversy.toLocaleString()}</span>
                </div>
              </div>

              {/* Litigant Parties */}
              <div className="space-y-2 bg-slate-950/40 p-3 rounded-xl border border-slate-850">
                <span className="block text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Litigating Parties</span>
                <div className="space-y-1.5">
                  {activeCase.parties.map((p, i) => (
                    <div key={i} className="flex justify-between items-center gap-2">
                      <span className="font-semibold text-slate-200 truncate max-w-[110px]">{p.name}</span>
                      <Badge variant={p.role === 'plaintiff' ? 'default' : 'secondary'}>
                        {p.role}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions Panel */}
        <Card className="xl:col-span-1 bg-slate-900/40 border border-slate-850 h-fit">
          <CardHeader className="cursor-pointer select-none" onClick={() => setActionsExpanded(!actionsExpanded)}>
            <div className="flex items-center justify-between">
              <CardTitle>Quick Actions</CardTitle>
              <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                {actionsExpanded ? 'Collapse' : 'Expand'}
                {actionsExpanded ? (
                  <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                )}
              </span>
            </div>
          </CardHeader>
          {actionsExpanded && (
            <CardContent className="p-5 space-y-2 animate-fade-in border-t border-slate-850/40">
              <button 
                onClick={() => onNavigate('#evidence')}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 bg-slate-950 hover:bg-slate-850/80 text-xs text-slate-300 rounded-xl transition-all border border-slate-850 hover:border-slate-800 text-left cursor-pointer"
              >
                <Upload className="w-4 h-4 text-indigo-400" />
                Upload Document
              </button>
              <button 
                onClick={() => onNavigate('#tasks')}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 bg-slate-950 hover:bg-slate-850/80 text-xs text-slate-300 rounded-xl transition-all border border-slate-850 hover:border-slate-800 text-left cursor-pointer"
              >
                <Calendar className="w-4 h-4 text-emerald-400" />
                Schedule Reminder
              </button>
              <button 
                onClick={() => onNavigate('#simulator')}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 bg-slate-950 hover:bg-slate-850/80 text-xs text-slate-300 rounded-xl transition-all border border-slate-850 hover:border-slate-800 text-left cursor-pointer"
              >
                <Play className="w-4 h-4 text-purple-400" />
                Run Simulator
              </button>
              <button 
                onClick={() => onNavigate('#timeline')}
                className="w-full flex items-center gap-2.5 px-3.5 py-2.5 bg-slate-950 hover:bg-slate-850/80 text-xs text-slate-300 rounded-xl transition-all border border-slate-850 hover:border-slate-800 text-left cursor-pointer"
              >
                <Clock className="w-4 h-4 text-amber-400" />
                View Case Timeline
              </button>
            </CardContent>
          )}
        </Card>
      </div>

      {/* SECTION 2: METRIC DOSSIER ROW */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Next Deadline */}
        <Card className="bg-slate-900 border-slate-850/80 flex flex-col justify-between p-5 space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-widest">Next Deadline</span>
              <p className="text-2xl font-black text-slate-100 tracking-tight mt-1">3 Days</p>
            </div>
            <div className="p-2.5 bg-indigo-950 border border-indigo-900/30 text-indigo-400 rounded-xl">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="text-[11px] text-slate-400 leading-normal">
            <span className="font-bold text-slate-300">Answer Due</span>
            <span className="block text-[10px] font-mono text-slate-500 mt-0.5">May 21, 2025</span>
          </div>
        </Card>

        {/* Open Tasks */}
        <Card className="bg-slate-900 border-slate-850/80 flex flex-col justify-between p-5 space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest">Open Tasks</span>
              <p className="text-2xl font-black text-slate-100 tracking-tight mt-1">5 Tasks</p>
            </div>
            <div className="p-2.5 bg-emerald-950 border border-emerald-900/30 text-emerald-400 rounded-xl">
              <CheckSquare className="w-5 h-5" />
            </div>
          </div>
          <div className="text-[11px] leading-normal flex items-center gap-1.5 text-rose-400 font-bold">
            <AlertTriangle className="w-3.5 h-3.5" />
            2 Overdue Tasks
          </div>
        </Card>

        {/* Evidence Docs */}
        <Card className="bg-slate-900 border-slate-850/80 flex flex-col justify-between p-5 space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest">Evidence & Docs</span>
              <p className="text-2xl font-black text-slate-100 tracking-tight mt-1">42 Documents</p>
            </div>
            <div className="p-2.5 bg-amber-950 border border-amber-900/30 text-amber-400 rounded-xl">
              <Folder className="w-5 h-5" />
            </div>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-slate-400">
              <span className="font-mono">68% Uploaded</span>
              <span className="font-semibold text-emerald-400">Target Reached</span>
            </div>
            <Progress value={68} colorClass="bg-emerald-500" />
          </div>
        </Card>

        {/* Outcome Score */}
        <Card className="bg-slate-900 border-slate-850/80 flex flex-col justify-between p-5 space-y-3">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-mono font-bold text-purple-400 uppercase tracking-widest">Outcome Score</span>
              <p className="text-2xl font-black text-slate-100 tracking-tight mt-1">68%</p>
            </div>
            <div className="p-2.5 bg-purple-950 border border-purple-900/30 text-purple-400 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-[11px] leading-normal font-bold text-emerald-400 flex items-center gap-1.5">
            <span className="inline-block transform rotate-0 font-sans">↑</span>
            6% Favorable Outcome vs last run
          </div>
        </Card>
      </div>

      {/* SECTION 3: CASE PROGRESS TIMELINE FLOWBAR */}
      <Card>
        <CardHeader>
          <CardTitle>Case Progress Timeline</CardTitle>
          <CardDescription>Litigation checkpoints mapped in chronological sequence according to state statutes.</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="overflow-x-auto pb-2">
            <div className="flex items-center justify-between min-w-[800px] relative px-4 py-6">
              
              {/* Connecting Line */}
              <div className="absolute top-1/2 -translate-y-1/2 left-10 right-10 h-0.5 bg-slate-800 z-0" />
              
              {/* Colored progress overlay line */}
              <div className="absolute top-1/2 -translate-y-1/2 left-10 w-[42%] h-0.5 bg-indigo-500 z-0" />

              {/* Checkpoints */}
              {[
                { id: 1, label: 'Filed', date: 'May 12', status: 'completed' },
                { id: 2, label: 'Served', date: 'May 15', status: 'completed' },
                { id: 3, label: 'Responsive Pleading', date: 'May 21', status: 'completed' },
                { id: 4, label: 'Discovery', date: 'In Progress', status: 'active' },
                { id: 5, label: 'Motions', date: '', status: 'upcoming' },
                { id: 6, label: 'Hearing', date: '', status: 'upcoming' },
                { id: 7, label: 'Trial', date: '', status: 'upcoming' },
                { id: 8, label: 'Judgment', date: '', status: 'upcoming' },
                { id: 9, label: 'Writ / Appeal', date: '', status: 'upcoming' },
              ].map((node) => {
                return (
                  <div key={node.id} className="flex flex-col items-center text-center space-y-2.5 z-10 relative">
                    {node.status === 'completed' && (
                      <div className="w-8 h-8 rounded-full bg-indigo-600 text-slate-100 flex items-center justify-center border-2 border-slate-950 shadow-md">
                        <CheckCircle2 className="w-4.5 h-4.5 text-slate-100" />
                      </div>
                    )}
                    {node.status === 'active' && (
                      <div className="w-8 h-8 rounded-full bg-slate-950 border-2 border-indigo-500 text-indigo-400 flex items-center justify-center font-mono font-bold text-xs ring-4 ring-indigo-500/10 animate-pulse">
                        {node.id}
                      </div>
                    )}
                    {node.status === 'upcoming' && (
                      <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 text-slate-600 flex items-center justify-center font-mono font-medium text-xs">
                        {node.id}
                      </div>
                    )}
                    <div className="space-y-0.5 max-w-[80px]">
                      <p className={`text-[10px] font-bold leading-tight ${node.status === 'active' ? 'text-indigo-400' : 'text-slate-300'}`}>{node.label}</p>
                      {node.date && (
                        <p className={`text-[9px] font-mono ${node.status === 'active' ? 'text-indigo-400/80 animate-pulse' : 'text-slate-500'}`}>{node.date}</p>
                      )}
                    </div>
                  </div>
                );
              })}

            </div>
          </div>
        </CardContent>
      </Card>

      {/* SECTION 4: GRID (RECENT ACTIVITY & OUTCOME SNAPSHOT) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Activity List */}
        <Card className="flex flex-col justify-between">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Recent Activity Log</CardTitle>
                <CardDescription>Auditable record of document indexing, filings, and timeline modifications.</CardDescription>
              </div>
              <button 
                onClick={() => onNavigate('#reports')}
                className="text-[10px] font-mono font-bold text-indigo-400 hover:text-indigo-300 uppercase tracking-wider"
              >
                View All Activity
              </button>
            </div>
          </CardHeader>
          <CardContent className="p-6 pt-2 space-y-4">
            {[
              { type: 'doc', icon: FileText, iconColor: 'text-rose-400 bg-rose-950/40 border-rose-900/30', title: 'Complaint.pdf uploaded', detail: 'By Mauricio Sanchez • Apr 18, 2025 2:45 PM', tag: 'Document' },
              { type: 'doc', icon: FileText, iconColor: 'text-blue-400 bg-blue-950/40 border-blue-900/30', title: 'Answer.pdf uploaded', detail: 'By Mauricio Sanchez • Apr 21, 2025 3:12 PM', tag: 'Document' },
              { type: 'system', icon: Clock, iconColor: 'text-purple-400 bg-purple-950/40 border-purple-900/30', title: 'Deadline updated: Answer Due', detail: 'Calculation adjusted for service • May 21, 2025', tag: 'System' },
              { type: 'task', icon: CheckSquare, iconColor: 'text-emerald-400 bg-emerald-950/40 border-emerald-900/30', title: 'Task completed: Review Lease Agreement', detail: 'By Mauricio Sanchez • Apr 20, 2025 11:08 AM', tag: 'Task' },
              { type: 'note', icon: Scale, iconColor: 'text-amber-400 bg-amber-950/40 border-amber-900/30', title: 'Note added: Tenant has partial payment defense', detail: 'By Mauricio Sanchez • Apr 20, 2025 10:32 AM', tag: 'Note' },
            ].map((act, i) => (
              <div key={i} className="flex items-center justify-between gap-4 p-3 bg-slate-950/30 border border-slate-900 rounded-xl hover:bg-slate-950/60 transition-all">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg border ${act.iconColor}`}>
                    <act.icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">{act.title}</h4>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">{act.detail}</p>
                  </div>
                </div>
                <Badge variant="secondary">{act.tag}</Badge>
              </div>
            ))}
            <button 
              onClick={() => onNavigate('#reports')}
              className="w-full py-2.5 text-center bg-slate-950 hover:bg-slate-850/80 border border-slate-850 rounded-xl text-xs font-bold text-indigo-400 hover:text-indigo-300 transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              View Full Activity Feed <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </CardContent>
        </Card>

        {/* Outcome Snapshot */}
        <Card className="flex flex-col justify-between">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Outcome Snapshot</CardTitle>
                <CardDescription>Mathematical probability spectrum generated from current evidence lockers.</CardDescription>
              </div>
              <Button onClick={onSimulate} variant="outline" size="sm" icon={Play}>
                Run Simulator
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-6 pt-2 space-y-6">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-8 border-b border-slate-850/60 pb-5">
              {/* Radial Donut Progress */}
              <div className="relative w-36 h-36 flex items-center justify-center shrink-0">
                {/* SVG Circle Track */}
                <svg className="absolute w-full h-full transform -rotate-90">
                  <circle cx="72" cy="72" r="58" strokeWidth="10" stroke="#020617" fill="transparent" />
                  <circle cx="72" cy="72" r="58" strokeWidth="10" stroke="#6366f1" fill="transparent" 
                    strokeDasharray={2 * Math.PI * 58}
                    strokeDashoffset={2 * Math.PI * 58 * (1 - 0.68)}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="text-center space-y-0.5">
                  <p className="text-3xl font-black text-slate-100 tracking-tight">68%</p>
                  <p className="text-[9px] text-indigo-400 font-mono font-bold uppercase tracking-wider">Favorable</p>
                  <p className="text-[9px] text-slate-500 font-mono">+6% vs last run</p>
                </div>
              </div>

              {/* Text descriptions */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-400 font-bold uppercase tracking-wide text-[10px]">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  Favorable Outcome Likely
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  Case analysis indexes indicate high defensibility of service process and significant breach in the landlord's habitability warranty.
                </p>
                <div className="text-[10px] text-slate-500 font-mono">
                  Confidence Interval: <span className="text-indigo-400 font-bold">MODERATE (±8%)</span>
                </div>
              </div>
            </div>

            {/* Sub-distributions */}
            <div className="space-y-3.5">
              <div>
                <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-1">
                  <span>Win at Trial (Tenant Dismissal)</span>
                  <span className="font-mono text-indigo-400">53%</span>
                </div>
                <Progress value={53} colorClass="bg-indigo-500" />
              </div>
              <div>
                <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-1">
                  <span>Favorable Settlement Agreement</span>
                  <span className="font-mono text-indigo-400">28%</span>
                </div>
                <Progress value={28} colorClass="bg-indigo-400" />
              </div>
              <div>
                <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-1">
                  <span>Partial Win / Fee Concessions</span>
                  <span className="font-mono text-indigo-400">12%</span>
                </div>
                <Progress value={12} colorClass="bg-indigo-300" />
              </div>
              <div>
                <div className="flex justify-between text-[11px] font-bold text-slate-300 mb-1">
                  <span>Unfavorable Ruling / Eviction</span>
                  <span className="font-mono text-rose-400">8%</span>
                </div>
                <Progress value={8} colorClass="bg-rose-500" />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 text-[10px] text-slate-500 border-t border-slate-850/40">
              <span className="font-mono">Based on 42 documents and 16 factors.</span>
              <button 
                onClick={() => onNavigate('#outcomes')}
                className="font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 uppercase tracking-wider"
              >
                View Full Analysis <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </CardContent>
        </Card>

      </div>

    </div>
  );
};
