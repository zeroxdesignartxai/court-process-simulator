/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Award, ShieldAlert, GitMerge, CheckCircle2, ChevronRight, Scale, BookOpen, AlertTriangle, Activity, TrendingUp, TrendingDown, Sparkles } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge, Progress } from '../components/UI';
import { CaseReport } from '../types';

interface OutcomesPageProps {
  report: CaseReport;
}

// Helper to calculate dynamic favorable outcome probability combining scenario analysis and claims/defenses metrics
const calculateFavorableProbability = (report: CaseReport): number => {
  // 1. Analyze Outcomes Scenarios
  let outcomeProb = 70; // default baseline
  if (report.outcomes && report.outcomes.length > 0) {
    const favorableOutcomes = report.outcomes.filter(out => {
      const name = out.outcomeName.toLowerCase();
      const isUnfavorable = 
        name.includes('judgment for plaintiff') || 
        name.includes('eviction judgment') || 
        name.includes('unfavorable') || 
        (name.includes('judgment') && name.includes('landlord'));
      return !isUnfavorable;
    });
    
    const favorableSum = favorableOutcomes.reduce((sum, out) => sum + out.probabilityValue, 0);
    const totalSum = report.outcomes.reduce((sum, out) => sum + out.probabilityValue, 0);
    
    if (totalSum > 0) {
      outcomeProb = Math.round((favorableSum / totalSum) * 100);
    }
  }

  // 2. Analyze Claims & Defenses Scores
  let meritProb = 50;
  if (report.claimsAndDefenses && report.claimsAndDefenses.length > 0) {
    const claims = report.claimsAndDefenses.filter(c => c.type === 'claim');
    const defenses = report.claimsAndDefenses.filter(c => c.type === 'defense');
    
    const avgClaim = claims.length > 0 ? claims.reduce((sum, c) => sum + c.overallScore, 0) / claims.length : 50;
    const avgDefense = defenses.length > 0 ? defenses.reduce((sum, d) => sum + d.overallScore, 0) / defenses.length : 50;
    
    const claimsAdvantage = 100 - avgClaim;
    const defensesAdvantage = avgDefense;
    
    meritProb = (claimsAdvantage + defensesAdvantage) / 2;
  } else {
    meritProb = outcomeProb;
  }

  // 3. Blend them together (60% outcomes probability, 40% merits analysis)
  const blended = Math.round(outcomeProb * 0.6 + meritProb * 0.4);
  return Math.max(5, Math.min(95, blended)); // bound between 5% and 95%
};

export const OutcomesPage: React.FC<OutcomesPageProps> = ({ report }) => {
  const favorablePercentage = calculateFavorableProbability(report);

  const getFavorableCommentary = (pct: number) => {
    if (pct >= 70) {
      return {
        status: 'Strong Favorable Signal',
        color: 'text-emerald-400',
        borderColor: 'border-emerald-500/20',
        badgeColor: 'success' as const,
        description: 'Advanced modeling predicts a highly favorable judicial outlook. Procedural notices exhibit material defects, and Affirmative Defenses are supported by verified photographic and electronic chat evidence, creating leverage for a clean dismissal or maximum settlement concession.',
        signals: [
          'Material Notice Service defects are deemed statistically fatal to claimant jurisdiction.',
          'Physical and photographic proof of water/mold breaches establish robust habitability offsets.',
          'Adversarial claims demonstrate a low structural success probability at evidentiary hearings.'
        ],
        risks: [
          'Claimant may cure procedural notices and refile subsequently.',
          'Lack of a certified building inspector report introduces potential foundation challenges.'
        ]
      };
    } else if (pct >= 40) {
      return {
        status: 'Moderate Favorable Signal',
        color: 'text-amber-400',
        borderColor: 'border-amber-500/20',
        badgeColor: 'warning' as const,
        description: 'Modeling indicates balanced odds with substantial merits but procedurally sensitive steps. While your core defenses are sound, the claimant possesses valid claims that could survive threshold motions, urging a strategic focus on evidentiary foundations.',
        signals: [
          'Core defensive claims show moderate evidentiary merit.',
          'Opposing side holds written contractual assent, securing a baseline for their financial claims.'
        ],
        risks: [
          'High risk of litigation costs exceeding recovery, suggesting an optimized settlement path.',
          'Admissibility of verbal understandings remains restricted under integrated agreement rules.'
        ]
      };
    } else {
      return {
        status: 'Low Favorable Signal',
        color: 'text-rose-400',
        borderColor: 'border-rose-500/20',
        badgeColor: 'destructive' as const,
        description: 'Simulation flags a highly elevated risk profile. The plaintiff\'s claim is backed by uncontested records, and your defenses currently suffer from critical evidentiary or procedural deficits. Re-evaluating settlement structures is strongly recommended.',
        signals: [
          'Claimant possesses clear documented proof of compliance and defaults.',
          'No material notice defects have been established or verified.'
        ],
        risks: [
          'Failure to secure independent verification leaves affirmative allegations unsubstantiated.',
          'High probability of unfavorable summary judgment if service is found compliant.'
        ]
      };
    }
  };

  const commentary = getFavorableCommentary(favorablePercentage);

  const gaugeData = [
    { name: 'Favorable', value: favorablePercentage, color: 'url(#favorableGauge)' },
    { name: 'Remaining', value: 100 - favorablePercentage, color: '#1e293b' }
  ];

  return (
    <div className="space-y-6 animate-fade-in" id="outcomes_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg">
        <div className="space-y-1">
          <Badge variant="purple">Outcomes Modeling</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Judicial Outcomes & Adversarial Arguments</h2>
          <p className="text-xs text-slate-400">Review potential settlement or trial outcomes, probability bands, and outlines of adversarial legal theories.</p>
        </div>
      </div>

      {/* REAL-TIME VERDICT PROBABILITY GAUGE CARD */}
      <Card className="border-slate-850 bg-slate-900/40" id="verdict_gauge_hero">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
            
            {/* GAUGE CHART PANEL */}
            <div className="col-span-1 bg-slate-950/80 border border-slate-850 rounded-2xl p-5 flex flex-col items-center justify-between min-h-[260px] relative overflow-hidden">
              <div className="absolute top-2.5 left-3 text-[8.5px] font-mono text-indigo-500/40 tracking-widest uppercase">
                MODEL // VERDICT_CALC
              </div>
              <div className="absolute top-2.5 right-3 flex items-center gap-1 text-[8.5px] font-mono text-emerald-500/60 uppercase">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                LIVE UPDATES
              </div>
              
              <div className="w-full flex-1 flex flex-col items-center justify-center pt-4">
                <div className="relative w-full h-[150px] flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="favorableGauge" x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="#818cf8" stopOpacity={0.9} />
                          <stop offset="100%" stopColor="#4f46e5" stopOpacity={1} />
                        </linearGradient>
                      </defs>
                      <Pie
                        data={gaugeData}
                        cx="50%"
                        cy="90%"
                        startAngle={180}
                        endAngle={0}
                        innerRadius={65}
                        outerRadius={88}
                        dataKey="value"
                        stroke="none"
                      >
                        {gaugeData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={index === 0 ? 'url(#favorableGauge)' : '#1e293b'} 
                          />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  
                  {/* Gauge Overlay Text */}
                  <div className="absolute bottom-[10%] text-center">
                    <span className="text-3xl font-black font-mono tracking-tight text-slate-100 block">
                      {favorablePercentage}%
                    </span>
                    <span className="text-[7.5px] font-mono font-bold tracking-widest text-slate-500 uppercase block mt-0.5">
                      Favorable Verdict
                    </span>
                  </div>
                </div>
                
                {/* 0% 50% 100% ticks */}
                <div className="w-4/5 flex justify-between px-2 text-[8px] font-mono text-slate-600 border-t border-slate-900/60 pt-1.5">
                  <span>0% (RISK)</span>
                  <span>50% (EQUAL)</span>
                  <span>100% (WIN)</span>
                </div>
              </div>
            </div>

            {/* BRIEFING DOSSIER ANALYSIS PANEL */}
            <div className="col-span-1 lg:col-span-2 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-850 pb-3">
                <div className="space-y-0.5">
                  <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-widest block">Simulation Analysis</span>
                  <h3 className="text-sm font-black text-slate-200 uppercase tracking-tight flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
                    Verdict Probability Dossier
                  </h3>
                </div>
                <Badge variant={commentary.badgeColor}>
                  {commentary.status}
                </Badge>
              </div>

              <p className="text-slate-300 text-xs leading-relaxed">
                {commentary.description}
              </p>

              {/* Dynamic Signals List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div className="space-y-2 bg-slate-950/40 p-3.5 border border-slate-900 rounded-xl">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-mono text-[9px] font-black uppercase tracking-wider">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    Case Strength Multipliers
                  </div>
                  <ul className="space-y-1.5">
                    {commentary.signals.map((sig, idx) => (
                      <li key={idx} className="text-slate-300 text-[10.5px] leading-relaxed flex items-start gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 mt-1.5" />
                        <span>{sig}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2 bg-slate-950/40 p-3.5 border border-slate-900 rounded-xl">
                  <div className="flex items-center gap-1.5 text-rose-400 font-mono text-[9px] font-black uppercase tracking-wider">
                    <TrendingDown className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    Procedural Risk Overlays
                  </div>
                  <ul className="space-y-1.5">
                    {commentary.risks.map((risk, idx) => (
                      <li key={idx} className="text-slate-300 text-[10.5px] leading-relaxed flex items-start gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0 mt-1.5" />
                        <span>{risk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

          </div>
        </CardContent>
      </Card>

      {/* OUTCOMES ANALYSIS LIST */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {report.outcomes.map((out, index) => {
          return (
            <Card key={index} className="flex flex-col justify-between border-slate-850/80">
              <CardHeader className="bg-slate-900/30 p-5 border-b border-slate-850 flex items-center justify-between">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">Judicial Outcome Scenario #{index + 1}</span>
                  <CardTitle className="text-sm font-black text-slate-200 uppercase">{out.outcomeName}</CardTitle>
                </div>
                <Badge variant={out.confidenceLevel === 'high' ? 'success' : out.confidenceLevel === 'moderate' ? 'info' : 'warning'}>
                  Confidence: {out.confidenceLevel}
                </Badge>
              </CardHeader>

              <CardContent className="p-6 space-y-5 text-xs">
                
                {/* Probability Band Progress */}
                <div className="space-y-2 bg-slate-950/50 p-4 border border-slate-900 rounded-xl">
                  <div className="flex justify-between items-center text-[11px] font-bold text-slate-300">
                    <span className="uppercase tracking-wide font-sans text-slate-400">Simulation Probability Band</span>
                    <span className="font-mono text-indigo-400 font-extrabold text-sm">{out.probabilityRange}</span>
                  </div>
                  <Progress value={out.probabilityValue} colorClass="bg-indigo-500" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Supporting Factors */}
                  <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-900/80 space-y-2">
                    <span className="block text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">Supporting Factors</span>
                    <ul className="list-disc pl-4 space-y-1.5 text-slate-300 leading-relaxed text-[11px]">
                      {out.keySupportingFactors.map((f, i) => <li key={i}>{f}</li>)}
                    </ul>
                  </div>

                  {/* Negative Factors */}
                  <div className="bg-slate-950/40 p-3.5 rounded-xl border border-slate-900/80 space-y-2">
                    <span className="block text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider">Risks & Counter-arguments</span>
                    <ul className="list-disc pl-4 space-y-1.5 text-slate-300 leading-relaxed text-[11px]">
                      {out.keyNegativeFactors.map((f, i) => <li key={i}>{f}</li>)}
                    </ul>
                  </div>
                </div>

                {/* Key Assumptions */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-900 space-y-1.5">
                  <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Model Assumptions</span>
                  <ul className="list-disc pl-4 space-y-1 text-slate-400 leading-normal font-mono text-[10px]">
                    {out.assumptions.map((as, i) => <li key={i}>{as}</li>)}
                  </ul>
                </div>

              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* ADVERSARIAL ARGUMENT SIDE-BY-SIDE OUTLINES */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        
        {/* PLAINTIFF ARGUMENTS */}
        <Card className="border-indigo-950/40">
          <CardHeader className="bg-indigo-950/10 p-5 border-b border-indigo-900/10 flex items-center gap-2">
            <Scale className="w-5 h-5 text-indigo-400" />
            <CardTitle className="text-slate-200">Plaintiff Case Theory Outline</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-5 text-xs">
            <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1.5 leading-relaxed">
              <span className="block text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">Theory of Liability</span>
              <p className="text-slate-300 leading-relaxed">{report.plaintiffArguments.legalTheory}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Primary Alleged Facts</span>
                <ul className="list-disc pl-4 space-y-1.5 text-slate-400 leading-normal">
                  {report.plaintiffArguments.keyFacts.map((f, i) => <li key={i}>{f}</li>)}
                </ul>
              </div>
              <div className="space-y-1.5">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Primary Exhibits</span>
                <ul className="list-disc pl-4 space-y-1.5 text-slate-400 leading-normal font-mono text-[10px]">
                  {report.plaintiffArguments.keyEvidence.map((e, i) => <li key={i}>{e}</li>)}
                </ul>
              </div>
            </div>

            <div className="p-4 bg-slate-950/30 border border-slate-900 rounded-xl space-y-1 text-slate-400 leading-relaxed">
              <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Legal Citations & Authorities</span>
              <ul className="list-disc pl-4 space-y-1 font-mono text-[10px]">
                {report.plaintiffArguments.authorities.map((auth, i) => <li key={i}>{auth}</li>)}
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* DEFENDANT ARGUMENTS */}
        <Card className="border-slate-850/80">
          <CardHeader className="bg-slate-900/30 p-5 border-b border-slate-850 flex items-center gap-2">
            <Scale className="w-5 h-5 text-slate-400" />
            <CardTitle className="text-slate-200">Defendant Defensive Theory Outline</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-5 text-xs">
            <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1.5 leading-relaxed">
              <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Affirmative Defense Theory</span>
              <p className="text-slate-300 leading-relaxed">{report.defendantArguments.legalTheory}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Primary Disputed Facts</span>
                <ul className="list-disc pl-4 space-y-1.5 text-slate-400 leading-normal">
                  {report.defendantArguments.keyFacts.map((f, i) => <li key={i}>{f}</li>)}
                </ul>
              </div>
              <div className="space-y-1.5">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Exhibits Mapped</span>
                <ul className="list-disc pl-4 space-y-1.5 text-slate-400 leading-normal font-mono text-[10px]">
                  {report.defendantArguments.keyEvidence.map((e, i) => <li key={i}>{e}</li>)}
                </ul>
              </div>
            </div>

            <div className="p-4 bg-slate-950/30 border border-slate-900 rounded-xl space-y-1 text-slate-400 leading-relaxed">
              <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Authorities & Affirmative Rules</span>
              <ul className="list-disc pl-4 space-y-1 font-mono text-[10px]">
                {report.defendantArguments.authorities.map((auth, i) => <li key={i}>{auth}</li>)}
              </ul>
            </div>
          </CardContent>
        </Card>

      </div>

    </div>
  );
};
