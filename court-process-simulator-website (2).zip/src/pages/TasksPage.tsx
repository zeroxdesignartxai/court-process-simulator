/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Calendar, CheckSquare, Plus, Trash2, AlertTriangle, CheckCircle2, ShieldCheck, Clock, FileText } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Button, Input, Select, Badge } from '../components/UI';
import { DeadlineItem, CaseReport } from '../types';

interface TasksPageProps {
  report: CaseReport;
}

export const TasksPage: React.FC<TasksPageProps> = ({ report }) => {
  const [deadlines, setDeadlines] = useState<DeadlineItem[]>(report.deadlines);

  // Form State for new Deadline
  const [label, setLabel] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [calculationMethod, setCalculationMethod] = useState('');
  const [ruleReliedOn, setRuleReliedOn] = useState('');
  const [riskLevel, setRiskLevel] = useState<DeadlineItem['riskLevel']>('low');

  const handleAddDeadline = () => {
    if (!label.trim() || !dueDate) return;
    const newItem: DeadlineItem = {
      id: `dl_${Date.now()}`,
      label,
      dueDate,
      calculationMethod: calculationMethod || 'Static Date Setting',
      ruleReliedOn: ruleReliedOn || 'Custom Rule',
      status: 'unverified',
      riskLevel
    };
    setDeadlines([...deadlines, newItem]);
    setLabel('');
    setDueDate('');
    setCalculationMethod('');
    setRuleReliedOn('');
    setRiskLevel('low');
  };

  const handleToggleVerify = (id: string) => {
    setDeadlines((prev) =>
      prev.map((dl) =>
        dl.id === id
          ? {
              ...dl,
              status: dl.status === 'verified' ? 'unverified' : 'verified',
            }
          : dl
      )
    );
  };

  const handleDelete = (id: string) => {
    setDeadlines(deadlines.filter((dl) => dl.id !== id));
  };

  return (
    <div className="space-y-6 animate-fade-in" id="tasks_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <Badge variant="purple">Litigation Scheduler</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Tasks, Deadlines & Priority Action Plans</h2>
          <p className="text-xs text-slate-400">Track critical responsive pleadings, calculate litigation triggers, and coordinate priority action recommendations.</p>
        </div>
        <Badge variant="destructive">
          <AlertTriangle className="w-3.5 h-3.5 mr-1" />
          High Risk Deadlines Pending
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: DEADLINE CALENDAR LIST */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Civil Litigation Deadlines</CardTitle>
              <CardDescription>Review strict dates computed against filing triggers and service checklists.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-3.5">
              {deadlines.length === 0 ? (
                <p className="text-xs text-slate-500 italic">No scheduled deadlines.</p>
              ) : (
                <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                  {deadlines.map((dl) => {
                    const isVerified = dl.status === 'verified';
                    const riskBadge = {
                      high: 'destructive' as const,
                      medium: 'warning' as const,
                      low: 'secondary' as const
                    }[dl.riskLevel];

                    return (
                      <div
                        key={dl.id}
                        className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition-all ${
                          isVerified
                            ? 'bg-emerald-950/5 border-emerald-900/20'
                            : 'bg-slate-950/40 border-slate-850/80'
                        }`}
                      >
                        <div className="flex items-start gap-3 min-w-0">
                          <input 
                            type="checkbox" 
                            checked={isVerified}
                            onChange={() => handleToggleVerify(dl.id)}
                            className="w-4.5 h-4.5 rounded border-slate-800 text-indigo-600 focus:ring-indigo-500 bg-slate-950 mt-1 cursor-pointer"
                          />
                          <div className="min-w-0 space-y-1">
                            <h4 className={`text-xs font-black truncate leading-tight ${isVerified ? 'text-slate-400 line-through' : 'text-slate-200'}`}>
                              {dl.label}
                            </h4>
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-slate-500 font-mono">
                              <span className="text-indigo-400 font-bold flex items-center gap-1 shrink-0">
                                <Calendar className="w-3 h-3" />
                                {dl.dueDate}
                              </span>
                              <span className="truncate max-w-[200px]">Rule: {dl.ruleReliedOn}</span>
                              <span className="truncate max-w-[250px] hidden sm:inline">Calc: {dl.calculationMethod}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Badge variant={riskBadge}>
                            {dl.riskLevel} risk
                          </Badge>
                          <button
                            onClick={() => handleDelete(dl.id)}
                            className="p-1.5 hover:bg-rose-950/20 text-slate-500 hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* CALCULATE & ADD DEADLINE */}
          <Card>
            <CardHeader>
              <CardTitle>Calculate & Append Procedural Deadline</CardTitle>
              <CardDescription>Enter strict calendar milestones according to civil code triggers.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input 
                  label="Deadline Label" 
                  value={label} 
                  onChange={(e) => setLabel(e.target.value)} 
                  placeholder="e.g. Demurrer / Motion to Strike Answer"
                />
                <Input 
                  label="Due Calendar Date" 
                  type="date"
                  value={dueDate} 
                  onChange={(e) => setDueDate(e.target.value)} 
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input 
                  label="Statutory Rule Authority" 
                  value={ruleReliedOn} 
                  onChange={(e) => setRuleReliedOn(e.target.value)} 
                  placeholder="e.g. CCP Section 1167 / Rule 12(a)"
                />
                <Select 
                  label="Risk Evaluation" 
                  value={riskLevel} 
                  onChange={(e) => setRiskLevel(e.target.value as any)} 
                  options={[
                    { value: 'low', label: 'Low - Informational' },
                    { value: 'medium', label: 'Medium - Normal Checkpoint' },
                    { value: 'high', label: 'High - Jurisdictional Forfeiture' }
                  ]}
                />
              </div>

              <Input 
                label="Calculation Foundation Formula" 
                value={calculationMethod} 
                onChange={(e) => setCalculationMethod(e.target.value)} 
                placeholder="e.g. 5 days after completed conspicuous post-and-mail service"
              />

              <Button onClick={handleAddDeadline} variant="primary" icon={Plus} className="w-full">
                Calculate & Track Deadline
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN: ACTIONABLE RECOMMENDATIONS */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Priority Action Plan</CardTitle>
              <CardDescription>Top strategic recommendation vectors prepared by legal algorithms.</CardDescription>
            </CardHeader>
            <CardContent className="p-5 space-y-4 text-xs">
              {report.recommendations.map((rec, i) => {
                const priorityBadge = {
                  high: 'destructive' as const,
                  medium: 'warning' as const,
                  low: 'secondary' as const
                }[rec.priority];

                return (
                  <div key={rec.id || i} className="p-4 bg-slate-950/40 border border-slate-850 rounded-xl space-y-3">
                    
                    <div className="flex justify-between items-center pb-2 border-b border-slate-900">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                        <h4 className="text-[11px] font-black uppercase text-slate-300">Action Entry #{i + 1}</h4>
                      </div>
                      <Badge variant={priorityBadge}>
                        {rec.priority} Priority
                      </Badge>
                    </div>

                    <div className="space-y-1.5">
                      <span className="block text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Required Action</span>
                      <p className="font-bold text-slate-200 leading-normal">{rec.action}</p>
                    </div>

                    <div className="space-y-1.5">
                      <span className="block text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wider">Strategic Reasoning</span>
                      <p className="text-slate-400 leading-normal">{rec.reason}</p>
                    </div>

                    <div className="p-2.5 bg-rose-950/20 border border-rose-900/10 text-rose-300 rounded-lg flex items-start gap-1.5 text-[10px]">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        Risk if ignored:
                        <span className="block font-medium text-slate-400 mt-0.5 leading-normal">{rec.riskIfIgnored}</span>
                      </div>
                    </div>

                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

      </div>

    </div>
  );
};
