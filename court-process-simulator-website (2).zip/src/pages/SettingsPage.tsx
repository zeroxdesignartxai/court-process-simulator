/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, ShieldCheck, Key, Bell, Info, ShieldAlert, Sparkles, HelpCircle, ChevronRight, ChevronDown } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Button, Input, Badge } from '../components/UI';

export const SettingsPage: React.FC = () => {
  const [notifsEnabled, setNotifsEnabled] = useState(() => {
    try {
      const savedPreferences = JSON.parse(localStorage.getItem('legal-simulator-preferences-v1') || '{}');
      return savedPreferences.notifsEnabled !== false;
    } catch {
      return true;
    }
  });
  const [saved, setSaved] = useState(false);

  // FAQ State
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: "How do I load a custom legal case file?",
      a: "Use the top-right '+ New Case' button, then enter the case title, parties, facts, claims, defenses, and requested remedy. Your case workspace is saved in this browser."
    },
    {
      q: "What do the telemetry values represent?",
      a: "They are synthetic demonstration values used to make the practice environment interactive. They are not connected to courthouse sensors, a judge, a docket, or a live court system."
    },
    {
      q: "Is the simulation data legally binding or constituting advice?",
      a: "No. The Legal Simulator is for organization, education, and strategy practice. It does not predict a judge or jury, establish an attorney-client relationship, or replace advice from a qualified lawyer."
    },
    {
      q: "How is my case information and evidence secured?",
      a: "Case workspace data is saved in this browser. When you run an AI action, structured case text may be sent to the AI service configured by the site owner. Do not enter passwords, account numbers, or information you are not authorized to share."
    }
  ];

  const handleReset = () => {
    localStorage.removeItem('legal-simulator-cases-v2');
    localStorage.removeItem('legal-simulator-active-case-v2');
    localStorage.removeItem('onboarding-completed');
    window.location.hash = '#landing';
    window.location.reload();
  };

  const handleSave = () => {
    localStorage.setItem('legal-simulator-preferences-v1', JSON.stringify({ notifsEnabled }));
    window.dispatchEvent(new CustomEvent('legal-simulator-preferences-updated', {
      detail: { notifsEnabled }
    }));
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1800);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="settings_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <Badge variant="purple">Workspace Configuration</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">System Settings & Interactive FAQ Manuals</h2>
          <p className="text-xs text-slate-400">Configure local workspace preferences and review important usage and privacy guidance.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: SYSTEM SETTINGS CARDS */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>AI Connection</CardTitle>
              <CardDescription>The website uses its configured AI service when available and a built-in demonstration response when it is not.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              
              <div className="flex items-center justify-between gap-4 p-4 bg-slate-950/60 border border-slate-900 rounded-xl">
                <div>
                  <p className="text-xs font-bold text-slate-200">Automatic connection mode</p>
                  <p className="text-[10px] text-slate-500 mt-1">No API key is exposed in the browser.</p>
                </div>
                <Badge variant="success">Auto</Badge>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2 text-xs">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-indigo-400" />
                  API Credentials Protection
                </span>
                <p className="text-slate-400 leading-normal">
                  AI credentials are read only by the server. If no credential is configured, the simulator stays usable with clearly labeled demonstration responses.
                </p>
              </div>

            </CardContent>
          </Card>

          {/* PREFERENCES */}
          <Card>
            <CardHeader>
              <CardTitle>Workspace Preferences</CardTitle>
              <CardDescription>Control the alerts shown in this browser.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4 text-xs">
              
              <div className="flex items-center justify-between p-3.5 bg-slate-950/40 border border-slate-850 rounded-xl">
                <div className="space-y-0.5 max-w-[80%] pr-4">
                  <span className="block font-bold text-slate-200 flex items-center gap-1.5">
                    <Bell className="w-4 h-4 text-emerald-400 shrink-0" />
                    Simulation Alerts
                  </span>
                  <p className="text-slate-400">Show top-bar notices when simulated readiness or hearing-practice values need attention.</p>
                </div>
                <input 
                  type="checkbox" 
                  checked={notifsEnabled}
                  onChange={(e) => setNotifsEnabled(e.target.checked)}
                  className="w-10 h-5 bg-slate-950 border border-slate-850 rounded-full text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                />
              </div>

              <div className="pt-4 border-t border-slate-900 flex justify-end gap-3">
                <Button onClick={handleReset} variant="outline" size="sm">
                  Reset Local Workspace
                </Button>
                <Button onClick={handleSave} variant="primary" size="sm">
                  {saved ? 'Preferences Saved' : 'Save Preferences'}
                </Button>
              </div>

            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN: INTERACTIVE FAQ */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Manuals & Knowledge Base</CardTitle>
              <CardDescription>Expandable operational manuals for the Legal Telemetry Dashboard.</CardDescription>
            </CardHeader>
            <CardContent className="p-5 space-y-3">
              {faqs.map((faq, index) => {
                const isOpen = openFaq === index;
                return (
                  <div key={index} className="border border-slate-850 rounded-xl overflow-hidden transition-all">
                    <button
                      onClick={() => setOpenFaq(isOpen ? null : index)}
                      className={`w-full flex items-center justify-between p-4 text-left text-xs font-bold transition-colors cursor-pointer ${
                        isOpen ? 'bg-slate-850/40 text-indigo-400' : 'bg-slate-950/20 text-slate-300 hover:bg-slate-850/20'
                      }`}
                    >
                      <span className="pr-4 leading-normal">{faq.q}</span>
                      {isOpen ? (
                        <ChevronDown className="w-4 h-4 text-indigo-400 shrink-0" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                    </button>
                    {isOpen && (
                      <div className="p-4 bg-slate-950/60 text-xs text-slate-400 leading-relaxed border-t border-slate-850/60">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </div>

      </div>

    </div>
  );
};
