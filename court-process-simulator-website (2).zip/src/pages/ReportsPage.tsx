/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Share2, 
  Activity, 
  AlertTriangle, 
  Database, 
  Server, 
  FileSpreadsheet,
  Volume2, 
  RefreshCw,
  PlusCircle,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge, Button, Progress } from '../components/UI';
import { CaseReport, SensorMetric, TelemetryAlert } from '../types';
import TelemetryDashboard from '../components/TelemetryDashboard';

interface ReportsPageProps {
  report: CaseReport;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ report }) => {
  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    // Generate simple mock CSV export file
    const headers = 'Alert ID,Timestamp,Metric Category,Severity,Message\n';
    const rows = [
      'al_7a92,10:24:15 AM,noise,critical,"Decibel Anomaly: Extreme sound levels detected in Courtroom B (92 dB)."\n',
      'al_4f2a,10:24:32 AM,cpu,critical,"System Anomaly: Prediction load exceeded 90%."\n'
    ];
    const blob = new Blob([headers + rows.join('')], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'telemetry_alerts_history.csv';
    a.click();
  };

  return (
    <div className="space-y-6 animate-fade-in" id="reports_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <Badge variant="purple">Legal Data Dossier</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Telemetry Records & Certified Exporters</h2>
          <p className="text-xs text-slate-400">Compile judicial summaries, audit live IoT sound feeds, and export certified dossier PDF packages.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <Button onClick={handlePrint} variant="outline" size="sm" icon={Printer}>
            Print Dossier Pack
          </Button>
          <Button onClick={handleExportCSV} variant="secondary" size="sm" icon={Download}>
            Export CSV Log
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        
        {/* TAB 1: FULL COMPLEX TELEMETRY VIEW */}
        <Card className="border-slate-850/80">
          <CardHeader className="border-b border-slate-850">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-400" />
              <div>
                <CardTitle>IoT Courtroom Telemetry Feed</CardTitle>
                <CardDescription>Live streaming audit logs tracking hearing ambient sound, docket queues, and prediction nodes.</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {/* We render the premium original TelemetryDashboard component directly for perfect fidelity to the codebase! */}
            <TelemetryDashboard />
          </CardContent>
        </Card>

        {/* COMPREHENSIVE DOSSIER EXPORT INDEX */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-slate-900/50">
            <CardContent className="p-6 space-y-4">
              <div className="w-10 h-10 bg-indigo-950 border border-indigo-900/20 text-indigo-400 rounded-xl flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xs font-black uppercase text-slate-200">Certified Case Brief (PDF)</h3>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Download a printable briefing memorandum containing the full IRAC merits matrix and case history timeline.
                </p>
              </div>
              <Button onClick={handlePrint} variant="outline" size="sm" className="w-full">
                Download Memorandums
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50">
            <CardContent className="p-6 space-y-4">
              <div className="w-10 h-10 bg-rose-950 border border-rose-900/20 text-rose-400 rounded-xl flex items-center justify-center">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xs font-black uppercase text-slate-200">Fact Chronology CSV</h3>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Export an structured spreadsheet audit log detailing facts, evidentiary associations, and verification timelines.
                </p>
              </div>
              <Button onClick={handleExportCSV} variant="outline" size="sm" className="w-full">
                Export Spreadsheet
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/50">
            <CardContent className="p-6 space-y-4">
              <div className="w-10 h-10 bg-purple-950 border border-purple-900/20 text-purple-400 rounded-xl flex items-center justify-center">
                <Share2 className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xs font-black uppercase text-slate-200">Collaborative Workspace Link</h3>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Generate a temporary read-only token link to securely share the telemetry graphs and trial simulators with external experts.
                </p>
              </div>
              <Button onClick={() => alert('Temporary sharing token generated: s_token_3a9f92b4')} variant="outline" size="sm" className="w-full">
                Generate Share Token
              </Button>
            </CardContent>
          </Card>
        </div>

      </div>

    </div>
  );
};
