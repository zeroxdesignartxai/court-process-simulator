/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Trash2, Scale, UserPlus, Calendar, PlusCircle, Sparkles } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Button, Input, Select, Textarea, Badge } from '../components/UI';
import { CaseIntake, Party, FactItem } from '../types';

interface IntakePageProps {
  activeCase: CaseIntake;
  onUpdateCase: (updated: CaseIntake) => void;
  onProcessCase: () => void;
  isProcessing: boolean;
}

export const IntakePage: React.FC<IntakePageProps> = ({
  activeCase,
  onUpdateCase,
  onProcessCase,
  isProcessing
}) => {
  // Form Local State
  const [title, setTitle] = useState(activeCase.title);
  const [caseType, setCaseType] = useState(activeCase.caseType);
  const [jurisdiction, setJurisdiction] = useState(activeCase.jurisdiction);
  const [courtName, setCourtName] = useState(activeCase.courtName);
  const [amountInControversy, setAmountInControversy] = useState(activeCase.amountInControversy);
  const [remedyRequested, setRemedyRequested] = useState(activeCase.remedyRequested);

  // Lists State
  const [parties, setParties] = useState<Party[]>(activeCase.parties);
  const [facts, setFacts] = useState<FactItem[]>(activeCase.facts);

// New Party Temporary Form State
  const [newPartyName, setNewPartyName] = useState('');
  const [newPartyRole, setNewPartyRole] = useState<'plaintiff' | 'defendant'>('plaintiff');
  const [newPartyType, setNewPartyType] = useState<'individual' | 'organization'>('individual');
  const [newPartyVoucherType, setNewPartyVoucherType] = useState<'none' | 'section8' | 'public_housing' | 'vash' | 'lihtc' | 'other'>('none');
  const [newPartyDisabilityStatus, setNewPartyDisabilityStatus] = useState<'none' | 'mobility' | 'cognitive' | 'animal' | 'other'>('none');
  const [newPartyServiceMethod, setNewPartyServiceMethod] = useState<'none' | 'personal' | 'defective_lobby' | 'defective_none' | 'substituted' | 'nail_and_mail'>('none');

  const SUGGESTED_PARTIES = [
    { label: "Custom Name (Type below)", name: "", role: "defendant", type: "individual", voucherType: "none", disabilityStatus: "none", serviceMethod: "none" },
    { label: "Mauricio Sanchez (Section 8 Tenant)", name: "Mauricio Sanchez", role: "defendant", type: "individual", voucherType: "section8", disabilityStatus: "mobility", serviceMethod: "defective_lobby" },
    { label: "Marcus Sterling (Private Tenant)", name: "Marcus Sterling", role: "defendant", type: "individual", voucherType: "none", disabilityStatus: "none", serviceMethod: "defective_lobby" },
    { label: "AHM Resicom LLC (Corporate Landlord)", name: "AHM Resicom LLC", role: "plaintiff", type: "organization", voucherType: "none", disabilityStatus: "none", serviceMethod: "none" },
    { label: "Eldorado Realty Corp (Corporate Landlord)", name: "Eldorado Realty Corp", role: "plaintiff", type: "organization", voucherType: "none", disabilityStatus: "none", serviceMethod: "none" },
    { label: "Housing Authority of the City of Los Angeles (HACLA)", name: "Housing Authority of the City of Los Angeles (HACLA)", role: "defendant", type: "organization", voucherType: "none", disabilityStatus: "none", serviceMethod: "none" },
    { label: "U.S. Dept of Housing & Urban Development (HUD)", name: "U.S. Dept of Housing & Urban Development (HUD)", role: "defendant", type: "organization", voucherType: "none", disabilityStatus: "none", serviceMethod: "none" }
  ];

  const STANDARD_CLAIMS = [
    "Breach of Written Lease",
    "Warranty of Habitability Breach",
    "Constructive Eviction",
    "Retaliatory Rent Increase",
    "Unlawful Detainer Relief",
    "Covenant of Quiet Enjoyment Breach",
    "Security Deposit Withholding",
    "Negligent Maintenance",
    "Unjust Enrichment"
  ];

  const STANDARD_DEFENSES = [
    "Warranty of Habitability Defense",
    "Retaliatory Eviction Defense",
    "Improper Service of Process",
    "Laches / Unreasonable Delay",
    "Estoppel / Waiver",
    "Failure to Mitigate Damages",
    "Cure of Breach Completed",
    "Constructive Eviction Offset",
    "Mutual Mistake"
  ];

  const handleUpdatePartyInline = (id: string, updates: Partial<Party>) => {
    const updated = parties.map((p) => {
      if (p.id === id) {
        return { ...p, ...updates };
      }
      return p;
    });
    setParties(updated);
    triggerSync(updated, facts);
  };

  const handleAddClaimToParty = (partyId: string, claim: string) => {
    const party = parties.find(p => p.id === partyId);
    if (!party) return;
    if (party.claims.includes(claim)) return;
    handleUpdatePartyInline(partyId, { claims: [...party.claims, claim] });
  };

  const handleRemoveClaimFromParty = (partyId: string, claim: string) => {
    const party = parties.find(p => p.id === partyId);
    if (!party) return;
    handleUpdatePartyInline(partyId, { claims: party.claims.filter(c => c !== claim) });
  };

  const handleAddDefenseToParty = (partyId: string, defense: string) => {
    const party = parties.find(p => p.id === partyId);
    if (!party) return;
    if (party.defenses.includes(defense)) return;
    handleUpdatePartyInline(partyId, { defenses: [...party.defenses, defense] });
  };

  const handleRemoveDefenseFromParty = (partyId: string, defense: string) => {
    const party = parties.find(p => p.id === partyId);
    if (!party) return;
    handleUpdatePartyInline(partyId, { defenses: party.defenses.filter(d => d !== defense) });
  };

  // New Fact Temporary Form State
  const [newFactDesc, setNewFactDesc] = useState('');
  const [newFactDate, setNewFactDate] = useState('');
  const [newFactStatus, setNewFactStatus] = useState<'admitted' | 'disputed' | 'allegation' | 'unknown'>('allegation');

  const handleAddParty = () => {
    if (!newPartyName.trim()) return;
    const party: Party = {
      id: `p_${Date.now()}`,
      name: newPartyName,
      role: newPartyRole,
      type: newPartyType,
      represented: true,
      claims: [],
      defenses: [],
      voucherType: newPartyVoucherType,
      disabilityStatus: newPartyDisabilityStatus,
      serviceMethod: newPartyServiceMethod,
    };
    const updated = [...parties, party];
    setParties(updated);
    setNewPartyName('');
    setNewPartyRole('plaintiff');
    setNewPartyType('individual');
    setNewPartyVoucherType('none');
    setNewPartyDisabilityStatus('none');
    setNewPartyServiceMethod('none');
    triggerSync(updated, facts);
  };

  const handleRemoveParty = (id: string) => {
    const updated = parties.filter((p) => p.id !== id);
    setParties(updated);
    triggerSync(updated, facts);
  };

  const handleAddFact = () => {
    if (!newFactDesc.trim()) return;
    const fact: FactItem = {
      id: `f_${Date.now()}`,
      description: newFactDesc,
      date: newFactDate || new Date().toISOString().split('T')[0],
      status: newFactStatus,
      evidenceIds: []
    };
    const updated = [...facts, fact];
    setFacts(updated);
    setNewFactDesc('');
    setNewFactDate('');
    triggerSync(parties, updated);
  };

  const handleRemoveFact = (id: string) => {
    const updated = facts.filter((f) => f.id !== id);
    setFacts(updated);
    triggerSync(parties, updated);
  };

  const triggerSync = (pList = parties, fList = facts) => {
    const updatedCase: CaseIntake = {
      ...activeCase,
      title,
      caseType,
      jurisdiction,
      courtName,
      amountInControversy: Number(amountInControversy),
      remedyRequested,
      parties: pList,
      facts: fList,
    };
    onUpdateCase(updatedCase);
  };

  const handleSaveAndAnalyze = () => {
    triggerSync();
    onProcessCase();
  };

  return (
    <div className="space-y-6 animate-fade-in" id="intake_page_root">
      
      {/* HEADER SECTION */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <Badge variant="purple">Case Dossier Builder</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Structured Intake Form & Merits Context</h2>
          <p className="text-xs text-slate-400">Modify facts, claims, defenses, and litigant profiles to feed the predictive courtroom models.</p>
        </div>
        <Button 
          onClick={handleSaveAndAnalyze} 
          variant="primary" 
          disabled={isProcessing}
          icon={Sparkles}
          className="w-full md:w-auto"
        >
          {isProcessing ? 'Processing Litigation Model...' : 'Sync & Re-Simulate Case'}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* LEFT COLUMN: CORE METADATA */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>1. Primary Case Dossier Metadata</CardTitle>
              <CardDescription>Establish core litigation parameters, jurisdiction, and damages prayer.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <Input 
                label="Case Title / Caption" 
                value={title} 
                onChange={(e) => { setTitle(e.target.value); triggerSync(); }} 
                placeholder="e.g. Sanchez v. AHM Resicom LLC"
              />
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select 
                  label="Procedural Case Type" 
                  value={caseType} 
                  onChange={(e) => { setCaseType(e.target.value as any); triggerSync(); }} 
                  options={[
                    { value: 'landlord_tenant', label: 'Landlord - Tenant Dispute' },
                    { value: 'small_claims', label: 'Small Claims Action' },
                    { value: 'contract_dispute', label: 'Breach of Contract' },
                    { value: 'debt_collection', label: 'Debt Collection Defence' },
                    { value: 'employment', label: 'Employment Dispute' }
                  ]}
                />
                <Input 
                  label="Amount In Controversy ($)" 
                  type="number"
                  value={amountInControversy} 
                  onChange={(e) => { setAmountInControversy(Number(e.target.value)); triggerSync(); }} 
                  placeholder="e.g. 15000"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input 
                  label="Jurisdiction Code" 
                  value={jurisdiction} 
                  onChange={(e) => { jurisdiction && setJurisdiction(e.target.value); triggerSync(); }} 
                  placeholder="e.g. State of California (County of Los Angeles)"
                />
                <Input 
                  label="Filing Court Forum Name" 
                  value={courtName} 
                  onChange={(e) => { courtName && setCourtName(e.target.value); triggerSync(); }} 
                  placeholder="e.g. Los Angeles County Superior Court"
                />
              </div>

              <Textarea 
                label="Prayer for Relief / Remedy Requested" 
                value={remedyRequested} 
                onChange={(e) => { setRemedyRequested(e.target.value); triggerSync(); }} 
                placeholder="Provide a description of damages, restitution, injunctions or other prayers."
              />
            </CardContent>
          </Card>

          {/* FACT TIMELINE EDITOR */}
          <Card>
            <CardHeader>
              <CardTitle>2. Fact Timelines & Evidentiary Claims</CardTitle>
              <CardDescription>Formulate chronological disputes and assert their trial admission status.</CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              
              {/* Add Fact Form */}
              <div className="p-4 bg-slate-950/40 border border-slate-850 rounded-xl space-y-4">
                <span className="block text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">Append Chronological Fact</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input 
                    label="Calendar Date" 
                    type="date"
                    value={newFactDate} 
                    onChange={(e) => setNewFactDate(e.target.value)}
                  />
                  <Select 
                    label="Admission Status" 
                    value={newFactStatus} 
                    onChange={(e) => setNewFactStatus(e.target.value as any)} 
                    options={[
                      { value: 'admitted', label: 'Admitted / Undisputed' },
                      { value: 'disputed', label: 'Contested / Disputed' },
                      { value: 'allegation', label: 'Plead Allegation' },
                      { value: 'unknown', label: 'Unverified status' }
                    ]}
                  />
                </div>
                <Textarea 
                  label="Fact Allegation Description" 
                  value={newFactDesc} 
                  onChange={(e) => setNewFactDesc(e.target.value)} 
                  placeholder="e.g. Process server left notice on lobby floor rather than physical in-hand service."
                />
                <Button onClick={handleAddFact} variant="outline" size="sm" icon={Plus}>
                  Add Fact Entry
                </Button>
              </div>

              {/* Facts List */}
              <div className="space-y-2">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Chronological Case Facts ({facts.length})</span>
                {facts.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No facts added yet.</p>
                ) : (
                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {facts.map((fact) => {
                      const badgeVariant = {
                        admitted: 'success' as const,
                        disputed: 'destructive' as const,
                        allegation: 'warning' as const,
                        unknown: 'secondary' as const
                      }[fact.status];

                      return (
                        <div key={fact.id} className="flex items-start justify-between gap-4 p-3 bg-slate-950/20 border border-slate-850 rounded-xl hover:border-slate-850">
                          <div className="space-y-1.5 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold text-indigo-400 bg-indigo-950/20 px-2 py-0.5 rounded border border-indigo-900/10">
                                <Calendar className="w-3 h-3" />
                                {fact.date}
                              </span>
                              <Badge variant={badgeVariant}>{fact.status}</Badge>
                            </div>
                            <p className="text-xs text-slate-300 leading-normal">{fact.description}</p>
                          </div>
                          <button 
                            onClick={() => handleRemoveFact(fact.id)}
                            className="p-1.5 hover:bg-rose-950/20 text-slate-500 hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN: LITIGANT PARTIES */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>3. Litigating Parties & Counsel</CardTitle>
              <CardDescription>Manage active plaintiffs, defendants, and legal representatives.</CardDescription>
            </CardHeader>
            <CardContent className="p-5 space-y-5">
              
              {/* Add Party Form */}
              <div className="p-3.5 bg-slate-950/40 border border-slate-850 rounded-xl space-y-3">
                <span className="block text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider">Add Litigant Profile</span>
                
                {/* PRESET SELECTOR - Dropdown of possible answers for the party/person */}
                <div>
                  <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Preset Litigant Templates</label>
                  <select
                    onChange={(e) => {
                      const idx = Number(e.target.value);
                      const p = SUGGESTED_PARTIES[idx];
                      if (p) {
                        setNewPartyName(p.name);
                        setNewPartyRole(p.role as any);
                        setNewPartyType(p.type as any);
                        setNewPartyVoucherType(p.voucherType as any);
                        setNewPartyDisabilityStatus(p.disabilityStatus as any);
                        setNewPartyServiceMethod(p.serviceMethod as any);
                      }
                    }}
                    defaultValue="0"
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-indigo-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    {SUGGESTED_PARTIES.map((party, idx) => (
                      <option key={idx} value={idx}>{party.label}</option>
                    ))}
                  </select>
                </div>

                <Input 
                  label="Litigant / Entity Name" 
                  value={newPartyName} 
                  onChange={(e) => setNewPartyName(e.target.value)} 
                  placeholder="e.g. Mauricio Sanchez"
                />
                <div className="grid grid-cols-2 gap-2">
                  <Select 
                    label="Role" 
                    value={newPartyRole} 
                    onChange={(e) => setNewPartyRole(e.target.value as any)} 
                    options={[
                      { value: 'plaintiff', label: 'Plaintiff' },
                      { value: 'defendant', label: 'Defendant' }
                    ]}
                  />
                  <Select 
                    label="Entity Type" 
                    value={newPartyType} 
                    onChange={(e) => setNewPartyType(e.target.value as any)} 
                    options={[
                      { value: 'individual', label: 'Individual' },
                      { value: 'organization', label: 'Organization' }
                    ]}
                  />
                </div>

                {/* Additional housing-specific properties dropdowns (Dropdown menu of possible answers for each part of person) */}
                <div className="grid grid-cols-1 gap-2.5 pt-2 border-t border-slate-850/60">
                  <div>
                    <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Housing Voucher / Tenancy Class</label>
                    <select
                      value={newPartyVoucherType}
                      onChange={(e) => setNewPartyVoucherType(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="none">None (Market Rate Tenant / Owner)</option>
                      <option value="section8">Section 8 Housing Choice Voucher</option>
                      <option value="public_housing">HUD Public Housing Program</option>
                      <option value="vash">VASH (Veteran Housing Assistance)</option>
                      <option value="lihtc">LIHTC (Low-Income Tax Credit Unit)</option>
                      <option value="other">Other Subsidized Housing Program</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Disability / Accommodation Requirement</label>
                    <select
                      value={newPartyDisabilityStatus}
                      onChange={(e) => setNewPartyDisabilityStatus(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="none">No Disability Accommodation Claimed</option>
                      <option value="mobility">Physical Mobility Accommodation Request</option>
                      <option value="cognitive">Cognitive / Mental Health Accommodation Request</option>
                      <option value="animal">Service or Emotional Support Animal Request</option>
                      <option value="other">Other Reasonable Accommodation Request</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Notice / Service of Process Method</label>
                    <select
                      value={newPartyServiceMethod}
                      onChange={(e) => setNewPartyServiceMethod(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                    >
                      <option value="none">No Notice Active</option>
                      <option value="personal">In-Hand Personal Service (Rule 4/CCP 1162)</option>
                      <option value="defective_lobby">Defective Service (Left in Common Lobby Basket)</option>
                      <option value="defective_none">Defective Service (No Written Notice Received)</option>
                      <option value="substituted">Substituted Service (Left with Co-resident/Worker)</option>
                      <option value="nail_and_mail">Nail and Mail (Posted on Entrance Door)</option>
                    </select>
                  </div>
                </div>

                <Button onClick={handleAddParty} variant="outline" size="sm" icon={UserPlus} className="w-full">
                  Add Party
                </Button>
              </div>

              {/* Parties List */}
              <div className="space-y-4">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">Active Parties ({parties.length})</span>
                {parties.map((p) => {
                  return (
                    <div key={p.id} className="p-4 bg-slate-950/40 border border-slate-850 rounded-xl space-y-3 relative">
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-1">
                          <input
                            type="text"
                            value={p.name}
                            onChange={(e) => handleUpdatePartyInline(p.id, { name: e.target.value })}
                            className="bg-transparent border-b border-dashed border-slate-700 hover:border-slate-500 focus:border-indigo-500 text-xs font-bold text-slate-200 px-1 py-0.5 focus:outline-none w-full"
                            placeholder="Litigant Name"
                          />
                        </div>
                        <button 
                          onClick={() => handleRemoveParty(p.id)}
                          className="p-1 hover:bg-rose-950/30 text-slate-500 hover:text-rose-400 rounded transition-colors cursor-pointer"
                          title="Remove Party"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Dropdown controls for each part of person */}
                      <div className="grid grid-cols-1 gap-2.5 pt-1">
                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Litigant Role</label>
                          <select
                            value={p.role}
                            onChange={(e) => handleUpdatePartyInline(p.id, { role: e.target.value as any })}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="plaintiff">Plaintiff (Claimant)</option>
                            <option value="defendant">Defendant (Responding)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Entity Type</label>
                          <select
                            value={p.type}
                            onChange={(e) => handleUpdatePartyInline(p.id, { type: e.target.value as any })}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="individual">Individual</option>
                            <option value="organization">Corporate / Organization</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Legal Representation</label>
                          <select
                            value={p.represented ? 'true' : 'false'}
                            onChange={(e) => handleUpdatePartyInline(p.id, { represented: e.target.value === 'true' })}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="true">Represented by Counsel</option>
                            <option value="false">Self-Represented (Pro Se)</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Housing Voucher / Tenancy Class</label>
                          <select
                            value={p.voucherType || 'none'}
                            onChange={(e) => handleUpdatePartyInline(p.id, { voucherType: e.target.value as any })}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="none">None (Market Rate Tenant / Owner)</option>
                            <option value="section8">Section 8 Housing Choice Voucher</option>
                            <option value="public_housing">HUD Public Housing Program</option>
                            <option value="vash">VASH (Veteran Housing Assistance)</option>
                            <option value="lihtc">LIHTC (Low-Income Tax Credit Unit)</option>
                            <option value="other">Other Subsidized Housing Program</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Disability / Accommodation Requirement</label>
                          <select
                            value={p.disabilityStatus || 'none'}
                            onChange={(e) => handleUpdatePartyInline(p.id, { disabilityStatus: e.target.value as any })}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="none">No Disability Accommodation Claimed</option>
                            <option value="mobility">Physical Mobility Accommodation Request</option>
                            <option value="cognitive">Cognitive / Mental Health Accommodation Request</option>
                            <option value="animal">Service or Emotional Support Animal Request</option>
                            <option value="other">Other Reasonable Accommodation Request</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Notice / Service of Process Method</label>
                          <select
                            value={p.serviceMethod || 'none'}
                            onChange={(e) => handleUpdatePartyInline(p.id, { serviceMethod: e.target.value as any })}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-300 focus:outline-none focus:border-indigo-500"
                          >
                            <option value="none">No Notice Active</option>
                            <option value="personal">In-Hand Personal Service (Rule 4/CCP 1162)</option>
                            <option value="defective_lobby">Defective Service (Left in Common Lobby Basket)</option>
                            <option value="defective_none">Defective Service (No Written Notice Received)</option>
                            <option value="substituted">Substituted Service (Left with Co-resident/Worker)</option>
                            <option value="nail_and_mail">Nail and Mail (Posted on Entrance Door)</option>
                          </select>
                        </div>

                        {/* Add Claim Dropdown */}
                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Add Legal Claims</label>
                          <select
                            value=""
                            onChange={(e) => {
                              if (e.target.value) {
                                handleAddClaimToParty(p.id, e.target.value);
                              }
                            }}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-indigo-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            <option value="" disabled>-- Select claim answer --</option>
                            {STANDARD_CLAIMS.map((claim) => (
                              <option key={claim} value={claim}>{claim}</option>
                            ))}
                          </select>
                          {p.claims && p.claims.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1.5">
                              {p.claims.map((claim) => (
                                <span key={claim} className="inline-flex items-center gap-1 bg-indigo-950/40 border border-indigo-900/40 text-indigo-400 text-[9px] px-1.5 py-0.5 rounded">
                                  {claim}
                                  <button onClick={() => handleRemoveClaimFromParty(p.id, claim)} className="hover:text-indigo-200 text-indigo-600 font-bold ml-0.5">×</button>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Add Defense Dropdown */}
                        <div>
                          <label className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Add Legal Defenses</label>
                          <select
                            value=""
                            onChange={(e) => {
                              if (e.target.value) {
                                handleAddDefenseToParty(p.id, e.target.value);
                              }
                            }}
                            className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-emerald-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                          >
                            <option value="" disabled>-- Select defense answer --</option>
                            {STANDARD_DEFENSES.map((defense) => (
                              <option key={defense} value={defense}>{defense}</option>
                            ))}
                          </select>
                          {p.defenses && p.defenses.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1.5">
                              {p.defenses.map((defense) => (
                                <span key={defense} className="inline-flex items-center gap-1 bg-emerald-950/40 border border-emerald-900/40 text-emerald-400 text-[9px] px-1.5 py-0.5 rounded">
                                  {defense}
                                  <button onClick={() => handleRemoveDefenseFromParty(p.id, defense)} className="hover:text-emerald-200 text-emerald-600 font-bold ml-0.5">×</button>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                      </div>
                    </div>
                  );
                })}
              </div>

            </CardContent>
          </Card>
        </div>

      </div>

    </div>
  );
};
