/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BookOpen, Search, FileText, Scale, Sparkles, Copy, Check, 
  HelpCircle, ShieldAlert, CheckCircle2, ChevronDown, ChevronUp, AlertCircle,
  History, Calendar, Clock, Gavel, ArrowRight, Lock, Unlock, ExternalLink, Briefcase,
  MapPin
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge, Button } from '../components/UI';
import { CaseIntake } from '../types';

interface ResearchPageProps {
  activeCase?: CaseIntake;
}

interface Statute {
  code: string;
  title: string;
  summary: string;
  application: string;
}

interface CasePrecedent {
  name: string;
  citation: string;
  facts: string;
  issue: string;
  holding: string;
  relevance: string;
}

interface Doctrine {
  name: string;
  definition: string;
  burdenOfProof: string;
}

interface LegalTopic {
  broadTopic: string;
  subtopic: string;
  elements: string;
  exceptionDefenses: string;
  burdenAndStandard: string;
  remedies: string;
}

interface EvidenceItem {
  item: string;
  proves: string;
  hearsayAndAuthentication: string;
  risks: string;
}

interface ProceduralRisk {
  issue: string;
  rules: string;
  deadlines: string;
  waiverRisks: string;
}

interface RiskAssessmentItem {
  argument: string;
  score: number;
  legalAuthority: string;
  factualSupport: string;
  admissibility: string;
  explanation: string;
}

interface SourceVerificationRow {
  proposition: string;
  source: string;
  authorityLevel: string;
  jurisdiction: string;
  verified: string;
  citationOrLink: string;
  notes: string;
}

interface PaymentReconciliationRow {
  month: string;
  contractRent: string;
  haclaPortion: string;
  tenantPortion: string;
  tenantPayment: string;
  ownerCredit: string;
  adjustment: string;
  abatement: string;
  claimedBalance: string;
  verifiedLawfulBalance: string;
  sourceDocument: string;
}

interface ResearchMemo {
  summary: string;
  statutes: Statute[];
  cases: CasePrecedent[];
  doctrines: Doctrine[];
  practiceTips: string[];
  
  // New rich analytical sections
  jurisdictionAndDate?: string;
  confirmedFacts?: string[];
  disputedFacts?: string[];
  legalIssues?: string[];
  legalTopicMap?: LegalTopic[];
  evidenceAnalysis?: EvidenceItem[];
  proceduralRisks?: ProceduralRisk[];
  strongestUserArguments?: string[];
  strongestOpposingArguments?: string[];
  missingEvidence?: string[];
  riskAssessment?: RiskAssessmentItem[];
  recommendedActions?: string[];
  plainEnglishExplanation?: string;
  sourceVerificationTable?: SourceVerificationRow[];
  paymentReconciliationTable?: PaymentReconciliationRow[];
}

export const ResearchPage: React.FC<ResearchPageProps> = ({ activeCase }) => {
  const [activeTab, setActiveTab] = useState<'guides' | 'search' | 'citation' | 'procedure'>('guides');
  
  // Custom Search Query State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCaseType, setSelectedCaseType] = useState(activeCase?.caseType || 'landlord_tenant');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('California Superior Court');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [searchResult, setSearchResult] = useState<ResearchMemo | null>(null);
  const [researchSubTab, setResearchSubTab] = useState<'exec' | 'law' | 'facts' | 'risks'>('exec');

  // States for Federal Procedure Tab
  const [selectedProcSection, setSelectedProcSection] = useState<string>('rulebook');
  const [calcTriggerDate, setCalcTriggerDate] = useState<string>('2026-07-13');
  const [calcRuleType, setCalcRuleType] = useState<string>('rule12a');
  const [calcResult, setCalcResult] = useState<{
    date: string;
    rule: string;
    days: number;
    description: string;
    holidaysEncountered: string[];
  } | null>(null);

  const calculateDeadline = (triggerStr: string, ruleType: string) => {
    if (!triggerStr) return;
    const trigger = new Date(triggerStr + 'T12:00:00'); // Midday avoids timezone offsets
    if (isNaN(trigger.getTime())) return;

    let days = 21;
    let rule = 'Rule 12(a)(1)(A)(i)';
    let desc = 'Time to serve an answer or Rule 12 motion after being served with summons and complaint.';

    switch (ruleType) {
      case 'rule12a':
        days = 21;
        rule = 'FRCP Rule 12(a)(1)(A)(i)';
        desc = 'Time to serve an answer or Rule 12 motion after being served with summons and complaint.';
        break;
      case 'rule4d_waived':
        days = 60;
        rule = 'FRCP Rule 4(d)(3)';
        desc = 'Time to serve an answer when service is waived (within the United States).';
        break;
      case 'rule12a_us':
        days = 60;
        rule = 'FRCP Rule 12(a)(2) & (3)';
        desc = 'Time for the United States, its agencies, or officers to answer.';
        break;
      case 'remand_defect':
        days = 30;
        rule = '28 U.S.C. § 1447(c)';
        desc = 'Deadline to file a motion to remand based on any defect other than lack of subject-matter jurisdiction.';
        break;
      case 'rule12a4_denied':
        days = 14;
        rule = 'FRCP Rule 12(a)(4)(A)';
        desc = 'Deadline to serve responsive pleading if the court denies a Rule 12 motion or postpones its disposition.';
        break;
      case 'rule15a_right':
        days = 21;
        rule = 'FRCP Rule 15(a)(1)(B)';
        desc = 'Time to amend a pleading once as a matter of course after service of a responsive pleading or Rule 12 motion.';
        break;
      case 'rule26_disclosures':
        days = 14;
        rule = 'FRCP Rule 26(a)(1)(C)';
        desc = 'Deadline to make initial disclosures after the parties’ Rule 26(f) conference.';
        break;
      case 'frap4_appeal':
        days = 30;
        rule = 'FRAP Rule 4(a)(1)(A)';
        desc = 'Standard time to file a notice of appeal with the district clerk after entry of judgment.';
        break;
      case 'frap4_appeal_us':
        days = 60;
        rule = 'FRAP Rule 4(a)(1)(B)';
        desc = 'Time to file a notice of appeal when the United States or its agency/officer is a party.';
        break;
    }

    let target = new Date(trigger.getTime());
    target.setDate(target.getDate() + days);

    const holidaysEncountered: string[] = [];
    const isWeekendOrHoliday = (date: Date) => {
      const day = date.getDay();
      if (day === 0) {
        holidaysEncountered.push('Sunday');
        return true;
      }
      if (day === 6) {
        holidaysEncountered.push('Saturday');
        return true;
      }
      
      const m = date.getMonth();
      const d = date.getDate();
      if (m === 6 && d === 4) {
        holidaysEncountered.push('Independence Day (July 4)');
        return true;
      }
      if (m === 11 && d === 25) {
        holidaysEncountered.push('Christmas Day (Dec 25)');
        return true;
      }
      if (m === 0 && d === 1) {
        holidaysEncountered.push('New Year\'s Day (Jan 1)');
        return true;
      }
      if (m === 10 && d === 11) {
        holidaysEncountered.push('Veterans Day (Nov 11)');
        return true;
      }
      return false;
    };

    while (isWeekendOrHoliday(target)) {
      target.setDate(target.getDate() + 1);
    }

    const formatStr = target.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    setCalcResult({
      date: formatStr,
      rule,
      days,
      description: desc,
      holidaysEncountered: Array.from(new Set(holidaysEncountered))
    });
  };

  useEffect(() => {
    calculateDeadline(calcTriggerDate, calcRuleType);
  }, [calcTriggerDate, calcRuleType]);

  // Expanded cards tracker for statutes & cases
  const [expandedStatute, setExpandedStatute] = useState<number | null>(null);
  const [expandedCase, setExpandedCase] = useState<number | null>(null);

  // Copied indicator state
  const [copiedTextId, setCopiedTextId] = useState<string | null>(null);

  // Citation generator state
  const [citeType, setCiteType] = useState<'case' | 'statute'>('case');
  const [citeCaseName, setCiteCaseName] = useState('Green v. Superior Court');
  const [citeVolume, setCiteVolume] = useState('10');
  const [citeReporter, setCiteReporter] = useState('Cal. 3d');
  const [citePage, setCitePage] = useState('616');
  const [citeYear, setCiteYear] = useState('1974');
  
  const [citeStatuteTitle, setCiteStatuteTitle] = useState('California Civil Code');
  const [citeSection, setCiteSection] = useState('1941.1');

  // AI chat consult state
  const [consultQuery, setConsultQuery] = useState('');
  const [consultHistory, setConsultHistory] = useState<Array<{role: 'user' | 'assistant', text: string, memo?: ResearchMemo}>>([
    { 
      role: 'assistant', 
      text: "Welcome to the AI Research Consult. Ask me any legal research question or request authority for a claim, and I will analyze controlling case law and statutes." 
    }
  ]);
  const [consultLoading, setConsultLoading] = useState(false);

  // Trigger search on mount with active case context if available
  useEffect(() => {
    if (activeCase) {
      setSearchQuery(activeCase.caseType === 'landlord_tenant' ? 'habitability' : 'breach of contract');
      handleSearch(activeCase.caseType === 'landlord_tenant' ? 'habitability' : 'breach of contract');
    } else {
      handleSearch('habitability');
    }
  }, [activeCase]);

  const handleSearch = async (queryText: string) => {
    const q = queryText.trim() || searchQuery.trim() || 'habitability';
    setIsSearching(true);
    setSearchError('');
    
    try {
      const response = await fetch('/api/research', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: q,
          caseType: selectedCaseType,
          jurisdiction: selectedJurisdiction
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to retrieve legal research.');
      }

      const data = await response.json();
      if (data.research) {
        setSearchResult(data.research);
      } else {
        throw new Error('Research response was empty.');
      }
    } catch (err: any) {
      setSearchError(err.message || 'An error occurred while fetching legal research.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleAIQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consultQuery.trim()) return;

    const userMessage = consultQuery;
    setConsultHistory(prev => [...prev, { role: 'user', text: userMessage }]);
    setConsultQuery('');
    setConsultLoading(true);

    try {
      const response = await fetch('/api/research', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: userMessage,
          caseType: selectedCaseType,
          jurisdiction: selectedJurisdiction
        }),
      });

      if (!response.ok) throw new Error('Query error');

      const data = await response.json();
      if (data.research) {
        setConsultHistory(prev => [...prev, { 
          role: 'assistant', 
          text: `I have analyzed the authorities for your query "${userMessage}". Below is the statutory and case law brief matching your issue.`,
          memo: data.research
        }]);
      } else {
        throw new Error('Failed to parse AI research memo.');
      }
    } catch (err) {
      setConsultHistory(prev => [...prev, { 
        role: 'assistant', 
        text: "I was unable to retrieve a response. Please check your network or try reformulating your search terms." 
      }]);
    } finally {
      setConsultLoading(false);
    }
  };

  const handleCopyCitation = (citation: string, id: string) => {
    navigator.clipboard.writeText(citation);
    setCopiedTextId(id);
    setTimeout(() => setCopiedTextId(null), 2000);
  };

  // Generate citation string based on manual inputs
  const getGeneratedCitation = () => {
    if (citeType === 'case') {
      return `${citeCaseName}, ${citeVolume} ${citeReporter} ${citePage} (${citeYear})`;
    } else {
      return `${citeStatuteTitle} § ${citeSection}`;
    }
  };

  // Quick preset queries helper
  const handleQuickPreset = (presetQuery: string, type: string) => {
    setSelectedCaseType(type);
    setSearchQuery(presetQuery);
    setActiveTab('search');
    handleSearch(presetQuery);
  };

  return (
    <div className="space-y-6 animate-fade-in" id="research_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <Badge variant="indigo">Statutory & Case Law Precedent</Badge>
            <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Legal Research & Citation Authority</h2>
            <p className="text-xs text-slate-400">Search relevant statutes, analyze precedent holdings, and generate formal courtroom citations.</p>
          </div>
          
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-850 self-start md:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveTab('guides')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
                activeTab === 'guides' ? 'bg-indigo-600 text-slate-100 shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Curated Guides
            </button>
            <button
              onClick={() => setActiveTab('search')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
                activeTab === 'search' ? 'bg-indigo-600 text-slate-100 shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              AI Memo Search
            </button>
            <button
              onClick={() => setActiveTab('citation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
                activeTab === 'citation' ? 'bg-indigo-600 text-slate-100 shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cite Generator
            </button>
            <button
              onClick={() => setActiveTab('procedure')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
                activeTab === 'procedure' ? 'bg-indigo-600 text-slate-100 shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Federal Procedure
            </button>
          </div>
        </div>
      </div>

      {/* CURATED GUIDES TAB */}
      {activeTab === 'guides' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Guide Card 1 */}
            <Card className="hover:border-indigo-500/40 transition-all border-slate-850 flex flex-col justify-between">
              <CardHeader className="space-y-2">
                <div className="p-2.5 bg-indigo-950/40 border border-indigo-900/30 text-indigo-400 rounded-lg w-max">
                  <Scale className="w-5 h-5" />
                </div>
                <CardTitle className="text-sm font-bold uppercase text-slate-200">Residential Tenant Habitability Guide</CardTitle>
                <CardDescription className="text-xs text-slate-400 leading-relaxed">
                  Seminal California law establishing mutuality of covenants in residential leases. Establishes standards of livability, repairs, and legal rent abatements.
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0 pb-6 px-6">
                <Button 
                  onClick={() => handleQuickPreset('habitability and repair', 'landlord_tenant')} 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-xs"
                >
                  Explore Authority Precedents
                </Button>
              </CardContent>
            </Card>

            {/* Guide Card 2 */}
            <Card className="hover:border-indigo-500/40 transition-all border-slate-850 flex flex-col justify-between">
              <CardHeader className="space-y-2">
                <div className="p-2.5 bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 rounded-lg w-max">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <CardTitle className="text-sm font-bold uppercase text-slate-200">Eviction Notice Notice Service Guides</CardTitle>
                <CardDescription className="text-xs text-slate-400 leading-relaxed">
                  Procedural analysis of California CCP § 1162 governing notices, service requirements, and lack of personal jurisdiction defense arguments.
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0 pb-6 px-6">
                <Button 
                  onClick={() => handleQuickPreset('proper service of notice', 'landlord_tenant')} 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-xs"
                >
                  Explore Authority Precedents
                </Button>
              </CardContent>
            </Card>

            {/* Guide Card 3 */}
            <Card className="hover:border-indigo-500/40 transition-all border-slate-850 flex flex-col justify-between">
              <CardHeader className="space-y-2">
                <div className="p-2.5 bg-purple-950/40 border border-purple-900/30 text-purple-400 rounded-lg w-max">
                  <FileText className="w-5 h-5" />
                </div>
                <CardTitle className="text-sm font-bold uppercase text-slate-200">Contract Material Defaults & Damages</CardTitle>
                <CardDescription className="text-xs text-slate-400 leading-relaxed">
                  Expectation damages standards, Hadley foreseeability requirements, and mutual mistake of fact contract voiding elements.
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0 pb-6 px-6">
                <Button 
                  onClick={() => handleQuickPreset('breach of contract damages Hadley', 'contract_dispute')} 
                  variant="outline" 
                  size="sm" 
                  className="w-full text-xs"
                >
                  Explore Authority Precedents
                </Button>
              </CardContent>
            </Card>

          </div>

          {/* Quick FAQ / Code lookup */}
          <Card className="border-slate-850">
            <CardHeader className="border-b border-slate-850 pb-4">
              <CardTitle className="text-xs uppercase tracking-wider text-slate-400 font-mono flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-indigo-400" /> Key Constitutional and Statutory Anchors
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-300">
                <div className="space-y-2 p-4 bg-slate-950/40 border border-slate-900 rounded-xl">
                  <h4 className="font-bold font-mono text-[10px] text-indigo-400 uppercase">Fourteenth Amendment Due Process</h4>
                  <p className="leading-relaxed text-slate-400">
                    The bedrock of legal notification. A court cannot proceed with judgments or evictions unless personal jurisdiction has been properly established via strict, formal notice service. Leaves zero room for 'mailbox drops' without substituted requirements.
                  </p>
                </div>
                <div className="space-y-2 p-4 bg-slate-950/40 border border-slate-900 rounded-xl">
                  <h4 className="font-bold font-mono text-[10px] text-emerald-400 uppercase">Unlawful Detainer Summary Rules</h4>
                  <p className="leading-relaxed text-slate-400">
                    Since eviction is a summary remedy executed on short notices (e.g. 3-day notice to cure or quit), courts strictly enforce notice statutes. Even a minor arithmetic error in calculate-due-rent or date limits renders the lawsuit defective.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* AI MEMO SEARCH & RESULTS TAB */}
      {activeTab === 'search' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* SEARCH CONTROLS */}
          <div className="lg:col-span-4 space-y-6">
            <Card className="border-slate-850 bg-slate-950/30">
              <CardHeader>
                <CardTitle className="text-sm font-bold uppercase text-slate-200">Legal Search Criteria</CardTitle>
                <CardDescription className="text-[11px] text-slate-400">Formulate your query below. Our database will scan primary statutory codes and case precedent reporters.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                
                {/* Search query input */}
                <div className="space-y-1.5">
                  <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Query / Keywords</label>
                  <div className="relative">
                    <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="e.g. Habitability mold, Notice Service, Mutual Mistake..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Case Type Select */}
                <div className="space-y-1.5">
                  <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Area of Law</label>
                  <select
                    value={selectedCaseType}
                    onChange={(e) => setSelectedCaseType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="landlord_tenant">Landlord-Tenant Law</option>
                    <option value="contract_dispute">Breach of Contract</option>
                    <option value="debt_collection">Debt & Finance</option>
                    <option value="small_claims">Small Claims Procedure</option>
                    <option value="employment">Employment & Labor</option>
                  </select>
                </div>

                {/* Jurisdiction Select */}
                <div className="space-y-1.5">
                  <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Controlling Jurisdiction</label>
                  <select
                    value={selectedJurisdiction}
                    onChange={(e) => setSelectedJurisdiction(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="California Superior Court">California Superior Court (Persuasive/Controlling)</option>
                    <option value="New York Supreme Court">New York Civil / Supreme Court</option>
                    <option value="United States Federal Court">Federal District Court (U.S.)</option>
                    <option value="General Common Law Principles">General Common Law Authorities</option>
                  </select>
                </div>

                <Button 
                  onClick={() => handleSearch('')} 
                  variant="primary" 
                  className="w-full justify-center text-xs py-2.5"
                  icon={isSearching ? undefined : Sparkles}
                  disabled={isSearching}
                >
                  {isSearching ? 'Analyzing Precedents...' : 'Execute Research Query'}
                </Button>

                {searchError && (
                  <div className="p-3 bg-rose-950/20 border border-rose-900/30 text-rose-400 rounded-xl text-[10px] leading-normal flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{searchError}</span>
                  </div>
                )}

              </CardContent>
            </Card>

            {/* QUICK AI RESEARCH CHAT */}
            <Card className="border-slate-850">
              <CardHeader className="pb-3 border-b border-slate-850">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> AI Research Consultation
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-4">
                
                {/* Chat History */}
                <div className="h-44 overflow-y-auto space-y-3 pr-1 text-[11px] scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                  {consultHistory.map((item, idx) => (
                    <div 
                      key={idx} 
                      className={`p-3 rounded-xl max-w-[90%] leading-relaxed ${
                        item.role === 'user' 
                          ? 'bg-indigo-950/40 text-slate-200 border border-indigo-900/30 ml-auto' 
                          : 'bg-slate-950/50 text-slate-300 border border-slate-900'
                      }`}
                    >
                      <p>{item.text}</p>
                      {item.memo && (
                        <button
                          onClick={() => {
                            setSearchResult(item.memo!);
                            window.scrollTo({ top: 300, behavior: 'smooth' });
                          }}
                          className="mt-2 text-[10px] text-indigo-400 font-bold hover:underline block cursor-pointer"
                        >
                          → Load briefing results into viewer
                        </button>
                      )}
                    </div>
                  ))}
                  {consultLoading && (
                    <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-900 text-slate-400 text-[11px] animate-pulse">
                      Consulting digital law library...
                    </div>
                  )}
                </div>

                <form onSubmit={handleAIQuery} className="flex gap-2">
                  <input
                    type="text"
                    value={consultQuery}
                    onChange={(e) => setConsultQuery(e.target.value)}
                    placeholder="Ask a custom legal question..."
                    className="flex-1 bg-slate-950 border border-slate-850 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  />
                  <button
                    type="submit"
                    disabled={consultLoading || !consultQuery.trim()}
                    className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-slate-100 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Ask
                  </button>
                </form>

              </CardContent>
            </Card>

          </div>

          {/* SEARCH RESULTS ANALYSIS MEMO */}
          <div className="lg:col-span-8 space-y-6">
            {isSearching ? (
              <Card className="border-slate-850 p-12 text-center flex flex-col items-center justify-center space-y-4">
                <div className="w-12 h-12 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin"></div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">Scanning Legal Databases</p>
                  <p className="text-[11px] text-slate-500">Searching controlling case law reporters and state civil codes...</p>
                </div>
              </Card>
            ) : searchResult ? (
              <div className="space-y-6">
                
                {/* ADVANCED LEGAL RESEARCH PORTAL SUB-TABS */}
                <div className="flex flex-wrap gap-1.5 border-b border-slate-800 pb-2.5">
                  <button
                    onClick={() => setResearchSubTab('exec')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      researchSubTab === 'exec'
                        ? 'bg-indigo-600 text-slate-100'
                        : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <BookOpen className="w-3.5 h-3.5" /> Executive Brief
                  </button>
                  <button
                    onClick={() => setResearchSubTab('law')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      researchSubTab === 'law'
                        ? 'bg-indigo-600 text-slate-100'
                        : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <Scale className="w-3.5 h-3.5" /> Law & Precedent
                  </button>
                  <button
                    onClick={() => setResearchSubTab('facts')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      researchSubTab === 'facts'
                        ? 'bg-indigo-600 text-slate-100'
                        : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <FileText className="w-3.5 h-3.5" /> Fact & Topic Map
                  </button>
                  <button
                    onClick={() => setResearchSubTab('risks')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      researchSubTab === 'risks'
                        ? 'bg-indigo-600 text-slate-100'
                        : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <Gavel className="w-3.5 h-3.5" /> Risks & Reconciliation
                  </button>
                </div>

                {/* SUB-TAB 1: EXECUTIVE BRIEF */}
                {researchSubTab === 'exec' && (
                  <div className="space-y-6 animate-fade-in">
                    
                    {/* Brief Summary & Jurisdiction */}
                    <Card className="bg-indigo-950/10 border-indigo-900/30">
                      <CardHeader className="pb-3 flex flex-row items-center justify-between gap-4 space-y-0">
                        <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-indigo-400 flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-indigo-400" /> Executive Research Brief
                        </CardTitle>
                        {searchResult.jurisdictionAndDate && (
                          <Badge variant="outline" className="bg-slate-950/40 text-slate-400 text-[9px] font-mono border-slate-800 flex items-center gap-1">
                            <MapPin className="w-2.5 h-2.5 text-indigo-400" /> {searchResult.jurisdictionAndDate}
                          </Badge>
                        )}
                      </CardHeader>
                      <CardContent className="p-6 pt-0 space-y-3">
                        <p className="text-xs text-slate-300 leading-relaxed font-normal">{searchResult.summary}</p>
                      </CardContent>
                    </Card>

                    {/* Plain-English Explanation */}
                    {searchResult.plainEnglishExplanation && (
                      <Card className="border-emerald-950/30 bg-emerald-950/5">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-emerald-400 flex items-center gap-2">
                            <HelpCircle className="w-4 h-4" /> Plain-English Interpretation
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 pt-0">
                          <p className="text-xs text-slate-300 leading-relaxed font-normal">{searchResult.plainEnglishExplanation}</p>
                        </CardContent>
                      </Card>
                    )}

                    {/* Recommended Actions */}
                    {searchResult.recommendedActions && searchResult.recommendedActions.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Recommended Next Actions
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                          <ul className="space-y-3.5 text-xs text-slate-300">
                            {searchResult.recommendedActions.map((action, idx) => (
                              <li key={idx} className="flex gap-3 items-start">
                                <span className="w-5 h-5 bg-indigo-950/50 border border-indigo-900/30 text-[10px] font-mono text-indigo-400 rounded-full flex items-center justify-center shrink-0 mt-0.5 font-bold">
                                  {idx + 1}
                                </span>
                                <span className="leading-relaxed text-[11px]">{action}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}

                    {/* Practice Tactics */}
                    <Card className="border-slate-850">
                      <CardHeader className="border-b border-slate-850">
                        <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">Practice Tactics & Leverage</CardTitle>
                      </CardHeader>
                      <CardContent className="p-6">
                        <ul className="space-y-3.5 text-[11px] leading-relaxed text-slate-300">
                          {searchResult.practiceTips && searchResult.practiceTips.length > 0 ? (
                            searchResult.practiceTips.map((tip, idx) => (
                              <li key={idx} className="flex gap-2.5 items-start">
                                <span className="w-4 h-4 bg-slate-900 border border-slate-800 text-[10px] font-mono text-indigo-400 rounded flex items-center justify-center shrink-0 mt-0.5">
                                  {idx + 1}
                                </span>
                                <span>{tip}</span>
                              </li>
                            ))
                          ) : (
                            <p className="text-xs text-slate-500 italic">No practice tips returned.</p>
                          )}
                        </ul>
                      </CardContent>
                    </Card>

                  </div>
                )}

                {/* SUB-TAB 2: LAW & PRECEDENT */}
                {researchSubTab === 'law' && (
                  <div className="space-y-6 animate-fade-in">
                    
                    {/* Controlling Statutes */}
                    <Card className="border-slate-850">
                      <CardHeader className="border-b border-slate-850">
                        <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                          Controlling Statutory Codes & Regulations ({searchResult.statutes?.length || 0})
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-6 divide-y divide-slate-900 space-y-4">
                        {searchResult.statutes && searchResult.statutes.length > 0 ? (
                          searchResult.statutes.map((stat, idx) => {
                            const isExpanded = expandedStatute === idx;
                            return (
                              <div key={idx} className="pt-4 first:pt-0 space-y-2">
                                <div className="flex items-start justify-between gap-4">
                                  <div className="space-y-1">
                                    <span className="inline-block bg-indigo-950/50 border border-indigo-900/30 text-indigo-400 font-mono text-[10px] px-2 py-0.5 rounded">
                                      {stat.code}
                                    </span>
                                    <h4 className="text-xs font-bold text-slate-200 uppercase">{stat.title}</h4>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <button
                                      onClick={() => handleCopyCitation(stat.code, `stat_${idx}`)}
                                      className="p-1 hover:bg-slate-900 text-slate-500 hover:text-slate-300 rounded cursor-pointer"
                                      title="Copy statutory code"
                                    >
                                      {copiedTextId === `stat_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                                    </button>
                                    <button
                                      onClick={() => setExpandedStatute(isExpanded ? null : idx)}
                                      className="p-1 hover:bg-slate-900 text-slate-500 hover:text-slate-300 rounded cursor-pointer"
                                    >
                                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                    </button>
                                  </div>
                                </div>
                                
                                <p className="text-[11px] text-slate-400 leading-relaxed">{stat.summary}</p>
                                
                                {isExpanded && (
                                  <div className="p-4 bg-slate-950/50 border border-slate-900 rounded-xl text-[11px] leading-relaxed mt-2 animate-fade-in space-y-1">
                                    <span className="block text-[8px] font-mono font-bold text-indigo-400 uppercase tracking-widest">Practical Application in Case</span>
                                    <p className="text-slate-300">{stat.application}</p>
                                  </div>
                                )}
                              </div>
                            );
                          })
                        ) : (
                          <p className="text-xs text-slate-500 italic">No statutory provisions returned.</p>
                        )}
                      </CardContent>
                    </Card>

                    {/* Seminal Cases */}
                    <Card className="border-slate-850">
                      <CardHeader className="border-b border-slate-850">
                        <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                          Seminal Judicial Precedents ({searchResult.cases?.length || 0})
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-6 divide-y divide-slate-900 space-y-4">
                        {searchResult.cases && searchResult.cases.length > 0 ? (
                          searchResult.cases.map((cs, idx) => {
                            const isExpanded = expandedCase === idx;
                            return (
                              <div key={idx} className="pt-4 first:pt-0 space-y-2">
                                <div className="flex items-start justify-between gap-4">
                                  <div className="space-y-1">
                                    <h4 className="text-xs font-extrabold text-slate-200 uppercase tracking-tight">{cs.name}</h4>
                                    <span className="inline-block text-[10px] font-mono font-bold text-indigo-400">
                                      {cs.citation}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <button
                                      onClick={() => handleCopyCitation(`${cs.name}, ${cs.citation}`, `case_${idx}`)}
                                      className="p-1 hover:bg-slate-900 text-slate-500 hover:text-slate-300 rounded cursor-pointer"
                                      title="Copy case citation"
                                    >
                                      {copiedTextId === `case_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                                    </button>
                                    <button
                                      onClick={() => setExpandedCase(isExpanded ? null : idx)}
                                      className="p-1 hover:bg-slate-900 text-slate-500 hover:text-slate-300 rounded cursor-pointer"
                                    >
                                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                                    </button>
                                  </div>
                                </div>

                                <div className="space-y-1.5 text-[11px] leading-relaxed">
                                  <p className="text-slate-400 font-serif italic">"{cs.holding}"</p>
                                </div>

                                {isExpanded && (
                                  <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl text-[11px] leading-relaxed mt-2 animate-fade-in space-y-2.5">
                                    <div>
                                      <span className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-widest">Underlying Case Facts</span>
                                      <p className="text-slate-300 font-normal mt-0.5">{cs.facts}</p>
                                    </div>
                                    <div>
                                      <span className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-widest">Question of Law Presented</span>
                                      <p className="text-slate-300 font-normal mt-0.5">{cs.issue}</p>
                                    </div>
                                    <div className="border-t border-slate-900 pt-2 mt-1">
                                      <span className="block text-[8px] font-mono font-bold text-indigo-400 uppercase tracking-widest">How to leverage in current case</span>
                                      <p className="text-indigo-300 font-normal mt-0.5">{cs.relevance}</p>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })
                        ) : (
                          <p className="text-xs text-slate-500 italic">No case precedents returned.</p>
                        )}
                      </CardContent>
                    </Card>

                    {/* Doctrines & Burdens */}
                    <Card className="border-slate-850">
                      <CardHeader className="border-b border-slate-850">
                        <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">Legal Doctrines & Burdens</CardTitle>
                      </CardHeader>
                      <CardContent className="p-6 space-y-4">
                        {searchResult.doctrines && searchResult.doctrines.length > 0 ? (
                          searchResult.doctrines.map((doc, idx) => (
                            <div key={idx} className="space-y-1.5 text-xs">
                              <h4 className="font-bold text-slate-200 uppercase text-[11px] flex items-center gap-1.5">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> {doc.name}
                              </h4>
                              <p className="text-slate-400 leading-normal text-[11px]">{doc.definition}</p>
                              <div className="bg-slate-950/40 p-2 border border-slate-900 rounded-lg text-[10px] leading-relaxed text-slate-400">
                                <span className="font-bold text-indigo-400 uppercase">Burden:</span> {doc.burdenOfProof}
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-xs text-slate-500 italic">No specific doctrines returned.</p>
                        )}
                      </CardContent>
                    </Card>

                    {/* Source Verification Table */}
                    {searchResult.sourceVerificationTable && searchResult.sourceVerificationTable.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Source Verification Table
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0 overflow-x-auto">
                          <table className="w-full text-left text-[11px] border-collapse">
                            <thead>
                              <tr className="bg-slate-950 text-slate-400 font-mono text-[9px] uppercase tracking-wider border-b border-slate-850">
                                <th className="p-3">Proposition</th>
                                <th className="p-3">Source & Citation</th>
                                <th className="p-3 text-center">Status</th>
                                <th className="p-3">Notes</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-900 bg-slate-950/20">
                              {searchResult.sourceVerificationTable.map((row, idx) => (
                                <tr key={idx} className="hover:bg-slate-950/40">
                                  <td className="p-3 font-medium text-slate-200 max-w-xs truncate" title={row.proposition}>
                                    {row.proposition}
                                  </td>
                                  <td className="p-3 space-y-0.5">
                                    <div className="font-bold text-slate-300">{row.source}</div>
                                    <div className="text-[10px] font-mono text-indigo-400">{row.citationOrLink}</div>
                                    <div className="text-[9px] text-slate-500">{row.authorityLevel} ({row.jurisdiction})</div>
                                  </td>
                                  <td className="p-3 text-center">
                                    <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                                      row.verified.includes('YES')
                                        ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-900/40'
                                        : 'bg-amber-950/50 text-amber-400 border border-amber-900/40'
                                    }`}>
                                      {row.verified}
                                    </span>
                                  </td>
                                  <td className="p-3 text-slate-400 max-w-xs leading-normal">{row.notes}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </CardContent>
                      </Card>
                    )}

                  </div>
                )}

                {/* SUB-TAB 3: FACT & TOPIC MAP */}
                {researchSubTab === 'facts' && (
                  <div className="space-y-6 animate-fade-in">
                    
                    {/* Factual Matrix (Confirmed vs Disputed) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card className="border-emerald-950/30">
                        <CardHeader className="bg-emerald-950/10 border-b border-emerald-950/20">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-emerald-400">
                            Confirmed Facts & Documentation
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-5">
                          {searchResult.confirmedFacts && searchResult.confirmedFacts.length > 0 ? (
                            <ul className="space-y-2.5 text-[11px] text-slate-300">
                              {searchResult.confirmedFacts.map((fact, idx) => (
                                <li key={idx} className="flex gap-2 items-start">
                                  <span className="text-emerald-500 font-bold mt-0.5">✓</span>
                                  <span>{fact}</span>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-slate-500 italic">No confirmed facts categorized in this briefing yet.</p>
                          )}
                        </CardContent>
                      </Card>

                      <Card className="border-amber-950/30">
                        <CardHeader className="bg-amber-950/10 border-b border-amber-950/20">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-amber-400">
                            Disputed Allegations & Gaps
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-5">
                          {searchResult.disputedFacts && searchResult.disputedFacts.length > 0 ? (
                            <ul className="space-y-2.5 text-[11px] text-slate-300">
                              {searchResult.disputedFacts.map((fact, idx) => (
                                <li key={idx} className="flex gap-2 items-start">
                                  <span className="text-amber-500 font-bold mt-0.5">?</span>
                                  <span>{fact}</span>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-slate-500 italic">No active disputed allegations categorized.</p>
                          )}
                        </CardContent>
                      </Card>
                    </div>

                    {/* Legal Issues Spotted */}
                    {searchResult.legalIssues && searchResult.legalIssues.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Legal Issues Spotted (Substantive & Evidentiary)
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {searchResult.legalIssues.map((issue, idx) => (
                              <div key={idx} className="flex gap-3 items-start p-3 bg-slate-950/40 border border-slate-900 rounded-xl">
                                <div className="text-indigo-400 font-mono font-bold text-xs bg-indigo-950/40 border border-indigo-900/30 rounded-lg w-6 h-6 flex items-center justify-center shrink-0">
                                  Q{idx + 1}
                                </div>
                                <p className="text-[11px] leading-relaxed text-slate-300 font-normal">{issue}</p>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Legal Topic Map (West-Inspired Classification) */}
                    {searchResult.legalTopicMap && searchResult.legalTopicMap.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Legal Topic & Classification Map
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0 overflow-x-auto">
                          <table className="w-full text-left text-[11px] border-collapse">
                            <thead>
                              <tr className="bg-slate-950 text-slate-400 font-mono text-[9px] uppercase tracking-wider border-b border-slate-850">
                                <th className="p-3">Topic / Subtopic</th>
                                <th className="p-3">Operative Elements</th>
                                <th className="p-3">Burden & Burden Bearer</th>
                                <th className="p-3">Remedies / Defenses</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-900 bg-slate-950/20">
                              {searchResult.legalTopicMap.map((topic, idx) => (
                                <tr key={idx} className="hover:bg-slate-950/40 align-top">
                                  <td className="p-3">
                                    <div className="font-extrabold text-slate-200 uppercase text-[10px]">{topic.broadTopic}</div>
                                    <div className="text-[10px] text-indigo-400 italic mt-0.5">{topic.subtopic}</div>
                                  </td>
                                  <td className="p-3 text-slate-300 leading-relaxed max-w-xs">{topic.elements}</td>
                                  <td className="p-3 text-slate-400 leading-relaxed max-w-xs">{topic.burdenAndStandard}</td>
                                  <td className="p-3 space-y-1.5 max-w-xs">
                                    {topic.exceptionDefenses && (
                                      <div>
                                        <span className="block text-[8px] font-mono font-bold text-amber-500 uppercase">Defenses / Exceptions</span>
                                        <p className="text-slate-400 leading-normal mt-0.5">{topic.exceptionDefenses}</p>
                                      </div>
                                    )}
                                    {topic.remedies && (
                                      <div>
                                        <span className="block text-[8px] font-mono font-bold text-emerald-400 uppercase">Remedies</span>
                                        <p className="text-slate-400 leading-normal mt-0.5">{topic.remedies}</p>
                                      </div>
                                    )}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </CardContent>
                      </Card>
                    )}

                    {/* Evidence Analysis Matrix */}
                    {searchResult.evidenceAnalysis && searchResult.evidenceAnalysis.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Evidence Analysis & Admissibility Evaluation
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                          {searchResult.evidenceAnalysis.map((item, idx) => (
                            <div key={idx} className="p-4 bg-slate-950/40 border border-slate-900 rounded-xl space-y-2.5">
                              <div className="flex items-center justify-between gap-4 border-b border-slate-900 pb-2">
                                <h4 className="text-xs font-bold text-indigo-300 uppercase">{item.item}</h4>
                                <span className="text-[9px] font-mono uppercase text-slate-500 font-bold">Exhibit #{idx + 1}</span>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[11px] leading-relaxed">
                                <div>
                                  <span className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-widest">Proposition Proved</span>
                                  <p className="text-slate-300 mt-0.5">{item.proves}</p>
                                </div>
                                <div>
                                  <span className="block text-[8px] font-mono font-bold text-slate-500 uppercase tracking-widest">Hearsay & Authentication</span>
                                  <p className="text-slate-300 mt-0.5">{item.hearsayAndAuthentication}</p>
                                </div>
                                <div>
                                  <span className="block text-[8px] font-mono font-bold text-amber-500 uppercase tracking-widest">Exclusion & Prejudice Risks</span>
                                  <p className="text-slate-300 mt-0.5">{item.risks}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    )}

                  </div>
                )}

                {/* SUB-TAB 4: RISKS & RECONCILIATION */}
                {researchSubTab === 'risks' && (
                  <div className="space-y-6 animate-fade-in">
                    
                    {/* Adversarial Testing (Strongest Arguments Side-By-Side) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card className="border-indigo-950/40">
                        <CardHeader className="bg-indigo-950/20 border-b border-indigo-900/30">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-indigo-400">
                            Strongest User Arguments
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-5">
                          {searchResult.strongestUserArguments && searchResult.strongestUserArguments.length > 0 ? (
                            <ul className="space-y-3 text-[11px] text-slate-300">
                              {searchResult.strongestUserArguments.map((arg, idx) => (
                                <li key={idx} className="flex gap-2.5 items-start">
                                  <span className="text-indigo-400 font-bold font-mono">[{idx+1}]</span>
                                  <span>{arg}</span>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-slate-500 italic">No user arguments analyzed.</p>
                          )}
                        </CardContent>
                      </Card>

                      <Card className="border-rose-950/40">
                        <CardHeader className="bg-rose-950/20 border-b border-rose-900/30">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-rose-400">
                            Strongest Opposing Arguments
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-5">
                          {searchResult.strongestOpposingArguments && searchResult.strongestOpposingArguments.length > 0 ? (
                            <ul className="space-y-3 text-[11px] text-slate-300">
                              {searchResult.strongestOpposingArguments.map((arg, idx) => (
                                <li key={idx} className="flex gap-2.5 items-start">
                                  <span className="text-rose-400 font-bold font-mono">[{idx+1}]</span>
                                  <span>{arg}</span>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="text-xs text-slate-500 italic">No opposing arguments analyzed.</p>
                          )}
                        </CardContent>
                      </Card>
                    </div>

                    {/* Procedural & Deadline Risks */}
                    {searchResult.proceduralRisks && searchResult.proceduralRisks.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Procedural Obstacles & Deadline Controls
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0 overflow-x-auto">
                          <table className="w-full text-left text-[11px] border-collapse">
                            <thead>
                              <tr className="bg-slate-950 text-slate-400 font-mono text-[9px] uppercase tracking-wider border-b border-slate-850">
                                <th className="p-3">Procedural Issue</th>
                                <th className="p-3">Governing Rules / Codes</th>
                                <th className="p-3">Filing / Motion Deadlines</th>
                                <th className="p-3">Waiver / Preservation Risks</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-900 bg-slate-950/20">
                              {searchResult.proceduralRisks.map((risk, idx) => (
                                <tr key={idx} className="hover:bg-slate-950/40 align-top">
                                  <td className="p-3 font-extrabold text-slate-200">{risk.issue}</td>
                                  <td className="p-3 text-indigo-400 font-mono text-[10px]">{risk.rules}</td>
                                  <td className="p-3 text-rose-400 font-bold">{risk.deadlines}</td>
                                  <td className="p-3 text-slate-400 leading-normal max-w-xs">{risk.waiverRisks}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </CardContent>
                      </Card>
                    )}

                    {/* Missing Evidence */}
                    {searchResult.missingEvidence && searchResult.missingEvidence.length > 0 && (
                      <Card className="border-rose-950/40 bg-rose-950/5">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-rose-400 flex items-center gap-2">
                            <ShieldAlert className="w-4 h-4 text-rose-400" /> Crucial Investigation & Evidence Gaps
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 pt-0">
                          <ul className="space-y-2 text-[11px] text-slate-300">
                            {searchResult.missingEvidence.map((item, idx) => (
                              <li key={idx} className="flex gap-2 items-start">
                                <span className="text-rose-500 font-bold">⚠️</span>
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}

                    {/* Math-Based Risk Scoring */}
                    {searchResult.riskAssessment && searchResult.riskAssessment.length > 0 && (
                      <Card className="border-slate-850">
                        <CardHeader className="border-b border-slate-850">
                          <CardTitle className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                            Decisional Strength & Risk Scoring (0 - 100)
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-6">
                          {searchResult.riskAssessment.map((assess, idx) => {
                            const score = assess.score;
                            // color codes for visual safety gauge
                            const scoreColor = score >= 70 
                              ? 'bg-emerald-500 text-emerald-400 border-emerald-900/50' 
                              : score >= 45 
                                ? 'bg-amber-500 text-amber-400 border-amber-900/50' 
                                : 'bg-rose-500 text-rose-400 border-rose-900/50';
                            
                            const scoreBg = score >= 70 
                              ? 'bg-emerald-950/20 border-emerald-900/20' 
                              : score >= 45 
                                ? 'bg-amber-950/20 border-amber-900/20' 
                                : 'bg-rose-950/20 border-rose-900/20';

                            return (
                              <div key={idx} className={`p-4 border rounded-xl space-y-3.5 ${scoreBg}`}>
                                <div className="flex items-center justify-between gap-4">
                                  <h4 className="text-xs font-extrabold text-slate-200 uppercase tracking-tight">{assess.argument}</h4>
                                  <div className="flex items-center gap-1.5 font-mono text-xs">
                                    <span className="text-[10px] text-slate-500">PROBABILITY / STRENGTH:</span>
                                    <span className={`px-2 py-0.5 rounded font-extrabold font-mono text-[11px] border ${
                                      score >= 70 ? 'bg-emerald-950 text-emerald-400 border-emerald-900/30' : score >= 45 ? 'bg-amber-950 text-amber-400 border-amber-900/30' : 'bg-rose-950 text-rose-400 border-rose-900/30'
                                    }`}>
                                      {score}%
                                    </span>
                                  </div>
                                </div>

                                {/* Progress bar */}
                                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-900">
                                  <div className={`h-full ${score >= 70 ? 'bg-emerald-500' : score >= 45 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${score}%` }}></div>
                                </div>

                                {/* Scoring Pillars */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[10px]">
                                  <div className="bg-slate-950/50 p-2 rounded-lg border border-slate-900">
                                    <span className="font-mono font-bold text-slate-500 block uppercase text-[8px]">Legal Authority</span>
                                    <span className="text-slate-300 mt-0.5 block">{assess.legalAuthority}</span>
                                  </div>
                                  <div className="bg-slate-950/50 p-2 rounded-lg border border-slate-900">
                                    <span className="font-mono font-bold text-slate-500 block uppercase text-[8px]">Factual Support</span>
                                    <span className="text-slate-300 mt-0.5 block">{assess.factualSupport}</span>
                                  </div>
                                  <div className="bg-slate-950/50 p-2 rounded-lg border border-slate-900">
                                    <span className="font-mono font-bold text-slate-500 block uppercase text-[8px]">Admissibility</span>
                                    <span className="text-slate-300 mt-0.5 block">{assess.admissibility}</span>
                                  </div>
                                </div>

                                <p className="text-[11px] leading-relaxed text-slate-400 font-normal border-t border-slate-900/60 pt-2">{assess.explanation}</p>
                              </div>
                            );
                          })}
                        </CardContent>
                      </Card>
                    )}

                    {/* Subsidized Housing Payment Reconciliation Table */}
                    {searchResult.paymentReconciliationTable && searchResult.paymentReconciliationTable.length > 0 && (
                      <Card className="border-indigo-950/30">
                        <CardHeader className="bg-indigo-950/10 border-b border-indigo-900/20">
                          <CardTitle className="text-xs uppercase font-mono font-bold tracking-widest text-indigo-400">
                            HACLA / Section 8 Rent Payment Reconciliation Ledger
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0 overflow-x-auto">
                          <table className="w-full text-left text-[11px] border-collapse min-w-[800px]">
                            <thead>
                              <tr className="bg-slate-950 text-slate-400 font-mono text-[9px] uppercase tracking-wider border-b border-slate-850">
                                <th className="p-3">Month</th>
                                <th className="p-3">Contract Rent</th>
                                <th className="p-3">HACLA Paid</th>
                                <th className="p-3">Tenant Share</th>
                                <th className="p-3">Tenant Paid</th>
                                <th className="p-3">Abatement</th>
                                <th className="p-3 text-red-400">Claimed Balance</th>
                                <th className="p-3 text-emerald-400">Verified Balance</th>
                                <th className="p-3">Source Records</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-900 bg-slate-950/20">
                              {searchResult.paymentReconciliationTable.map((row, idx) => (
                                <tr key={idx} className="hover:bg-slate-950/40 font-mono text-[10px]">
                                  <td className="p-3 font-bold text-slate-200">{row.month}</td>
                                  <td className="p-3 text-slate-300">{row.contractRent}</td>
                                  <td className="p-3 text-indigo-400">{row.haclaPortion}</td>
                                  <td className="p-3 text-amber-400">{row.tenantPortion}</td>
                                  <td className="p-3 text-slate-300">{row.tenantPayment}</td>
                                  <td className="p-3 text-indigo-400">{row.abatement}</td>
                                  <td className="p-3 text-red-400 font-bold">{row.claimedBalance}</td>
                                  <td className="p-3 text-emerald-400 font-extrabold">{row.verifiedLawfulBalance}</td>
                                  <td className="p-3 text-slate-500 font-sans text-[9px] max-w-xs">{row.sourceDocument}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </CardContent>
                      </Card>
                    )}

                  </div>
                )}

              </div>
            ) : (
              <Card className="border-slate-850 p-12 text-center">
                <p className="text-xs text-slate-500">Submit a query or select a guide to load legal research documentation.</p>
              </Card>
            )}
          </div>

        </div>
      )}

      {/* CITE GENERATOR TAB */}
      {activeTab === 'citation' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Form Controls */}
          <Card className="border-slate-850">
            <CardHeader>
              <CardTitle className="text-sm font-bold uppercase text-slate-200">Legal Citation Formulator</CardTitle>
              <CardDescription className="text-xs text-slate-400">
                Formulate perfectly styled court citations adhering to legal citation standards (Bluebook / California Style Manual).
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-xs">
              
              {/* Type Switch */}
              <div className="space-y-1.5">
                <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Authority Type</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setCiteType('case')}
                    className={`flex-1 px-3 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      citeType === 'case' 
                        ? 'bg-indigo-950 border-indigo-500 text-indigo-300' 
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Case Law Precedent
                  </button>
                  <button
                    onClick={() => setCiteType('statute')}
                    className={`flex-1 px-3 py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      citeType === 'statute' 
                        ? 'bg-indigo-950 border-indigo-500 text-indigo-300' 
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Statutory Code
                  </button>
                </div>
              </div>

              {citeType === 'case' ? (
                <div className="space-y-4 animate-fade-in">
                  
                  {/* Case Name */}
                  <div className="space-y-1.5">
                    <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Case Title</label>
                    <input
                      type="text"
                      value={citeCaseName}
                      onChange={(e) => setCiteCaseName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200"
                    />
                  </div>

                  {/* Reporter details */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1.5">
                      <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Volume</label>
                      <input
                        type="text"
                        value={citeVolume}
                        onChange={(e) => setCiteVolume(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 text-center"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Reporter</label>
                      <input
                        type="text"
                        value={citeReporter}
                        onChange={(e) => setCiteReporter(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 text-center"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Page</label>
                      <input
                        type="text"
                        value={citePage}
                        onChange={(e) => setCitePage(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 text-center"
                      />
                    </div>
                  </div>

                  {/* Year */}
                  <div className="space-y-1.5">
                    <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Year of Decision</label>
                    <input
                      type="text"
                      value={citeYear}
                      onChange={(e) => setCiteYear(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200"
                    />
                  </div>

                </div>
              ) : (
                <div className="space-y-4 animate-fade-in">
                  
                  {/* Statute Title */}
                  <div className="space-y-1.5">
                    <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Statutory Code Title</label>
                    <input
                      type="text"
                      value={citeStatuteTitle}
                      onChange={(e) => setCiteStatuteTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200"
                    />
                  </div>

                  {/* Section */}
                  <div className="space-y-1.5">
                    <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Section Number (§)</label>
                    <input
                      type="text"
                      value={citeSection}
                      onChange={(e) => setCiteSection(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200"
                      placeholder="e.g. 1941"
                    />
                  </div>

                </div>
              )}

            </CardContent>
          </Card>

          {/* Output Display */}
          <Card className="border-slate-850 bg-slate-950/20 flex flex-col justify-center">
            <CardContent className="p-8 space-y-6 text-center">
              
              <div className="p-4 bg-slate-950 border border-slate-850 rounded-2xl relative space-y-2">
                <span className="block text-[8px] font-mono font-bold text-indigo-400 uppercase tracking-widest">Formatted Legal Citation Output</span>
                <p className="text-base font-serif italic text-slate-100 font-normal py-4">
                  {getGeneratedCitation()}
                </p>
                
                <Button
                  onClick={() => handleCopyCitation(getGeneratedCitation(), 'manual_cite')}
                  variant="outline"
                  size="sm"
                  className="mx-auto"
                  icon={copiedTextId === 'manual_cite' ? Check : Copy}
                >
                  {copiedTextId === 'manual_cite' ? 'Citation Copied!' : 'Copy to Clipboard'}
                </Button>
              </div>

              <div className="space-y-2 text-left p-4 bg-slate-950/40 rounded-xl border border-slate-900 text-[11px] leading-relaxed text-slate-400">
                <h5 className="font-bold text-slate-300 font-mono text-[9px] uppercase tracking-wider">Citation Usage Practice Note</h5>
                <p>
                  Place citations in parentheticals or as standalone citation sentences in briefs, motions, or administrative pleadings immediately following the legal statement they support.
                </p>
              </div>

            </CardContent>
          </Card>

        </div>
      )}

      {/* FEDERAL CIVIL PROCEDURE & LITIGATION ENGINE TAB */}
      {activeTab === 'procedure' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in" id="federal_procedure_container">
          
          {/* SIDEBAR NAVIGATION OF TOPICS */}
          <div className="lg:col-span-4 space-y-4">
            <Card className="border-slate-850 bg-slate-950/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <Gavel className="w-4 h-4 text-indigo-400" /> Litigation Engine Modules
                </CardTitle>
                <CardDescription className="text-[10px] text-slate-500">
                  Select a procedural or substantive housing module below to view controlling rules, analytical frameworks, and checklists.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-2 pt-0 space-y-1">
                {[
                  { id: 'rulebook', label: 'Rulebook & Historical Reference', badge: 'West’s 2009', icon: History },
                  { id: 'jurisdiction', label: 'Subject-Matter & Personal Jurisdiction', badge: '28 USC § 1331', icon: Scale },
                  { id: 'venue_removal', label: 'Venue, Removal & Remand', badge: 'UD Warning', icon: MapPin },
                  { id: 'commence_pleading', label: 'Commencing & Plausibility Pleading', badge: 'Rule 8 & 9', icon: FileText },
                  { id: 'motions_12', label: 'Rule 12 Motion Defenses', badge: 'Rule 12(b)', icon: ShieldAlert },
                  { id: 'deadline_calc', label: 'Interactive Deadline Calculator', badge: 'Rule 6 Engine', icon: Clock },
                  { id: 'case_mgmt_discov', label: 'Scheduling & Discovery Rules (ESI)', badge: 'Rule 16 & 26', icon: Calendar },
                  { id: 'summary_judgment', label: 'Summary Judgment & Evidence', badge: 'Rule 56 & FRE', icon: CheckCircle2 },
                  { id: 'trial_appeals', label: 'Trial, Post-Trial & Appeals', badge: '28 USC § 1291', icon: Gavel },
                  { id: 'housing_civil', label: 'Housing, Civil Rights & HACLA', badge: 'HUD & § 1983', icon: Briefcase },
                  { id: 'verification_tbl', label: 'Authority Verification Table', badge: 'Compliance Map', icon: BookOpen }
                ].map((item) => {
                  const IconComponent = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setSelectedProcSection(item.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left text-xs transition-all cursor-pointer ${
                        selectedProcSection === item.id
                          ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-200 font-bold shadow-sm'
                          : 'border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <IconComponent className={`w-3.5 h-3.5 shrink-0 ${selectedProcSection === item.id ? 'text-indigo-400' : 'text-slate-500'}`} />
                        <span className="truncate text-slate-200">{item.label}</span>
                      </div>
                      <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded shrink-0 ${
                        selectedProcSection === item.id ? 'bg-indigo-600 text-slate-100' : 'bg-slate-950 text-slate-500 border border-slate-850'
                      }`}>
                        {item.badge}
                      </span>
                    </button>
                  );
                })}
              </CardContent>
            </Card>

            {/* ADVERSARIAL ASSESSMENT CHEAT SHEET */}
            <Card className="border-slate-850 bg-slate-950/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                  Adversarial Risk Checklists
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3.5 text-[11px] leading-relaxed text-slate-300">
                <div className="p-2.5 bg-rose-950/10 border border-rose-900/30 rounded-xl space-y-1">
                  <span className="font-bold text-rose-400 block text-[9px] uppercase font-mono tracking-wider">⚠️ Waiver Risks</span>
                  <p className="text-slate-400 text-[10px]">
                    Failure to raise insufficiency of service, venue, or personal jurisdiction in your first Rule 12 motion or responsive pleading constitutes a permanent, non-appealable waiver of those defenses under Rule 12(h)(1).
                  </p>
                </div>
                <div className="p-2.5 bg-indigo-950/10 border border-indigo-900/30 rounded-xl space-y-1">
                  <span className="font-bold text-indigo-400 block text-[9px] uppercase font-mono tracking-wider">💡 Settlement Leverage</span>
                  <p className="text-slate-400 text-[10px]">
                    Propound early discovery requesting internal HUD/HACLA communications regarding notice approvals. Forcing administrative disclosures often creates settlement momentum.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* ACTIVE CONTENT VIEW */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* 1. RULEBOOK & HISTORY */}
            {selectedProcSection === 'rulebook' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <History className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">West’s Federal Civil Judicial Procedure & Rules (2009 vs Present)</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Analysis of procedural versus substantive litigation machinery.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  <div className="p-4 bg-amber-950/20 border border-amber-900/40 text-amber-300 rounded-xl space-y-2">
                    <h4 className="font-extrabold text-[11px] uppercase tracking-wider flex items-center gap-1.5">
                      ⚠️ CRITICAL ALERT: Outdated 2009 Edition
                    </h4>
                    <p className="leading-relaxed text-slate-300">
                      This system identifies the physical book as <strong>West’s Federal Civil Judicial Procedure and Rules, 2009 Revised Edition</strong>. 
                      Since 2009, major procedural revisions have occurred. Relying blindly on a 2009 rulebook carries severe malpractice risks for active litigation.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[10px] text-slate-400 pt-2 border-t border-amber-900/30">
                      <div>
                        <strong className="text-amber-200">What Changed Since 2009:</strong>
                        <ul className="list-disc pl-4 space-y-1 mt-1">
                          <li>Discovery Scope: 2015 amendments deleted "reasonably calculated to lead to admissible evidence" and established strict <strong>proportionality</strong> limits in Rule 26(b)(1).</li>
                          <li>Electronically Stored Information (ESI): Rule 37(e) completely updated standards for spoliation and lost digital records.</li>
                        </ul>
                      </div>
                      <div>
                        <strong className="text-amber-200">Other Amendments:</strong>
                        <ul className="list-disc pl-4 space-y-1 mt-1">
                          <li>Pleading: Rise of the Twombly/Iqbal plausibility doctrine rendering older standard notice templates vulnerable.</li>
                          <li>Rule 45 Overhaul: Streamlined nationwide service of subpoenas replacing local district restrictions.</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      Substantive Law vs. Procedural Law
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3.5 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2">
                        <Badge variant="indigo">Substantive Law</Badge>
                        <p className="leading-relaxed text-slate-400 text-[11px]">
                          <strong>Definition:</strong> Rules that define, create, and regulate the legal rights, duties, and causes of action. 
                        </p>
                        <p className="text-[10px] text-slate-500 leading-normal italic">
                          Example: The Fair Housing Act establishes a substantive right to be free from discrimination. HUD/HACLA regulations create rights to informal hearings and due process in Section 8 voucher terminations.
                        </p>
                      </div>
                      <div className="p-3.5 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2">
                        <Badge variant="emerald">Procedural Law</Badge>
                        <p className="leading-relaxed text-slate-400 text-[11px]">
                          <strong>Definition:</strong> The mechanical machinery through which those rights and duties are asserted, defended, proved, and enforced.
                        </p>
                        <p className="text-[10px] text-slate-500 leading-normal italic">
                          Example: The Federal Rules of Civil Procedure dictate the deadline for filing an Answer, how subpoenas must be drafted and served, and the burden-shifting structure for Summary Judgment under Rule 56.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950/40 rounded-xl border border-slate-900 space-y-1.5">
                    <span className="font-bold font-mono text-[9px] text-slate-500 uppercase block tracking-wider">Current Controlling Authorities Needed</span>
                    <p className="text-[11px] leading-relaxed text-slate-400">
                      Current federal litigation depends on: (1) Current FRCP/FRAP text, (2) Title 28 of the United States Code, (3) Federal Rules of Evidence, (4) Local District rules, (5) Individual Judge’s standing orders, and (6) Current binding case precedents.
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* 2. SUBJECT-MATTER & PERSONAL JURISDICTION */}
            {selectedProcSection === 'jurisdiction' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Scale className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Subject-Matter & Personal Jurisdiction</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Establishing the court’s basic power to hear the controversy and bind the parties.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-4">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      A. Subject-Matter Jurisdiction (Non-Waivable)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Subject-matter jurisdiction (SMJ) is a constitutional requirement under Article III. Since federal courts are courts of limited jurisdiction, they must confirm SMJ exists at every stage. Lack of SMJ can be raised at any time, including on appeal, and cannot be waived by consent.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-950/50 border border-slate-900 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-[10px] text-indigo-400 font-bold uppercase">Federal-Question</span>
                          <span className="text-[9px] text-slate-500 font-mono">28 U.S.C. § 1331</span>
                        </div>
                        <p className="text-[11px] leading-relaxed text-slate-400">
                          Requires that the action arises under the Constitution, laws, or treaties of the United States. 
                        </p>
                        <p className="text-[10px] text-slate-500 font-serif italic">
                          Rule: Well-Pleaded Complaint Rule holds that federal question must appear on the face of the plaintiff’s properly pleaded complaint. A federal defense or counterclaim (e.g. FHA defense to an eviction) does NOT satisfy § 1331.
                        </p>
                      </div>

                      <div className="p-4 bg-slate-950/50 border border-slate-900 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-[10px] text-indigo-400 font-bold uppercase">Diversity of Citizenship</span>
                          <span className="text-[9px] text-slate-500 font-mono">28 U.S.C. § 1332</span>
                        </div>
                        <p className="text-[11px] leading-relaxed text-slate-400">
                          Requires complete diversity (no plaintiff shares a state of citizenship with any defendant) and the amount in controversy exceeds $75,000.
                        </p>
                        <p className="text-[10px] text-slate-500 font-serif italic">
                          Citizenship: Individuals are citizens of their domicile. Corporations are citizens of their state of incorporation and where they have their principal place of business (nerve center).
                        </p>
                      </div>
                    </div>

                    <div className="p-3 bg-indigo-950/10 border border-indigo-900/30 text-indigo-300 rounded-xl text-[11px]">
                      <strong>Supplemental Jurisdiction (28 U.S.C. § 1367):</strong> Allows a federal court to hear state law claims that are so related to the federal claims that they form part of the same "case or controversy" (common nucleus of operative fact).
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      B. Personal Jurisdiction (Waivable)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      The court’s power over the parties. Subject to the state’s long-arm statute and Constitutional Due Process limits. Unlike SMJ, personal jurisdiction (PJ) is waived if not raised in the defendant's initial response.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3.5 bg-slate-950/40 border border-slate-900 rounded-xl space-y-1">
                        <span className="font-bold text-slate-200 text-[11px]">General (All-Purpose) Jurisdiction</span>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          Where the defendant is "at home." Domicile for individuals; state of incorporation and principal place of business for corporations (Daimler AG v. Bauman).
                        </p>
                      </div>
                      <div className="p-3.5 bg-slate-950/40 border border-slate-900 rounded-xl space-y-1">
                        <span className="font-bold text-slate-200 text-[11px]">Specific (Case-Linked) Jurisdiction</span>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          The controversy arises out of or relates to the defendant's minimum contacts with the forum state. Requires purposeful availment and reasonableness (International Shoe).
                        </p>
                      </div>
                    </div>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 3. VENUE, REMOVAL & REMAND */}
            {selectedProcSection === 'venue_removal' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Venue, Removal & Remand Rules</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Rules governing court selection, forum transfer, and moving cases from state to federal courts.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      A. Venue Requirements (28 U.S.C. § 1391)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Venue is proper in: (1) a judicial district where any defendant resides if all defendants reside in the same state, or (2) a judicial district in which a substantial part of the events giving rise to the claim occurred, or where a substantial part of the property involved is located.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[10.5px]">
                      <div className="p-3 bg-slate-950/50 border border-slate-900 rounded-xl">
                        <strong className="text-indigo-400">Transfer of Venue (§ 1404)</strong>
                        <p className="text-slate-400 mt-1 font-normal">For the convenience of parties and witnesses, in the interest of justice, a court may transfer any civil action to any other district where it might have been brought.</p>
                      </div>
                      <div className="p-3 bg-slate-950/50 border border-slate-900 rounded-xl">
                        <strong className="text-rose-400">Improper Venue Cure (§ 1406)</strong>
                        <p className="text-slate-400 mt-1 font-normal">If venue is filed in the wrong district, the court must dismiss the case, or if it be in the interest of justice, transfer it to a district where it could have been brought.</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      B. Removal and Remand (28 U.S.C. §§ 1441, 1446)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Defendants may remove an action filed in state court to the federal district court of the place where the state action is pending if the federal court has original jurisdiction.
                    </p>
                    
                    <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-2">
                      <span className="font-mono text-[9px] font-bold text-amber-400 uppercase tracking-widest block">⚠️ THE STATE EVICTION REMOVAL DEFECT WARNING</span>
                      <p className="text-[11px] leading-relaxed text-slate-300">
                        <strong>Critical Principle:</strong> Under California practice, an Unlawful Detainer (UD) action is a highly summary state court remedy. 
                        A tenant <strong>CANNOT</strong> remove a state unlawful detainer action to federal court merely because the tenant asserts a federal defense or counterclaim (such as housing discrimination under the Fair Housing Act or violation of Section 8/HACLA federal procedural regulations).
                      </p>
                      <p className="text-[10.5px] text-slate-400 leading-normal">
                        Under the <strong>well-pleaded complaint rule</strong>, the state court complaint itself must arise under federal law. An unlawful detainer complaint is purely a state real property claim. Attempting to remove it based on a federal defense will result in <strong>immediate remand</strong> back to state court, and may expose the tenant to <strong>Rule 11 sanctions</strong> or an order requiring them to pay the landlord's attorney's fees under 28 U.S.C. § 1447(c).
                      </p>
                    </div>

                    <div className="space-y-2 text-[11px]">
                      <span className="font-bold text-slate-200">The Removal Checklist & Timelines:</span>
                      <ul className="list-disc pl-5 space-y-1 text-slate-400">
                        <li><strong>Rule of Unanimity:</strong> All properly served defendants must consent to removal (28 U.S.C. § 1446(b)(2)(A)).</li>
                        <li><strong>Forum-Defendant Rule:</strong> A diversity case cannot be removed if any of the properly joined and served defendants is a citizen of the state in which the action was brought (§ 1441(b)(2)).</li>
                        <li><strong>30-Day Deadline:</strong> Notice of removal must be filed within <strong>30 days</strong> after receipt of the initial pleading or service of summons (§ 1446(b)(1)).</li>
                        <li><strong>Remand Deadline:</strong> A motion to remand on the basis of any defect other than lack of SMJ must be filed within <strong>30 days</strong> of removal (§ 1447(c)). Remand for lack of SMJ can be raised at any time.</li>
                      </ul>
                    </div>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 4. COMMENCING ACTION & PLEADINGS */}
            {selectedProcSection === 'commence_pleading' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Commencing Actions & Pleading Standards</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Rule 3, Rule 4 Service of Process, and Rule 8/9 Plausibility Standards.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      A. Commencing and Service of Process (Rule 3 & 4)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      A civil action is commenced by filing a complaint with the court (Rule 3). Under Rule 4(m), the summons and complaint must be served upon the defendant within <strong>90 days</strong> after the complaint is filed, unless the court grants an extension for good cause.
                    </p>
                    <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl space-y-1.5">
                      <span className="text-[10px] text-indigo-400 font-bold font-mono uppercase">Rule 4(d) Waiver of Service</span>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Plaintiffs may request that the defendant waive service of a summons to reduce costs. If a defendant in the U.S. timely returns the waiver, they receive <strong>60 days</strong> from the date the request was sent to file an Answer (instead of the standard 21 days). If they refuse without good cause, they must pay the costs of formal service.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      B. Pleading Standards: Plausibility Pleading (Rule 8 & 9)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Under Rule 8(a)(2), a pleading must contain "a short and plain statement of the claim showing that the pleader is entitled to relief."
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3.5 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2">
                        <strong className="text-slate-200 block text-[11px]">The Iqbal / Twombly Standard</strong>
                        <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">
                          A complaint must state a claim for relief that is <strong>plausible on its face</strong>. 
                          A claim has facial plausibility when the plaintiff pleads factual content that allows the court to draw the reasonable inference that the defendant is liable for the misconduct alleged.
                        </p>
                        <p className="text-[10px] text-slate-500 leading-normal italic font-normal">
                          Factual allegations must be accepted as true, but threadbare recitals of elements and legal conclusions are ignored.
                        </p>
                      </div>
                      <div className="p-3.5 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2">
                        <strong className="text-slate-200 block text-[11px]">Rule 9: Heightened Particularity</strong>
                        <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">
                          In alleging fraud or mistake, a party must state with <strong>particularity</strong> the circumstances constituting fraud or mistake (the who, what, when, where, and how). 
                        </p>
                        <p className="text-[10px] text-slate-500 leading-normal italic font-normal">
                          Malice, intent, knowledge, and other conditions of a person’s mind may be alleged generally under Rule 9(b).
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-indigo-950/10 border border-indigo-900/30 rounded-xl space-y-1 text-[11px]">
                    <strong>Inconsistent Pleadings Allowed:</strong> Under Rule 8(d)(3), a party may state as many separate claims or defenses as it has, regardless of consistency. These are valuable in housing disputes when asserting alternative counts of constructive eviction and breach of lease.
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 5. RULE 12 DEFENSES */}
            {selectedProcSection === 'motions_12' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Rule 12 Motion Defenses & Consolidation</CardTitle>
                      <CardDescription className="text-xs text-slate-400">A rigorous checklist of pre-answer defensive motions and waiver rules.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-4">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      The Rule 12(b) Defenses Checklist
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      A defendant may assert several defenses by motion before filing an answer. Rule 12(b) defines these defenses:
                    </p>

                    <div className="space-y-2">
                      {[
                        { num: '12(b)(1)', name: 'Lack of Subject-Matter Jurisdiction', desc: 'Can be raised at any time, including on appeal. Non-waivable. If court lacks SMJ, it must dismiss.', waivable: false },
                        { num: '12(b)(2)', name: 'Lack of Personal Jurisdiction', desc: 'Waived if omitted from first Rule 12 motion or responsive pleading under Rule 12(h)(1).', waivable: true },
                        { num: '12(b)(3)', name: 'Improper Venue', desc: 'Waived if omitted from first response. May result in dismissal or transfer.', waivable: true },
                        { num: '12(b)(4)', name: 'Insufficient Process', desc: 'Challenges the content/form of the summons. Waived if omitted from first response.', waivable: true },
                        { num: '12(b)(5)', name: 'Insufficient Service of Process', desc: 'Challenges the method/delivery of service. Waived if omitted from first response.', waivable: true },
                        { num: '12(b)(6)', name: 'Failure to State a Claim upon which Relief can be Granted', desc: 'Tests pleading plausibility. Can be raised in any pleading, by motion for judgment on the pleadings, or at trial.', waivable: false },
                        { num: '12(b)(7)', name: 'Failure to Join a Party under Rule 19', desc: 'Challenges failure to join an indispensable party. Can be raised in pleadings, by motion, or at trial.', waivable: false }
                      ].map((def) => (
                        <div key={def.num} className="p-3 bg-slate-950/60 border border-slate-900 rounded-xl flex items-start gap-3">
                          <div className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded shrink-0 ${
                            def.waivable ? 'bg-rose-950 border border-rose-900 text-rose-300' : 'bg-emerald-950 border border-emerald-900 text-emerald-300'
                          }`}>
                            {def.num}
                          </div>
                          <div className="space-y-0.5">
                            <h5 className="font-bold text-slate-200 text-xs">{def.name}</h5>
                            <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">{def.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-indigo-950/10 border border-indigo-900/30 rounded-xl space-y-2">
                    <span className="font-bold text-indigo-300 block text-xs uppercase tracking-wide">Rule 12(h) Consolidation & Waiver Rules</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      If a party makes a motion under Rule 12, they must consolidate all waivable Rule 12 defenses (PJ, Venue, Service, Process) into that single motion. 
                      If a defendant moves to dismiss for failure to state a claim (12(b)(6)), but forgets to assert that service was improper (12(b)(5)), the service defense is <strong>forever waived</strong> and cannot be brought in an answer.
                    </p>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 6. INTERACTIVE DEADLINE CALCULATOR */}
            {selectedProcSection === 'deadline_calc' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Interactive Deadline Calculator (Rule 6 Engine)</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Strict calendar calculations adjusted for federal weekend and holiday rules.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl text-slate-400 leading-normal text-[11px]">
                    <strong>FRCP Rule 6(a)(1) Calculation Rule:</strong> In computing any time period: (A) exclude the day of the event that triggers the period, (B) count every day, including Saturdays, Sundays, and legal holidays, and (C) <strong>include the last day</strong>, unless it is a Saturday, Sunday, or legal holiday.
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Calculator Controls */}
                    <div className="p-4 bg-slate-950/40 border border-slate-900 rounded-xl space-y-4">
                      <div className="space-y-1.5">
                        <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Triggering Event Date</label>
                        <input
                          type="date"
                          value={calcTriggerDate}
                          onChange={(e) => setCalcTriggerDate(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">Procedural Rule Event</label>
                        <select
                          value={calcRuleType}
                          onChange={(e) => setCalcRuleType(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 cursor-pointer"
                        >
                          <option value="rule12a">Responsive Pleading - Answer/Rule 12 Motion (21 Days)</option>
                          <option value="rule4d_waived">Waiver of Service responsive pleading (60 Days)</option>
                          <option value="rule12a_us">Answer by U.S. Government, Agency, or Officer (60 Days)</option>
                          <option value="remand_defect">Motion to Remand based on procedural defect (30 Days)</option>
                          <option value="rule12a4_denied">Answer following Rule 12 denial (14 Days)</option>
                          <option value="rule15a_right">Amendment of Pleading once as of right (21 Days)</option>
                          <option value="rule26_disclosures">Initial Disclosures after Rule 26(f) conference (14 Days)</option>
                          <option value="frap4_appeal">Standard Appeal Notice to Circuit Court (30 Days)</option>
                          <option value="frap4_appeal_us">Appeal Notice where U.S. is a Party (60 Days)</option>
                        </select>
                      </div>
                    </div>

                    {/* Calculator Output */}
                    <div className="p-4 bg-indigo-950/10 border border-indigo-900/30 rounded-xl flex flex-col justify-between">
                      {calcResult ? (
                        <div className="space-y-3.5">
                          <div>
                            <span className="block text-[8px] font-mono font-bold text-indigo-400 uppercase tracking-widest">Calculated Deadline</span>
                            <p className="text-sm font-bold text-slate-100 mt-1">{calcResult.date}</p>
                            <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                              ({calcResult.days} Days from {calcTriggerDate})
                            </span>
                          </div>

                          <div className="text-[10.5px] text-slate-400 leading-normal border-t border-slate-800 pt-2.5 font-normal">
                            <span className="block font-bold text-slate-300 font-mono text-[8px] uppercase tracking-wider">{calcResult.rule}</span>
                            <p className="mt-0.5">{calcResult.description}</p>
                          </div>

                          {calcResult.holidaysEncountered.length > 0 && (
                            <div className="p-2 bg-slate-950/60 rounded border border-slate-900 text-[10px] text-amber-400 space-y-0.5">
                              <span className="block text-[8px] uppercase font-mono text-slate-500 font-bold">Rule 6 Weekend/Holiday Shifts</span>
                              <p className="leading-relaxed">
                                Adjusted to skip: {calcResult.holidaysEncountered.join(', ')}
                              </p>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500 italic text-center my-auto">Awaiting valid trigger date input...</p>
                      )}
                      
                      <div className="text-[10px] text-rose-400 leading-normal italic mt-2">
                        * Note: District Local Rules or judge-specific Standing Orders can alter these timelines. Always cross-verify.
                      </div>
                    </div>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 7. SCHEDULING & DISCOVERY RULES (ESI) */}
            {selectedProcSection === 'case_mgmt_discov' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Scheduling Conferences & Discovery Rules (ESI)</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Rule 16 orders, Rule 26 disclosures, proportionality, and digital spoliation sanctions.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      A. Rule 16 Scheduling Order (The Roadmap)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      The Rule 16 scheduling order is a controlling document. It can only be modified for "good cause" and with the judge’s consent under Rule 16(b)(4). It sets dates for amending pleadings, closing discovery, and filing dispositive motions.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      B. Discovery Scope & Proportionality (Rule 26)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Parties may obtain discovery regarding any nonprivileged matter that is <strong>relevant</strong> to any party\'s claim or defense and <strong>proportional</strong> to the needs of the case.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-slate-950/50 border border-slate-900 rounded-xl space-y-1">
                        <strong className="text-[11px] text-slate-200">Required Disclosures (Rule 26(a)(1))</strong>
                        <p className="text-[10.5px] text-slate-400 leading-normal font-normal">
                          Parties must disclose names/contact details of individuals likely to have discoverable information, and copies/descriptions of all documents the disclosing party may use to support its claims or defenses, without waiting for a discovery request.
                        </p>
                      </div>
                      <div className="p-3 bg-slate-950/50 border border-slate-900 rounded-xl space-y-1">
                        <strong className="text-[11px] text-slate-200">Proportionality Factors</strong>
                        <p className="text-[10.5px] text-slate-400 leading-normal font-normal">
                          Factors include: importance of issues at stake, amount in controversy, parties’ relative access to information, resources, importance of discovery in resolving issues, and whether burden outweighs benefit.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      C. Electronic Discovery & Digital Spoliation (Rule 37(e))
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Litigants are under an absolute duty to preserve Electronically Stored Information (ESI) when litigation is reasonably anticipated.
                    </p>
                    <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-2">
                      <strong className="text-rose-400 block text-[11px] uppercase font-mono tracking-wider">Rule 37(e) Failure to Preserve ESI</strong>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                        If ESI is lost because a party failed to take reasonable steps to preserve it:
                      </p>
                      <ul className="list-disc pl-4 text-[10px] space-y-1 text-slate-400 font-normal">
                        <li><strong>Upon finding prejudice:</strong> The court may order measures no greater than necessary to cure the prejudice.</li>
                        <li><strong>Upon finding intentional destruction:</strong> The court may: (A) presume the lost information was unfavorable, (B) instruct the jury to presume it was unfavorable, or (C) dismiss the action or enter a default judgment.</li>
                      </ul>
                    </div>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 8. SUMMARY JUDGMENT & EVIDENCE */}
            {selectedProcSection === 'summary_judgment' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Summary Judgment & Rules of Evidence</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Rule 56 standards, burden shifting, and Federal Rules of Evidence requirements.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      A. Rule 56 Summary Judgment (The Ultimate Hurdle)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      A court shall grant summary judgment if the movant shows that there is <strong>no genuine dispute as to any material fact</strong> and the movant is entitled to judgment as a matter of law.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-slate-950/50 border border-slate-900 rounded-xl space-y-1">
                        <strong className="text-[11px] text-slate-200">The Burden Shifting Framework</strong>
                        <p className="text-[10.5px] text-slate-400 leading-normal font-normal">
                          The moving party bears the initial burden of identifying those portions of pleadings, depositions, or documents which demonstrate the absence of a genuine issue of material fact (Celotex Corp. v. Catrett).
                        </p>
                      </div>
                      <div className="p-3 bg-slate-950/50 border border-slate-900 rounded-xl space-y-1">
                        <strong className="text-[11px] text-slate-200">The Responding Burden</strong>
                        <p className="text-[10.5px] text-slate-400 leading-normal font-normal">
                          Once moving burden is met, the non-moving party must go beyond mere allegations or denials and point to specific <strong>admissible evidence</strong> showing a genuine dispute for trial.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      B. Key Federal Rules of Evidence (FRE)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      On a summary judgment motion, facts must be supported by <strong>admissible evidence</strong>. Forms, emails, or reports that constitute inadmissible hearsay cannot be considered to defeat summary judgment.
                    </p>
                    <div className="space-y-2">
                      <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-900 space-y-1">
                        <span className="font-bold text-indigo-400 text-[10px] uppercase font-mono block">FRE 803(6) Business Records Exception</span>
                        <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">
                          Crucial for housing cases! Rent ledgers, HUD inspection logs, and HACLA administrative notices are admissible hearsay if: (A) made at or near the time by someone with knowledge, (B) kept in the course of a regularly conducted activity, and (C) making the record was a regular practice of that activity.
                        </p>
                      </div>
                      <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-900 space-y-1">
                        <span className="font-bold text-indigo-400 text-[10px] uppercase font-mono block">FRE 1002 Original Writing Rule</span>
                        <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">
                          To prove the content of a writing, recording, or photograph, the original writing is required unless exceptions apply. Digital copies/duplicates are generally admissible under FRE 1003 unless a genuine question is raised about authenticity.
                        </p>
                      </div>
                    </div>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 9. TRIAL, POST-TRIAL & APPEALS */}
            {selectedProcSection === 'trial_appeals' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Gavel className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Trial, Post-Trial Motions & Appeal Rules</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Rule 50 Judgment as a Matter of Law, finality, and FRAP notice deadlines.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      A. Trial and Post-Trial Machinery (Rule 50, 59, 60)
                    </h4>
                    <div className="space-y-3.5">
                      <div className="p-3 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1">
                        <strong className="text-indigo-400 block font-bold">Rule 50: Judgment as a Matter of Law (JMOL)</strong>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                          Before the case is submitted to the jury, a party can move for JMOL. If denied, they can file a <strong>Renewed JMOL</strong> within <strong>28 days</strong> after entry of judgment. A renewed Rule 50(b) motion is strictly prohibited unless the party made the motion under Rule 50(a) prior to jury deliberation.
                        </p>
                      </div>
                      <div className="p-3 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1">
                        <strong className="text-indigo-400 block font-bold">Rule 59: Motion for a New Trial / Altering Judgment</strong>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                          Must be filed no later than <strong>28 days</strong> after entry of judgment. Grounded on trial errors, manifest injustice, or verdict against weight of evidence.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      B. Appellate Jurisdiction & Deadlines (28 U.S.C. § 1291)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Federal courts of appeals have jurisdiction over appeals from all <strong>final decisions</strong> of the district courts.
                    </p>
                    <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl space-y-1.5">
                      <span className="font-bold text-rose-400 text-[10px] uppercase font-mono block">⚠️ Notice of Appeal Filing Deadline (FRAP 4)</span>
                      <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                        The notice of appeal must be filed with the district clerk within <strong>30 days</strong> after entry of the judgment or order appealed from (FRAP 4(a)(1)(A)).
                      </p>
                      <p className="text-[10.5px] text-slate-500 leading-normal font-normal">
                        <strong>Jurisdictional:</strong> This 30-day window is strictly jurisdictional. Circuit courts have zero authority to extend it for excusable neglect beyond the very narrow limits set in FRAP 4(a)(5). Miss the deadline, and the appeal is permanently barred.
                      </p>
                    </div>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 10. SPECIALIZED HOUSING & CIVIL RIGHTS */}
            {selectedProcSection === 'housing_civil' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Specialized Housing, Civil Rights & HACLA Module</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Analytical framework for federal statutory actions, Section 8 voucher due process, and immunity defenses.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  
                  <div className="p-4 bg-indigo-950/20 border border-indigo-900/40 text-indigo-300 rounded-xl space-y-1.5">
                    <strong className="block text-xs uppercase tracking-wide">Bedrock Principle: Administrative Private Rights of Action</strong>
                    <p className="text-[11px] leading-relaxed text-slate-300 font-normal">
                      Do not assume that every violation of a HUD housing regulation automatically creates an individual private right of action to sue a landlord or housing authority in federal court.
                    </p>
                    <p className="text-[10.5px] text-slate-400 leading-normal font-normal">
                      Under Supreme Court precedent (Alexander v. Sandoval), a federal agency regulation alone cannot create an enforceable private right of action unless the underlying statute (e.g. United States Housing Act) explicitly authorizes individual civil lawsuits.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      Core Civil Rights Substantive Frameworks
                    </h4>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* Section 1983 */}
                      <div className="p-3.5 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2">
                        <Badge variant="indigo">42 U.S.C. § 1983 Action</Badge>
                        <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">
                          Allows individuals to sue state or municipal actors (e.g., HACLA officials) for constitutional violations, including violations of 14th Amendment procedural due process during Section 8 termination hearings.
                        </p>
                        <div className="p-2 bg-slate-950 rounded text-[9.5px] text-slate-500">
                          <strong className="text-indigo-400">Qualified Immunity:</strong> Standard defense protects officials unless they violated "clearly established" statutory or constitutional rights of which a reasonable person would have known.
                        </div>
                      </div>

                      {/* Fair Housing Act */}
                      <div className="p-3.5 bg-slate-950/60 border border-slate-900 rounded-xl space-y-2">
                        <Badge variant="emerald">Fair Housing Act (FHA)</Badge>
                        <p className="text-[10.5px] text-slate-400 leading-relaxed font-normal">
                          Prohibits discrimination in the sale, rental, or financing of housing based on race, color, religion, sex, familial status, national origin, or disability.
                        </p>
                        <div className="p-2 bg-slate-950 rounded text-[9.5px] text-slate-500">
                          <strong className="text-emerald-400">Accommodations:</strong> Includes refusal to make reasonable accommodations in rules, policies, practices, or services when necessary to afford a disabled person equal opportunity to use housing.
                        </div>
                      </div>

                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold text-xs text-slate-100 uppercase tracking-wide border-b border-slate-800 pb-1.5">
                      Section 8 Voucher Hearing Due Process Checklist (Goldberg v. Kelly)
                    </h4>
                    <p className="leading-relaxed text-slate-400 text-[11px]">
                      Before a Public Housing Authority (such as HACLA) can terminate a Section 8 housing voucher, due process mandates:
                    </p>
                    <ul className="list-disc pl-5 space-y-1.5 text-slate-400 text-[10.5px] font-normal">
                      <li><strong>Detailed Notice:</strong> Timely written notice stating specific grounds for proposed termination.</li>
                      <li><strong>Document Inspection:</strong> Right to examine relevant documents prior to the hearing.</li>
                      <li><strong>Representation:</strong> Right to be represented by counsel or other spokesperson at the family's expense.</li>
                      <li><strong>Adversarial Rights:</strong> Opportunity to present evidence, call witnesses, and confront/cross-examine opposing witnesses.</li>
                      <li><strong>Impartial Decider:</strong> The hearing officer must be an impartial person who was not involved in making the decision.</li>
                      <li><strong>Written Decision:</strong> A written decision stating the brief reasons and evidence relied upon for the determination.</li>
                    </ul>
                  </div>

                </CardContent>
              </Card>
            )}

            {/* 11. AUTHORITY VERIFICATION TABLE */}
            {selectedProcSection === 'verification_tbl' && (
              <Card className="border-slate-850 bg-slate-900/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-indigo-400" />
                    <div>
                      <CardTitle className="text-sm font-bold uppercase text-slate-200">Procedural Authority Verification Table</CardTitle>
                      <CardDescription className="text-xs text-slate-400">Strict compliance map linking core litigation propositions to current codified sources.</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6 text-xs text-slate-300">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[11px] border-collapse">
                      <thead>
                        <tr className="border-b border-slate-800 text-[9px] uppercase font-mono text-slate-400 tracking-wider">
                          <th className="py-2.5 px-3">Legal Proposition</th>
                          <th className="py-2.5 px-3">Governing Rule/Statute</th>
                          <th className="py-2.5 px-3">Court Type</th>
                          <th className="py-2.5 px-3">Effective Status</th>
                          <th className="py-2.5 px-3">Verification Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850 text-slate-300">
                        {[
                          { prop: 'Waiver of PJ defense by omission', source: 'FRCP Rule 12(h)(1)', court: 'Federal District', status: 'VERIFIED — Current Text', action: 'Confirm no prior responsive pleadings or motions have been filed.' },
                          { prop: 'Federal question must be well-pleaded', source: '28 U.S.C. § 1331', court: 'Federal District', status: 'VERIFIED — Statutory', action: 'Draft complaint avoiding relying on anticipated federal defenses.' },
                          { prop: 'Discovery must be proportional to needs', source: 'FRCP Rule 26(b)(1)', court: 'Federal District', status: 'VERIFIED — Modernized', action: 'Verify scope factors under 2015 amendments before propounding.' },
                          { prop: 'Notice of Appeal strict filing limit', source: 'FRAP Rule 4(a)(1)(A)', court: 'Appellate Circuit', status: 'VERIFIED — Jurisdictional', action: 'Mark 30-day limit from judgment docketing in calendar.' },
                          { prop: 'Reasonable accommodation mandate', source: '42 U.S.C. § 3604(f)(3)(B)', court: 'Federal & State', status: 'VERIFIED — FHA', action: 'Request accommodation in writing before initiating administrative claims.' },
                          { prop: 'Goldberg administrative hearing rights', source: '24 C.F.R. § 982.554', court: 'Housing Agency / HUD', status: 'VERIFIED — HUD Regs', action: 'File request for informal hearing within 14 days of HACLA notice.' }
                        ].map((row, idx) => (
                          <tr key={idx} className="hover:bg-slate-950/40">
                            <td className="py-3 px-3 font-medium text-slate-200">{row.prop}</td>
                            <td className="py-3 px-3 font-mono text-indigo-400 font-semibold">{row.source}</td>
                            <td className="py-3 px-3 text-slate-400">{row.court}</td>
                            <td className="py-3 px-3">
                              <span className="bg-emerald-950/50 border border-emerald-900/30 text-emerald-400 px-1.5 py-0.5 rounded text-[9px] font-mono">
                                {row.status}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-slate-400 text-[10px] leading-relaxed font-normal">{row.action}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="p-3.5 bg-slate-950 border border-slate-850 rounded-xl flex items-start gap-2 text-[10px] text-slate-400 leading-normal">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>
                      <strong>Compliance Standard:</strong> These verified authority links represent controlling pathways under current appellate benchmarks. Never cite an outdated, reversed, or unverified rule or statutory code section.
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

          </div>

        </div>
      )}

    </div>
  );
};
