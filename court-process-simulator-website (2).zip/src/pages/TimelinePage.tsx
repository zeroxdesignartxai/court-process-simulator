/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GitMerge, ChevronRight, Clock, ShieldAlert, CheckCircle2, FileText, AlertCircle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, Badge, Button } from '../components/UI';
import { CourtNode } from '../types';

const FLOW_PHASES: CourtNode[] = [
  { id: 'n1', label: 'Demand / Notice Period', description: 'Mandatory pre-filing notices issued to responding party detailing claims and cure period.', status: 'completed', phase: 'pre_filing', requiredFilings: ['Form Notice to Cure', 'Proof of Mail'], deadlines: 'Typically 3, 5, 10, or 30 days prior to filing.' },
  { id: 'n2', label: 'Complaint Draft & Filing', description: 'Drafting the complaint setting forth allegations of fact, claims, and prayer for relief.', status: 'completed', phase: 'pleadings', requiredFilings: ['Summons', 'Verified Complaint', 'Civil Cover Sheet'], deadlines: 'Controlled by Statute of Limitations.' },
  { id: 'n3', label: 'Service of Process', description: 'Delivering Summons and Complaint to Defendant via certified mail or licensed process server.', status: 'completed', phase: 'pleadings', requiredFilings: ['Proof of Service Form', 'Affidavit of Process Server'], deadlines: 'Within 90-120 days after filing the complaint.' },
  { id: 'n4', label: 'Response Period (Answer)', description: 'Defendant files an Answer, Affirmative Defenses, or a Motion to Dismiss/Demurrer.', status: 'current', phase: 'pleadings', requiredFilings: ['Answer with Defenses', 'Motion to Dismiss (Rule 12b)'], deadlines: 'Within 21-30 days after completed service.' },
  { id: 'n5', label: 'Case Management Conference', description: 'First appearance before the assigned judge to establish scheduling orders, ADR, and deadlines.', status: 'upcoming', phase: 'pretrial', requiredFilings: ['Case Management Statement'], deadlines: 'Set by Court Order, usually 90 days post-filing.' },
  { id: 'n6', label: 'Written & Oral Discovery', description: 'Exchanging Interrogatories, Requests for Production, and conducting depositions under oath.', status: 'upcoming', phase: 'discovery', requiredFilings: ['Interrogatories', 'Requests for Production', 'Deposition Notices'], deadlines: 'Completed 30 days prior to initial trial date.' },
  { id: 'n7', label: 'Summary Judgment Motion', description: 'Filing dispositive motions to resolve the dispute prior to trial based on undisputed discovery facts.', status: 'upcoming', phase: 'pretrial', requiredFilings: ['Motion for Summary Judgment', 'Statement of Undisputed Facts'], deadlines: 'Must be filed at least 75 days before trial.' },
  { id: 'n8', label: 'Bench / Jury Trial', description: 'Opening statements, presentation of physical exhibits, witness cross-examinations, and closing arguments.', status: 'upcoming', phase: 'trial', requiredFilings: ['Trial Briefs', 'Exhibit Lists', 'Proposed Jury Instructions'], deadlines: 'Scheduled by the Assigned Judge.' },
  { id: 'n9', label: 'Judgment & Cost Petitions', description: 'Tribunal issues final judgment order. Parties submit cost ledgers and petitions for attorney fees.', status: 'upcoming', phase: 'judgment', requiredFilings: ['Proposed Judgment Order', 'Bill of Costs', 'Fee Motion'], deadlines: 'Filing usually required within 14-30 days of verdict.' },
  { id: 'n10', label: 'Appellate Review', description: 'Filing a notice of appeal challenging legal rulings or trial court procedural decisions.', status: 'upcoming', phase: 'appeal', requiredFilings: ['Notice of Appeal', 'Appellate Docketing Statement'], deadlines: 'Strictly enforced 30 days from entry of final judgment.' },
];

export const TimelinePage: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<CourtNode>(FLOW_PHASES[3]); // Default on Response Period

  return (
    <div className="space-y-6 animate-fade-in" id="timeline_page_root">
      
      {/* HEADER */}
      <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 shadow-lg">
        <div className="space-y-1">
          <Badge variant="purple">Procedural Timeline</Badge>
          <h2 className="text-lg font-black text-slate-100 uppercase tracking-tight">Chronological Litigation Flowchart</h2>
          <p className="text-xs text-slate-400">Map state and federal civil procedures. Drill down into deadlines, mandatory filings, and forfeiture warnings.</p>
        </div>
      </div>

      {/* HORIZONTAL TIMELINE FLOWCHART ROW */}
      <Card>
        <CardContent className="p-6">
          <div className="space-y-2 mb-4">
            <h3 className="text-sm font-black text-slate-100 uppercase tracking-tight">Interactive Procedural Milestones</h3>
            <p className="text-xs text-slate-400">Click on any litigation checkpoint below to inspect statutory rules and required court filings.</p>
          </div>

          <div className="overflow-x-auto pb-4 pt-2">
            <div className="flex items-center gap-3 min-w-[1200px] py-4">
              {FLOW_PHASES.map((node, index) => {
                const isCurrent = node.status === 'current';
                const isCompleted = node.status === 'completed';
                const isSelected = selectedNode?.id === node.id;

                return (
                  <div key={node.id} className="flex items-center gap-3">
                    {/* Node Card */}
                    <button
                      onClick={() => setSelectedNode(node)}
                      className={`w-48 text-left p-4 rounded-xl border transition-all duration-150 cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600/10 border-indigo-500 ring-2 ring-indigo-500/20'
                          : isCurrent
                          ? 'bg-amber-500/10 border-amber-500 animate-pulse'
                          : isCompleted
                          ? 'bg-emerald-500/5 border-emerald-500/30'
                          : 'bg-slate-950 border-slate-900 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                          isCompleted 
                            ? 'bg-emerald-500/10 text-emerald-400' 
                            : isCurrent 
                            ? 'bg-amber-500/10 text-amber-400' 
                            : 'bg-slate-850 text-slate-500'
                        }`}>
                          {node.phase.replace('_', ' ')}
                        </span>
                        {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                        {isCurrent && <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" />}
                      </div>
                      <h4 className="text-xs font-black text-slate-200 leading-tight line-clamp-1">{node.label}</h4>
                      <p className="text-[10px] text-slate-500 line-clamp-1 mt-1">{node.description}</p>
                    </button>

                    {/* Arrow connector */}
                    {index < FLOW_PHASES.length - 1 && (
                      <ChevronRight className={`w-4 h-4 shrink-0 ${isCompleted ? 'text-emerald-500' : 'text-slate-800'}`} />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SELECTION DETAIL CARDS */}
      {selectedNode && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-slide-up">
          
          {/* Main Info */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-indigo-950 text-indigo-400 border border-indigo-900/30 rounded-lg">
                  <GitMerge className="w-4 h-4" />
                </div>
                <div>
                  <CardTitle>{selectedNode.label}</CardTitle>
                  <CardDescription>Litigation Phase: <span className="font-semibold text-indigo-400 capitalize">{selectedNode.phase.replace('_', ' ')}</span></CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-5">
              <div className="text-xs text-slate-300 leading-relaxed">
                <span className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">Procedural Scope</span>
                {selectedNode.description}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-slate-950/60 border border-slate-900 p-4 rounded-xl space-y-2">
                  <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-indigo-400" />
                    Required Filings
                  </span>
                  <ul className="text-xs text-slate-300 list-disc pl-4 space-y-1.5">
                    {selectedNode.requiredFilings.map((filing, index) => (
                      <li key={index}>{filing}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-slate-950/60 border border-slate-900 p-4 rounded-xl space-y-2">
                  <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    Calculation Methods
                  </span>
                  <p className="text-xs text-slate-300 leading-normal">{selectedNode.deadlines}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Warning / Advisory Pane */}
          <Card className="bg-rose-950/10 border-rose-950/40 p-6 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-rose-400 font-bold uppercase tracking-wider text-[10px] font-mono">
                <ShieldAlert className="w-4 h-4" />
                Forfeiture Warning
              </div>
              <h3 className="text-sm font-black text-slate-200 uppercase leading-snug">Waiver of Procedural Rights</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Answering complaints, attending case management conferences, and completing disclosures are strictly bound to timelines. 
                Failing to raise certain affirmative defenses (such as improper service) in your very first responsive pleading waives them permanently.
              </p>
            </div>
            
            <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex items-center gap-2.5 mt-4">
              <AlertCircle className="w-5 h-5 text-indigo-400 shrink-0" />
              <div className="text-[10px] text-slate-400 font-mono leading-normal">
                Status check: 
                <span className={`block font-bold uppercase ${selectedNode.status === 'completed' ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {selectedNode.status.replace('_', ' ')}
                </span>
              </div>
            </div>
          </Card>

        </div>
      )}

    </div>
  );
};
