# Court Process Simulator

A responsive legal case-preparation website for organizing facts, parties, evidence, claims, defenses, deadlines, reports, research notes, and mock-hearing practice.

## What works

- Case intake and browser-local case persistence
- Claims, defenses, evidence, timeline, tasks, reports, and outcomes workspaces
- Mock courtroom and strategy simulations
- Optional Gemini-powered analysis with built-in demonstration fallbacks
- Responsive desktop, tablet, and mobile navigation
- Search across pages and loaded cases

## Run locally

1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env.local`
3. Add `GEMINI_API_KEY` only if AI responses are desired
4. Start the website: `npm run dev`

The simulator remains usable without an API key by returning demonstration responses.

## Production

- Build: `npm run build`
- Start: `npm run start`
- Optional server setting: `PORT`
- Optional cross-origin setting: `CORS_ALLOWED_ORIGIN`

## Important notice

This website is a preparation and educational tool. Its AI outputs, readiness values, and simulated outcomes are not legal advice and do not predict what a judge or jury will do. Verify authorities and deadlines against current official sources and qualified counsel.
